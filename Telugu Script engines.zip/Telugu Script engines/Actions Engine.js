/* ==========================================
   TELUGU ACTIONS ENGINE
   ========================================== */

/* ------------------------------------------
   ACTION CATEGORIES
------------------------------------------ */

const ACTION_CATEGORIES = {

  daily:[
    "తిను",
    "తాగు",
    "నడువు",
    "కూర్చో",
    "నిలబడు",
    "నిద్రపో",
    "కడుగు"
  ],

  learning:[
    "చదువు",
    "రాయి",
    "నేర్చుకో",
    "బోధించు",
    "ఆలోచించు",
    "గీయు"
  ],

  communication:[
    "మాట్లాడు",
    "పిలువు",
    "విను",
    "పాడు",
    "నవ్వు",
    "ఏడు"
  ],

  movement:[
    "పరుగెత్తు",
    "దూకు",
    "ఎక్కు",
    "దుగు",
    "ప్రయాణించు"
  ],

  objectActions:[
    "తెరువు",
    "మూయు",
    "తెచ్చు",
    "ఇవ్వు",
    "తీసుకో",
    "పట్టుకో",
    "వదులు",
    "కట్టు",
    "విప్పు"
  ],

  work:[
    "వంటచేయు",
    "శుభ్రం చేయు",
    "సాగు",
    "పెంచు",
    "పండించు"
  ],

  business:[
    "కొను",
    "అమ్ము"
  ],

  thinking:[
    "ఆలోచించు",
    "దాచు",
    "వెతుకు",
    "అన్వేషించు"
  ],

  social:[
    "సహాయం చేయు",
    "పంపు",
    "రక్షించు"
  ],

  achievement:[
    "గెలుచు",
    "సృష్టించు"
  ]
};

/* ------------------------------------------
   ACTIONS
------------------------------------------ */

const ACTIONS = [

{
telugu:"తిను",
english:"Eat",
emoji:"🍽️",
category:"daily",
object:"ఆహారం"
},

{
telugu:"తాగు",
english:"Drink",
emoji:"🥤",
category:"daily",
object:"నీరు"
},

{
telugu:"నడువు",
english:"Walk",
emoji:"🚶",
category:"movement",
object:"మార్గం"
},

{
telugu:"పరుగెత్తు",
english:"Run",
emoji:"🏃",
category:"movement",
object:"మైదానం"
},

{
telugu:"చదువు",
english:"Study",
emoji:"📚",
category:"learning",
object:"పుస్తకం"
},

{
telugu:"రాయి",
english:"Write",
emoji:"✍️",
category:"learning",
object:"నోట్‌బుక్"
},

{
telugu:"చూడు",
english:"See",
emoji:"👀",
category:"communication",
object:"చిత్రం"
},

{
telugu:"విను",
english:"Listen",
emoji:"👂",
category:"communication",
object:"సంగీతం"
},

{
telugu:"ఆడు",
english:"Play",
emoji:"⚽",
category:"daily",
object:"ఆట"
},

{
telugu:"పాడు",
english:"Sing",
emoji:"🎵",
category:"communication",
object:"పాట"
},

{
telugu:"నవ్వు",
english:"Laugh",
emoji:"😄",
category:"communication",
object:"సంతోషం"
},

{
telugu:"ఏడు",
english:"Cry",
emoji:"😢",
category:"communication",
object:"భావోద్వేగం"
},

{
telugu:"నిద్రపో",
english:"Sleep",
emoji:"😴",
category:"daily",
object:"పడక"
},

{
telugu:"కూర్చో",
english:"Sit",
emoji:"🪑",
category:"daily",
object:"కుర్చీ"
},

{
telugu:"నిలబడు",
english:"Stand",
emoji:"🧍",
category:"daily",
object:"నేల"
},

{
telugu:"ఎక్కు",
english:"Climb",
emoji:"🧗",
category:"movement",
object:"చెట్టు"
},

{
telugu:"దుగు",
english:"Descend",
emoji:"⬇️",
category:"movement",
object:"మెట్లు"
},

{
telugu:"తెరువు",
english:"Open",
emoji:"🚪",
category:"objectActions",
object:"తలుపు"
},

{
telugu:"మూయు",
english:"Close",
emoji:"🚪",
category:"objectActions",
object:"కిటికీ"
},

{
telugu:"తెచ్చు",
english:"Bring",
emoji:"📦",
category:"objectActions",
object:"వస్తువు"
},

{
telugu:"ఇవ్వు",
english:"Give",
emoji:"🤝",
category:"objectActions",
object:"బహుమతి"
},

{
telugu:"తీసుకో",
english:"Take",
emoji:"🖐️",
category:"objectActions",
object:"పుస్తకం"
},

{
telugu:"పిలువు",
english:"Call",
emoji:"📢",
category:"communication",
object:"స్నేహితుడు"
},

{
telugu:"మాట్లాడు",
english:"Speak",
emoji:"🗣️",
category:"communication",
object:"వ్యక్తి"
},

{
telugu:"ఆలోచించు",
english:"Think",
emoji:"🤔",
category:"thinking",
object:"ఆలోచన"
},

{
telugu:"గీయు",
english:"Draw",
emoji:"🎨",
category:"learning",
object:"చిత్రం"
},

{
telugu:"కడుగు",
english:"Wash",
emoji:"🧼",
category:"daily",
object:"చేతులు"
},

{
telugu:"వంటచేయు",
english:"Cook",
emoji:"🍳",
category:"work",
object:"ఆహారం"
},

{
telugu:"కొను",
english:"Buy",
emoji:"🛒",
category:"business",
object:"వస్తువు"
},

{
telugu:"అమ్ము",
english:"Sell",
emoji:"💰",
category:"business",
object:"ఉత్పత్తి"
},

{
telugu:"దాచు",
english:"Hide",
emoji:"📦",
category:"thinking",
object:"వస్తువు"
},

{
telugu:"వెతుకు",
english:"Search",
emoji:"🔍",
category:"thinking",
object:"సమాధానం"
},

{
telugu:"పంపు",
english:"Send",
emoji:"📨",
category:"social",
object:"సందేశం"
},

{
telugu:"సహాయం చేయు",
english:"Help",
emoji:"🤝",
category:"social",
object:"స్నేహితుడు"
},

{
telugu:"పట్టుకో",
english:"Catch",
emoji:"✋",
category:"objectActions",
object:"బంతి"
},

{
telugu:"వదులు",
english:"Release",
emoji:"🕊️",
category:"objectActions",
object:"బంతి"
},

{
telugu:"కట్టు",
english:"Tie",
emoji:"🎀",
category:"objectActions",
object:"తాడు"
},

{
telugu:"విప్పు",
english:"Untie",
emoji:"🎀",
category:"objectActions",
object:"తాడు"
},

{
telugu:"ప్రయాణించు",
english:"Travel",
emoji:"✈️",
category:"movement",
object:"దేశం"
},

{
telugu:"సృష్టించు",
english:"Create",
emoji:"✨",
category:"achievement",
object:"కొత్త విషయం"
},

{
telugu:"దూకు",
english:"Jump",
emoji:"🦘",
category:"movement",
object:"అడ్డంకి"
},

{
telugu:"గెలుచు",
english:"Win",
emoji:"🏆",
category:"achievement",
object:"బహుమతి"
},

{
telugu:"నేర్చుకో",
english:"Learn",
emoji:"📖",
category:"learning",
object:"నైపుణ్యం"
},

{
telugu:"బోధించు",
english:"Teach",
emoji:"👨‍🏫",
category:"learning",
object:"పాఠం"
},

{
telugu:"శుభ్రం చేయు",
english:"Clean",
emoji:"🧹",
category:"work",
object:"గది"
},

{
telugu:"సాగు",
english:"Cultivate",
emoji:"🌱",
category:"work",
object:"పొలం"
},

{
telugu:"పెంచు",
english:"Raise",
emoji:"🐄",
category:"work",
object:"జంతువు"
},

{
telugu:"పండించు",
english:"Grow",
emoji:"🌾",
category:"work",
object:"పంట"
},

{
telugu:"రక్షించు",
english:"Protect",
emoji:"🛡️",
category:"social",
object:"ప్రకృతి"
},

{
telugu:"అన్వేషించు",
english:"Explore",
emoji:"🧭",
category:"thinking",
object:"ప్రపంచం"
}

];

/* ------------------------------------------
   SENTENCE GENERATOR
------------------------------------------ */

function generateActionSentence(action){

  return `${action.object}ను ${action.telugu}.`;
}

/* Examples */

console.log(generateActionSentence(ACTIONS[0]));
// ఆహారాన్ని తిను.

console.log(generateActionSentence(ACTIONS[10]));
// సంతోషాన్ని నవ్వు.

console.log(generateActionSentence(ACTIONS[45]));
// ప్రకృతిని రక్షించు.