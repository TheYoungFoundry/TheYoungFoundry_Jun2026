/* ==========================================
   EMOTIONS RELATIONS (1-30)
   Telugu + English + Synonyms + Antonyms
   ========================================== */

const EMOTIONS_RELATIONS = [

{
word:"సంతోషం",
english:"Happiness",
synonyms:[
{telugu:"ఆనందం",english:"Joy"},
{telugu:"హర్షం",english:"Delight"}
],
antonyms:[
{telugu:"బాధ",english:"Sadness"}
]
},

{
word:"ఆనందం",
english:"Joy",
synonyms:[
{telugu:"సంతోషం",english:"Happiness"},
{telugu:"ఉల్లాసం",english:"Cheerfulness"}
],
antonyms:[
{telugu:"దుఃఖం",english:"Sorrow"}
]
},

{
word:"బాధ",
english:"Sadness",
synonyms:[
{telugu:"విచారం",english:"Grief"},
{telugu:"దుఃఖం",english:"Sorrow"}
],
antonyms:[
{telugu:"సంతోషం",english:"Happiness"}
]
},

{
word:"దుఃఖం",
english:"Sorrow",
synonyms:[
{telugu:"బాధ",english:"Sadness"},
{telugu:"వేదన",english:"Pain"}
],
antonyms:[
{telugu:"ఆనందం",english:"Joy"}
]
},

{
word:"కోపం",
english:"Anger",
synonyms:[
{telugu:"ఆగ్రహం",english:"Rage"},
{telugu:"రోషం",english:"Fury"}
],
antonyms:[
{telugu:"శాంతి",english:"Calmness"}
]
},

{
word:"ఆగ్రహం",
english:"Rage",
synonyms:[
{telugu:"కోపం",english:"Anger"},
{telugu:"రోషం",english:"Wrath"}
],
antonyms:[
{telugu:"ప్రశాంతత",english:"Peace"}
]
},

{
word:"భయం",
english:"Fear",
synonyms:[
{telugu:"భీతి",english:"Terror"},
{telugu:"ఆందోళన",english:"Anxiety"}
],
antonyms:[
{telugu:"ధైర్యం",english:"Courage"}
]
},

{
word:"భీతి",
english:"Terror",
synonyms:[
{telugu:"భయం",english:"Fear"},
{telugu:"పానిక్",english:"Panic"}
],
antonyms:[
{telugu:"ధైర్యం",english:"Bravery"}
]
},

{
word:"ధైర్యం",
english:"Courage",
synonyms:[
{telugu:"సాహసం",english:"Bravery"},
{telugu:"పరాక్రమం",english:"Valor"}
],
antonyms:[
{telugu:"భయం",english:"Fear"}
]
},

{
word:"సాహసం",
english:"Bravery",
synonyms:[
{telugu:"ధైర్యం",english:"Courage"},
{telugu:"పరాక్రమం",english:"Heroism"}
],
antonyms:[
{telugu:"పిరికితనం",english:"Cowardice"}
]
},

{
word:"ప్రేమ",
english:"Love",
synonyms:[
{telugu:"ఆప్యాయత",english:"Affection"},
{telugu:"స్నేహం",english:"Fondness"}
],
antonyms:[
{telugu:"ద్వేషం",english:"Hatred"}
]
},

{
word:"ద్వేషం",
english:"Hatred",
synonyms:[
{telugu:"విరోధం",english:"Hostility"},
{telugu:"అసహ్యం",english:"Dislike"}
],
antonyms:[
{telugu:"ప్రేమ",english:"Love"}
]
},

{
word:"ఆశ",
english:"Hope",
synonyms:[
{telugu:"నమ్మకం",english:"Expectation"},
{telugu:"విశ్వాసం",english:"Faith"}
],
antonyms:[
{telugu:"నిరాశ",english:"Hopelessness"}
]
},

{
word:"నిరాశ",
english:"Disappointment",
synonyms:[
{telugu:"నిస్పృహ",english:"Despair"},
{telugu:"విచారం",english:"Discouragement"}
],
antonyms:[
{telugu:"ఆశ",english:"Hope"}
]
},

{
word:"ఉత్సాహం",
english:"Enthusiasm",
synonyms:[
{telugu:"ఆసక్తి",english:"Interest"},
{telugu:"చురుకుదనం",english:"Eagerness"}
],
antonyms:[
{telugu:"నిరుత్సాహం",english:"Discouragement"}
]
},

{
word:"నిరుత్సాహం",
english:"Discouragement",
synonyms:[
{telugu:"నిస్పృహ",english:"Depression"},
{telugu:"అలసట",english:"Lethargy"}
],
antonyms:[
{telugu:"ఉత్సాహం",english:"Enthusiasm"}
]
},

{
word:"శాంతి",
english:"Peace",
synonyms:[
{telugu:"ప్రశాంతత",english:"Calmness"},
{telugu:"నిశ్చలత",english:"Tranquility"}
],
antonyms:[
{telugu:"అశాంతి",english:"Disturbance"}
]
},

{
word:"అశాంతి",
english:"Restlessness",
synonyms:[
{telugu:"కలత",english:"Uneasiness"},
{telugu:"ఆందోళన",english:"Disturbance"}
],
antonyms:[
{telugu:"శాంతి",english:"Peace"}
]
},

{
word:"ఆందోళన",
english:"Anxiety",
synonyms:[
{telugu:"చింత",english:"Worry"},
{telugu:"భయం",english:"Fear"}
],
antonyms:[
{telugu:"నిశ్చింత",english:"Relief"}
]
},

{
word:"నిశ్చింత",
english:"Relief",
synonyms:[
{telugu:"ప్రశాంతత",english:"Peace"},
{telugu:"సౌఖ్యం",english:"Comfort"}
],
antonyms:[
{telugu:"ఆందోళన",english:"Anxiety"}
]
},

{
word:"గర్వం",
english:"Pride",
synonyms:[
{telugu:"ఆత్మగౌరవం",english:"Self-respect"},
{telugu:"సంతృప్తి",english:"Pride"}
],
antonyms:[
{telugu:"అవమానం",english:"Shame"}
]
},

{
word:"అవమానం",
english:"Shame",
synonyms:[
{telugu:"అగౌరవం",english:"Dishonor"},
{telugu:"సిగ్గు",english:"Embarrassment"}
],
antonyms:[
{telugu:"గర్వం",english:"Pride"}
]
},

{
word:"సిగ్గు",
english:"Embarrassment",
synonyms:[
{telugu:"సంకోచం",english:"Shyness"},
{telugu:"లజ్జ",english:"Modesty"}
],
antonyms:[
{telugu:"ధైర్యం",english:"Confidence"}
]
},

{
word:"ఆశ్చర్యం",
english:"Surprise",
synonyms:[
{telugu:"విస్మయం",english:"Amazement"},
{telugu:"అబ్బురం",english:"Wonder"}
],
antonyms:[
{telugu:"సాధారణత",english:"Normality"}
]
},

{
word:"కృతజ్ఞత",
english:"Gratitude",
synonyms:[
{telugu:"ధన్యవాదం",english:"Thankfulness"},
{telugu:"కృతార్థత",english:"Appreciation"}
],
antonyms:[
{telugu:"కృతఘ్నత",english:"Ingratitude"}
]
},

{
word:"అసూయ",
english:"Jealousy",
synonyms:[
{telugu:"ఈర్ష్య",english:"Envy"},
{telugu:"పోటీభావం",english:"Jealous Feeling"}
],
antonyms:[
{telugu:"ప్రశంస",english:"Admiration"}
]
},

{
word:"కరుణ",
english:"Compassion",
synonyms:[
{telugu:"దయ",english:"Kindness"},
{telugu:"సానుభూతి",english:"Sympathy"}
],
antonyms:[
{telugu:"క్రూరత్వం",english:"Cruelty"}
]
},

{
word:"దయ",
english:"Kindness",
synonyms:[
{telugu:"కరుణ",english:"Compassion"},
{telugu:"సౌమ్యత",english:"Gentleness"}
],
antonyms:[
{telugu:"క్రూరత్వం",english:"Cruelty"}
]
},

{
word:"సంతృప్తి",
english:"Satisfaction",
synonyms:[
{telugu:"తృప్తి",english:"Contentment"},
{telugu:"సంతోషం",english:"Fulfillment"}
],
antonyms:[
{telugu:"అసంతృప్తి",english:"Dissatisfaction"}
]
},

{
word:"అసంతృప్తి",
english:"Dissatisfaction",
synonyms:[
{telugu:"అసంతుష్టి",english:"Discontent"},
{telugu:"నిరాశ",english:"Displeasure"}
],
antonyms:[
{telugu:"సంతృప్తి",english:"Satisfaction"}
]
}

];

/* Total: 30 Emotions */