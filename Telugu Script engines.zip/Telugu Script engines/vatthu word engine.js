/* =====================================================
   TELUGU VATTHULU ENGINE
   Child-Friendly Version
   ===================================================== */

const VATTHULU_ENGINE = [

{
vatthu:"క్క",

words:[
"అక్క",
"అక్కయ్య",
"పక్కన",
"చుక్క",
"చుక్కలు",
"ముక్క",
"ముక్కలు",
"చెక్క",
"ఎక్కు",
"ఎక్కడం"
],

sentences:[
"అక్క పాఠశాలకు వెళ్లింది.",
"ఆకాశంలో ఒక చుక్క కనిపించింది.",
"రాము చెట్టు ఎక్కాడు.",
"టేబుల్ మీద చెక్క ముక్క ఉంది.",
"పిల్ల అమ్మ పక్కన కూర్చుంది."
],

fillBlanks:[
{
question:"అ_",
answer:"క్క"
},
{
question:"చు_",
answer:"క్క"
},
{
question:"ము_",
answer:"క్క"
},
{
question:"ఎ_ు",
answer:"క్క"
}
]

},

{
vatthu:"గ్గ",

words:[
"మొగ్గ",
"మొగ్గలు",
"బుగ్గ",
"బుగ్గలు",
"దగ్గర",
"దగ్గు",
"తగ్గు",
"మగ్గం"
],

sentences:[
"పువ్వు మొగ్గ వికసించింది.",
"పాప బుగ్గలు అందంగా ఉన్నాయి.",
"నా దగ్గర పెన్సిల్ ఉంది.",
"జ్వరం తగ్గింది.",
"మగ్గంతో బట్ట నేస్తారు."
],

fillBlanks:[
{
question:"మొ_",
answer:"గ్గ"
},
{
question:"బు_",
answer:"గ్గ"
},
{
question:"ద_ర",
answer:"గ్గ"
}
]

},

{
vatthu:"చ్చ",

words:[
"పచ్చ",
"మచ్చ",
"పుచ్చకాయ",
"నిచ్చెన",
"కచ్చితం",
"తెచ్చు",
"గుచ్చం"
],

sentences:[
"పచ్చ ఆకు అందంగా ఉంది.",
"అతని చేతిపై మచ్చ ఉంది.",
"పుచ్చకాయ తియ్యగా ఉంటుంది.",
"నిచ్చెనతో పైకి ఎక్కు.",
"రేపు కచ్చితంగా వస్తాను."
],

fillBlanks:[
{
question:"ప_",
answer:"చ్చ"
},
{
question:"మ_",
answer:"చ్చ"
},
{
question:"ని_ెన",
answer:"చ్చ"
}
]

},

{
vatthu:"జ్జ",

words:[
"బుజ్జి",
"మజ్జిగ",
"గుజ్జు",
"గజ్జెలు",
"బజ్జి",
"సజ్జలు"
],

sentences:[
"బుజ్జి పిల్ల నవ్వుతోంది.",
"మజ్జిగ ఆరోగ్యానికి మంచిది.",
"మామిడి గుజ్జు తియ్యగా ఉంటుంది.",
"ఆమె గజ్జెలు ధరించింది.",
"బజ్జి వేడిగా ఉంది."
],

fillBlanks:[
{
question:"బు_ి",
answer:"జ్జ"
},
{
question:"మ_ిగ",
answer:"జ్జ"
},
{
question:"గు_ు",
answer:"జ్జ"
}
]

},

{
vatthu:"ట్ట",

words:[
"కట్ట",
"బుట్ట",
"గుట్ట",
"చుట్ట",
"మట్టి",
"పట్టణం",
"పట్టీ"
],

sentences:[
"రాము ఇల్లు కట్టాడు.",
"బుట్టలో పండ్లు ఉన్నాయి.",
"మట్టి తడిగా ఉంది.",
"హైదరాబాద్ పెద్ద పట్టణం.",
"అమ్మ నాకు పట్టీ ఇచ్చింది."
],

fillBlanks:[
{
question:"క_",
answer:"ట్ట"
},
{
question:"బు_",
answer:"ట్ట"
},
{
question:"మ_ి",
answer:"ట్ట"
}
]

},

{
vatthu:"డ్డ",

words:[
"గడ్డం",
"గడ్డ",
"అడ్డం",
"గొడ్డలి",
"దొడ్డి"
],

sentences:[
"అతనికి గడ్డం ఉంది.",
"గొడ్డలితో చెట్టు నరికారు.",
"రహదారికి అడ్డం వచ్చింది.",
"దొడ్డిలో పశువులు ఉన్నాయి."
],

fillBlanks:[
{
question:"గ_ం",
answer:"డ్డ"
},
{
question:"అ_ం",
answer:"డ్డ"
}
]

},

{
vatthu:"న్న",

words:[
"అన్న",
"అన్నం",
"చిన్న",
"కన్ను",
"వెన్న",
"సున్నా"
],

sentences:[
"అన్న పాఠశాలకు వెళ్లాడు.",
"అన్నం తినాలి.",
"చిన్న పిల్ల ఆడుతోంది.",
"కన్ను ఆరోగ్యంగా ఉండాలి.",
"సున్నా ఒక సంఖ్య."
],

fillBlanks:[
{
question:"అ_",
answer:"న్న"
},
{
question:"చి_",
answer:"న్న"
},
{
question:"క_ు",
answer:"న్న"
}
]

},

{
vatthu:"ప్ప",

words:[
"కప్ప",
"పప్పు",
"చెప్పు",
"తప్పు",
"నిప్పు"
],

sentences:[
"కప్ప చెరువులో ఉంది.",
"పప్పు ఆరోగ్యకరమైన ఆహారం.",
"నీ చెప్పు ఎక్కడ ఉంది?",
"తప్పు చేయకూడదు.",
"నిప్పుతో ఆడకూడదు."
],

fillBlanks:[
{
question:"క_",
answer:"ప్ప"
},
{
question:"ప_ు",
answer:"ప్ప"
},
{
question:"చె_ు",
answer:"ప్ప"
}
]

},

{
vatthu:"బ్బ",

words:[
"డబ్బు",
"అబ్బాయి",
"దిబ్బ",
"బొబ్బట్లు"
],

sentences:[
"డబ్బు జాగ్రత్తగా ఉంచాలి.",
"అబ్బాయి బంతి ఆడుతున్నాడు.",
"దిబ్బ మీద చెట్టు ఉంది.",
"బొబ్బట్లు రుచిగా ఉంటాయి."
],

fillBlanks:[
{
question:"డ_ు",
answer:"బ్బ"
},
{
question:"అ_ాయి",
answer:"బ్బ"
}
]

},

{
vatthu:"మ్మ",

words:[
"అమ్మ",
"బొమ్మ",
"గుమ్మం",
"తమ్ముడు",
"నమ్మకం",
"కుమ్మరి"
],

sentences:[
"అమ్మ వంట చేస్తోంది.",
"బొమ్మ చాలా అందంగా ఉంది.",
"తమ్ముడు పాఠశాలకు వెళ్లాడు.",
"మనకు నమ్మకం ఉండాలి.",
"కుమ్మరి కుండలు తయారు చేస్తాడు."
],

fillBlanks:[
{
question:"అ_",
answer:"మ్మ"
},
{
question:"బొ_",
answer:"మ్మ"
},
{
question:"త_ుడు",
answer:"మ్మ"
}
]

}

];

/* =====================================================
   QUIZ GENERATORS
   ===================================================== */

function random(arr){
  return arr[Math.floor(Math.random()*arr.length)];
}

function randomVatthuLesson(){
  return random(VATTHULU_ENGINE);
}

function generateWordQuiz(){

  const lesson = randomVatthuLesson();
  const word = random(lesson.words);

  return {
    type:"word",
    question:`"${word}" లో ఉన్న వత్తు ఏది?`,
    answer:lesson.vatthu
  };

}

function generateFillBlankQuiz(){

  const lesson = randomVatthuLesson();

  return random(lesson.fillBlanks);

}

function generateSentenceQuiz(){

  const lesson = randomVatthuLesson();

  return {
    type:"sentence",
    sentence:random(lesson.sentences),
    vatthu:lesson.vatthu
  };

}

function generateReadingCard(){

  const lesson = randomVatthuLesson();

  return {
    vatthu:lesson.vatthu,
    words:lesson.words,
    sentences:lesson.sentences
  };

}