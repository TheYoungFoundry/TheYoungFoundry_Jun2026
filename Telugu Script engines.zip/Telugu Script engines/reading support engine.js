/* =========================================================
   TELUGU VATTHULU + SAMYUKTAKSHARALU ENGINE
   ========================================================= */

/* =========================================================
   LESSON DATABASE
   ========================================================= */

const TELUGU_READING_ENGINE = {

"క్క":{
title:"క్క వత్తు",

words:[
"అక్క",
"అక్కయ్య",
"పక్కన",
"చుక్క",
"చుక్కలు",
"ముక్క",
"ముక్కలు",
"చెక్క",
"ఎక్కు",
"ఎక్కడం"
],

sentences:[
"అక్క పాఠశాలకు వెళ్లింది.",
"ఆకాశంలో చుక్కలు కనిపిస్తున్నాయి.",
"రాము చెట్టు ఎక్కాడు.",
"చెక్కతో బల్ల తయారు చేశారు."
]
},

"గ్గ":{
title:"గ్గ వత్తు",

words:[
"మొగ్గ",
"మొగ్గలు",
"బుగ్గ",
"బుగ్గలు",
"దగ్గర",
"దగ్గు",
"తగ్గు",
"మగ్గం"
],

sentences:[
"పువ్వు మొగ్గ వికసించింది.",
"పాప బుగ్గలు అందంగా ఉన్నాయి.",
"నా దగ్గర పుస్తకం ఉంది.",
"జ్వరం తగ్గింది."
]
},

"చ్చ":{
title:"చ్చ వత్తు",

words:[
"పచ్చ",
"మచ్చ",
"పుచ్చకాయ",
"నిచ్చెన",
"కచ్చితం",
"గుచ్చం"
],

sentences:[
"పచ్చ ఆకు అందంగా ఉంది.",
"పుచ్చకాయ తియ్యగా ఉంటుంది.",
"నిచ్చెనతో పైకి ఎక్కు.",
"రేపు కచ్చితంగా వస్తాను."
]
},

"జ్జ":{
title:"జ్జ వత్తు",

words:[
"బుజ్జి",
"మజ్జిగ",
"గుజ్జు",
"గజ్జెలు",
"బజ్జి"
],

sentences:[
"బుజ్జి పిల్ల నవ్వుతోంది.",
"మజ్జిగ ఆరోగ్యానికి మంచిది.",
"మామిడి గుజ్జు తియ్యగా ఉంటుంది."
]
},

"ట్ట":{
title:"ట్ట వత్తు",

words:[
"కట్ట",
"బుట్ట",
"గుట్ట",
"మట్టి",
"పట్టణం"
],

sentences:[
"రాము ఇల్లు కట్టాడు.",
"బుట్టలో పండ్లు ఉన్నాయి.",
"మట్టి తడిగా ఉంది."
]
},

"న్న":{
title:"న్న వత్తు",

words:[
"అన్న",
"అన్నం",
"చిన్న",
"కన్ను",
"వెన్న",
"సున్నా"
],

sentences:[
"అన్న పాఠశాలకు వెళ్లాడు.",
"అన్నం ఆరోగ్యానికి మంచిది.",
"చిన్న పిల్ల ఆడుతోంది."
]
},

"ప్ప":{
title:"ప్ప వత్తు",

words:[
"కప్ప",
"పప్పు",
"చెప్పు",
"తప్పు",
"నిప్పు"
],

sentences:[
"కప్ప చెరువులో ఉంది.",
"పప్పు తినాలి.",
"నిప్పుతో ఆడకూడదు."
]
},

"మ్మ":{
title:"మ్మ వత్తు",

words:[
"అమ్మ",
"బొమ్మ",
"తమ్ముడు",
"నమ్మకం",
"కుమ్మరి"
],

sentences:[
"అమ్మ వంట చేస్తోంది.",
"బొమ్మ అందంగా ఉంది.",
"తమ్ముడు పాఠశాలకు వెళ్లాడు."
]
},

"ల్ల":{
title:"ల్ల వత్తు",

words:[
"పిల్ల",
"బల్ల",
"తల్లి",
"పల్లె",
"మల్లె"
],

sentences:[
"పిల్ల బంతితో ఆడుతోంది.",
"బల్ల మీద పుస్తకం ఉంది.",
"తల్లి ప్రేమ గొప్పది."
]
},

"క్ష":{
title:"క్ష సంయుక్తాక్షరం",

words:[
"క్షమ",
"అక్షరం",
"క్షేత్రం",
"లక్ష్యం",
"సాక్ష్యం"
],

sentences:[
"క్షమ గొప్ప గుణం.",
"అక్షరం తెలుగు భాషకు ఆధారం.",
"లక్ష్యం ఉంటే విజయం వస్తుంది."
]
},

"త్ర":{
title:"త్ర సంయుక్తాక్షరం",

words:[
"మిత్రుడు",
"చిత్రం",
"యాత్ర",
"పాత్ర",
"నేత్రం"
],

sentences:[
"మిత్రుడు నాకు సహాయం చేశాడు.",
"చిత్రం అందంగా ఉంది.",
"యాత్ర ఆనందంగా జరిగింది."
]
},

"జ్ఞ":{
title:"జ్ఞ సంయుక్తాక్షరం",

words:[
"జ్ఞానం",
"విజ్ఞానం",
"జ్ఞాపకం",
"జ్ఞాని"
],

sentences:[
"జ్ఞానం గొప్ప సంపద.",
"విజ్ఞానం ప్రపంచాన్ని మార్చింది.",
"ఆ సంఘటన నాకు జ్ఞాపకం ఉంది."
]
},

"శ్ర":{
title:"శ్ర సంయుక్తాక్షరం",

words:[
"శ్రీ",
"శ్రద్ధ",
"శ్రమ",
"శ్రుతి"
],

sentences:[
"శ్రద్ధగా చదవాలి.",
"శ్రమ లేకుండా విజయం రాదు.",
"శ్రీరాముడు ఆదర్శ పురుషుడు."
]
}

};

/* =========================================================
   HELPERS
   ========================================================= */

function random(arr){
  return arr[Math.floor(Math.random()*arr.length)];
}

function lessonKeys(){
  return Object.keys(TELUGU_READING_ENGINE);
}

function randomLesson(){
  return TELUGU_READING_ENGINE[
    random(lessonKeys())
  ];
}

/* =========================================================
   READING CARD
   ========================================================= */

function generateReadingCard(){

  const lesson = randomLesson();

  return {
    title:lesson.title,
    words:lesson.words,
    sentences:lesson.sentences
  };

}

/* =========================================================
   WORD QUIZ
   ========================================================= */

function generateWordQuiz(){

  const key = random(lessonKeys());

  const lesson =
    TELUGU_READING_ENGINE[key];

  const word =
    random(lesson.words);

  return {

    type:"word",

    question:
      `"${word}" లో ఉన్న అక్షరం ఏది?`,

    answer:key

  };

}

/* =========================================================
   FILL BLANK
   ========================================================= */

function generateFillBlank(){

  const key = random(lessonKeys());

  const lesson =
    TELUGU_READING_ENGINE[key];

  const word =
    random(lesson.words);

  return {

    type:"fill",

    question:
      word.replace(key,"___"),

    answer:key

  };

}

/* =========================================================
   SENTENCE QUIZ
   ========================================================= */

function generateSentenceQuiz(){

  const lesson =
    randomLesson();

  return {

    type:"sentence",

    sentence:
      random(lesson.sentences)

  };

}

/* =========================================================
   READING PASSAGE
   ========================================================= */

function generateReadingPassage(){

  const lesson =
    randomLesson();

  return {

    title:lesson.title,

    passage:
      lesson.sentences.join(" ")

  };

}

/* =========================================================
   READING COMPREHENSION
   ========================================================= */

function generateReadingComprehension(){

  const lesson =
    randomLesson();

  return {

    passage:
      lesson.sentences.join(" "),

    question:
      `"${lesson.title}" లో ఒక పదం చెప్పండి.`,

    answers:
      lesson.words

  };

}

/* =========================================================
   DICTATION
   ========================================================= */

function generateDictation(){

  const lesson =
    randomLesson();

  return {

    word:
      random(lesson.words)

  };

}

/* =========================================================
   SPELLING PRACTICE
   ========================================================= */

function generateSpellingPractice(){

  const lesson =
    randomLesson();

  const word =
    random(lesson.words);

  return {

    question:
      `"${word}" పదాన్ని సరిగా వ్రాయండి`,

    answer:word

  };

}

/* =========================================================
   STATS
   ========================================================= */

function getReadingStats(){

  let totalWords = 0;
  let totalSentences = 0;

  Object.values(TELUGU_READING_ENGINE)
    .forEach(lesson=>{

      totalWords += lesson.words.length;
      totalSentences += lesson.sentences.length;

    });

  return {

    lessons:
      Object.keys(TELUGU_READING_ENGINE).length,

    words:
      totalWords,

    sentences:
      totalSentences

  };

}