/* ==========================================
   TELUGU FRUIT ENGINE
   ========================================== */

/* ------------------------------------------
   ADJECTIVES
------------------------------------------ */

const ADJECTIVES = [
"తీపి",
"పులుపు",
"రసవంతమైన",
"తాజా",
"రుచికరమైన",
"ఆరోగ్యకరమైన",
"పోషకమైన",
"సువాసనగల",
"మృదువైన",
"కరకరలాడే",
"పెద్ద",
"చిన్న",
"రంగురంగుల",
"సహజమైన",
"శుభ్రమైన",
"ఆకర్షణీయమైన",
"ప్రకాశవంతమైన",
"పండిన",
"తాజాగా కోసిన",
"రుచికరమైన"
];

/* ------------------------------------------
   ADVERBS
------------------------------------------ */

const ADVERBS = [
"తియ్యగా",
"రుచిగా",
"ఆరోగ్యకరంగా",
"సహజంగా",
"తాజాగా",
"అందంగా",
"సంతోషంగా",
"సులభంగా",
"నెమ్మదిగా",
"శ్రద్ధగా"
];

/* ------------------------------------------
   COLORS
------------------------------------------ */

const FRUIT_COLORS = [

"పసుపు",
"ఆకుపచ్చ",
"ఎరుపు",
"నారింజ రంగు",
"ఊదా",
"గులాబీ",
"తెలుపు",
"గోధుమ రంగు"

];

/* ------------------------------------------
   TASTES
------------------------------------------ */

const FRUIT_TASTES = [

"తీపి",
"పులుపు",
"తీపి-పులుపు",
"రసవంతమైన",
"సువాసనగల",
"మృదువైన",
"కరకరలాడే",
"తాజా"

];

/* ------------------------------------------
   SHAPES
------------------------------------------ */

const FRUIT_SHAPES = [

"గుండ్రం",
"పొడవైన",
"అండాకారం",
"హృదయాకారం",
"పెద్ద",
"చిన్న"

];

/* ------------------------------------------
   USES
------------------------------------------ */

const FRUIT_USES = [

"జ్యూస్",
"పండ్ల సలాడ్",
"స్మూతీ",
"జామ్",
"పచ్చడి",
"మిఠాయి",
"ఐస్ క్రీమ్",
"నేరుగా తినడం"

];

/* ------------------------------------------
   FRUITS
------------------------------------------ */

const FRUITS = [

{
telugu:"మామిడి",
english:"Mango",
emoji:"🥭",
colors:["పసుపు","ఆకుపచ్చ"],
tastes:["తీపి","రసవంతమైన"],
shapes:["అండాకారం"],
uses:["జ్యూస్","పచ్చడి","నేరుగా తినడం"]
},

{
telugu:"అరటి",
english:"Banana",
emoji:"🍌",
colors:["పసుపు"],
tastes:["తీపి","మృదువైన"],
shapes:["పొడవైన"],
uses:["స్మూతీ","నేరుగా తినడం"]
},

{
telugu:"ద్రాక్ష",
english:"Grapes",
emoji:"🍇",
colors:["ఆకుపచ్చ","ఊదా"],
tastes:["తీపి","రసవంతమైన"],
shapes:["గుండ్రం"],
uses:["జ్యూస్","పండ్ల సలాడ్"]
},

{
telugu:"జామ",
english:"Guava",
emoji:"🍈",
colors:["ఆకుపచ్చ"],
tastes:["తీపి-పులుపు"],
shapes:["గుండ్రం"],
uses:["జ్యూస్","నేరుగా తినడం"]
},

{
telugu:"సపోటా",
english:"Sapota",
emoji:"🍐",
colors:["గోధుమ రంగు"],
tastes:["తీపి"],
shapes:["గుండ్రం"],
uses:["స్మూతీ","నేరుగా తినడం"]
},

{
telugu:"నారింజ",
english:"Orange",
emoji:"🍊",
colors:["నారింజ రంగు"],
tastes:["తీపి-పులుపు"],
shapes:["గుండ్రం"],
uses:["జ్యూస్","నేరుగా తినడం"]
},

{
telugu:"దానిమ్మ",
english:"Pomegranate",
emoji:"❤️",
colors:["ఎరుపు"],
tastes:["తీపి-పులుపు"],
shapes:["గుండ్రం"],
uses:["జ్యూస్","పండ్ల సలాడ్"]
},

{
telugu:"బొప్పాయి",
english:"Papaya",
emoji:"🍈",
colors:["నారింజ రంగు"],
tastes:["తీపి"],
shapes:["అండాకారం"],
uses:["స్మూతీ","నేరుగా తినడం"]
},

{
telugu:"పుచ్చకాయ",
english:"Watermelon",
emoji:"🍉",
colors:["ఆకుపచ్చ","ఎరుపు"],
tastes:["రసవంతమైన","తీపి"],
shapes:["పెద్ద"],
uses:["జ్యూస్","నేరుగా తినడం"]
},

{
telugu:"ఖర్బూజ",
english:"Muskmelon",
emoji:"🍈",
colors:["పసుపు"],
tastes:["తీపి"],
shapes:["గుండ్రం"],
uses:["జ్యూస్","పండ్ల సలాడ్"]
},

{
telugu:"అనాస",
english:"Pineapple",
emoji:"🍍",
colors:["పసుపు"],
tastes:["తీపి-పులుపు"],
shapes:["అండాకారం"],
uses:["జ్యూస్","మిఠాయి"]
},

{
telugu:"ఉసిరి",
english:"Amla",
emoji:"🟢",
colors:["ఆకుపచ్చ"],
tastes:["పులుపు"],
shapes:["గుండ్రం"],
uses:["పచ్చడి"]
},

{
telugu:"నిమ్మ",
english:"Lemon",
emoji:"🍋",
colors:["పసుపు"],
tastes:["పులుపు"],
shapes:["గుండ్రం"],
uses:["జ్యూస్","పచ్చడి"]
},

{
telugu:"సీతాఫలం",
english:"Custard Apple",
emoji:"🍏",
colors:["ఆకుపచ్చ"],
tastes:["తీపి"],
shapes:["గుండ్రం"],
uses:["నేరుగా తినడం"]
},

{
telugu:"రేగిపండు",
english:"Indian Jujube",
emoji:"🍎",
colors:["ఎరుపు","గోధుమ రంగు"],
tastes:["తీపి-పులుపు"],
shapes:["గుండ్రం"],
uses:["నేరుగా తినడం"]
},

{
telugu:"కొబ్బరి",
english:"Coconut",
emoji:"🥥",
colors:["గోధుమ రంగు"],
tastes:["తీపి"],
shapes:["గుండ్రం"],
uses:["మిఠాయి","నేరుగా తినడం"]
},

{
telugu:"చింతపండు",
english:"Tamarind",
emoji:"🟤",
colors:["గోధుమ రంగు"],
tastes:["పులుపు"],
shapes:["పొడవైన"],
uses:["పచ్చడి"]
},

{
telugu:"బత్తాయి",
english:"Sweet Lime",
emoji:"🍊",
colors:["పసుపు"],
tastes:["తీపి-పులుపు"],
shapes:["గుండ్రం"],
uses:["జ్యూస్"]
},

{
telugu:"అత్తి",
english:"Fig",
emoji:"🟣",
colors:["ఊదా"],
tastes:["తీపి"],
shapes:["గుండ్రం"],
uses:["నేరుగా తినడం"]
},

{
telugu:"ఖర్జూరం",
english:"Dates",
emoji:"🌴",
colors:["గోధుమ రంగు"],
tastes:["తీపి"],
shapes:["పొడవైన"],
uses:["మిఠాయి"]
},

{
telugu:"స్ట్రాబెర్రీ",
english:"Strawberry",
emoji:"🍓",
colors:["ఎరుపు"],
tastes:["తీపి-పులుపు"],
shapes:["హృదయాకారం"],
uses:["జామ్","ఐస్ క్రీమ్"]
},

{
telugu:"కివి",
english:"Kiwi",
emoji:"🥝",
colors:["ఆకుపచ్చ"],
tastes:["తీపి-పులుపు"],
shapes:["అండాకారం"],
uses:["సలాడ్"]
},

{
telugu:"పీచ్",
english:"Peach",
emoji:"🍑",
colors:["గులాబీ"],
tastes:["తీపి"],
shapes:["గుండ్రం"],
uses:["నేరుగా తినడం"]
},

{
telugu:"పేర్",
english:"Pear",
emoji:"🍐",
colors:["ఆకుపచ్చ"],
tastes:["తీపి"],
shapes:["అండాకారం"],
uses:["సలాడ్"]
},

{
telugu:"ఆపిల్",
english:"Apple",
emoji:"🍎",
colors:["ఎరుపు","ఆకుపచ్చ"],
tastes:["తీపి"],
shapes:["గుండ్రం"],
uses:["జ్యూస్","నేరుగా తినడం"]
},

{
telugu:"ప్లమ్",
english:"Plum",
emoji:"🟣",
colors:["ఊదా"],
tastes:["తీపి-పులుపు"],
shapes:["గుండ్రం"],
uses:["జామ్"]
},

{
telugu:"చెర్రీ",
english:"Cherry",
emoji:"🍒",
colors:["ఎరుపు"],
tastes:["తీపి"],
shapes:["గుండ్రం"],
uses:["మిఠాయి"]
},

{
telugu:"బ్లూబెర్రీ",
english:"Blueberry",
emoji:"🫐",
colors:["ఊదా"],
tastes:["తీపి"],
shapes:["గుండ్రం"],
uses:["జామ్"]
},

{
telugu:"రాస్ప్‌బెర్రీ",
english:"Raspberry",
emoji:"🍓",
colors:["ఎరుపు"],
tastes:["తీపి-పులుపు"],
shapes:["గుండ్రం"],
uses:["జామ్"]
},

{
telugu:"అవకాడో",
english:"Avocado",
emoji:"🥑",
colors:["ఆకుపచ్చ"],
tastes:["మృదువైన"],
shapes:["అండాకారం"],
uses:["సలాడ్"]
},

{
telugu:"లీచీ",
english:"Lychee",
emoji:"🍈",
colors:["గులాబీ"],
tastes:["తీపి"],
shapes:["గుండ్రం"],
uses:["నేరుగా తినడం"]
},

{
telugu:"రాంబుటాన్",
english:"Rambutan",
emoji:"🔴",
colors:["ఎరుపు"],
tastes:["తీపి"],
shapes:["గుండ్రం"],
uses:["నేరుగా తినడం"]
},

{
telugu:"డ్రాగన్ ఫ్రూట్",
english:"Dragon Fruit",
emoji:"🐉",
colors:["గులాబీ"],
tastes:["తీపి"],
shapes:["అండాకారం"],
uses:["సలాడ్"]
},

{
telugu:"జాక్‌ఫ్రూట్",
english:"Jackfruit",
emoji:"🟢",
colors:["ఆకుపచ్చ"],
tastes:["తీపి"],
shapes:["పెద్ద"],
uses:["మిఠాయి","నేరుగా తినడం"]
},

{
telugu:"మల్బెర్రీ",
english:"Mulberry",
emoji:"🫐",
colors:["ఊదా"],
tastes:["తీపి"],
shapes:["చిన్న"],
uses:["జామ్"]
}

];

/* ------------------------------------------
   ENGINE
------------------------------------------ */

function random(arr){
  return arr[Math.floor(Math.random()*arr.length)];
}

function generateFruitDescription(fruit){

  const color = random(fruit.colors);
  const taste = random(fruit.tastes);
  const shape = random(fruit.shapes);
  const use = random(fruit.uses);

  return `${fruit.telugu} ఒక ${color} రంగు, ${taste} ${shape} పండు. దీనిని ${use} కోసం ఉపయోగిస్తారు.`;
}

/* ------------------------------------------
   EXAMPLES
------------------------------------------ */

console.log(generateFruitDescription(FRUITS[0]));
console.log(generateFruitDescription(FRUITS[10]));
console.log(generateFruitDescription(FRUITS[24]));