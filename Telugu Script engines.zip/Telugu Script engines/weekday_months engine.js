/* ==========================================
   TELUGU WEEKDAYS & MONTHS ENGINE
   ========================================== */

/* ------------------------------------------
   WEEKDAYS
------------------------------------------ */

const WEEKDAYS = [

{
telugu:"ఆదివారం",
english:"Sunday",
short:"ఆది",
emoji:"☀️",
position:1
},

{
telugu:"సోమవారం",
english:"Monday",
short:"సోమ",
emoji:"🌙",
position:2
},

{
telugu:"మంగళవారం",
english:"Tuesday",
short:"మంగళ",
emoji:"🔥",
position:3
},

{
telugu:"బుధవారం",
english:"Wednesday",
short:"బుధ",
emoji:"📚",
position:4
},

{
telugu:"గురువారం",
english:"Thursday",
short:"గురు",
emoji:"🪔",
position:5
},

{
telugu:"శుక్రవారం",
english:"Friday",
short:"శుక్ర",
emoji:"🌸",
position:6
},

{
telugu:"శనివారం",
english:"Saturday",
short:"శని",
emoji:"🪐",
position:7
}

];

/* ------------------------------------------
   ENGLISH MONTHS
------------------------------------------ */

const MONTHS = [

{
telugu:"జనవరి",
english:"January",
days:31,
season:"శిశిర ఋతువు",
position:1
},

{
telugu:"ఫిబ్రవరి",
english:"February",
days:28,
season:"శిశిర ఋతువు",
position:2
},

{
telugu:"మార్చి",
english:"March",
days:31,
season:"వసంత ఋతువు",
position:3
},

{
telugu:"ఏప్రిల్",
english:"April",
days:30,
season:"వసంత ఋతువు",
position:4
},

{
telugu:"మే",
english:"May",
days:31,
season:"గ్రీష్మ ఋతువు",
position:5
},

{
telugu:"జూన్",
english:"June",
days:30,
season:"గ్రీష్మ ఋతువు",
position:6
},

{
telugu:"జూలై",
english:"July",
days:31,
season:"వర్షాకాలం",
position:7
},

{
telugu:"ఆగస్టు",
english:"August",
days:31,
season:"వర్షాకాలం",
position:8
},

{
telugu:"సెప్టెంబర్",
english:"September",
days:30,
season:"వర్షాకాలం",
position:9
},

{
telugu:"అక్టోబర్",
english:"October",
days:31,
season:"శరదృతువు",
position:10
},

{
telugu:"నవంబర్",
english:"November",
days:30,
season:"హేమంత ఋతువు",
position:11
},

{
telugu:"డిసెంబర్",
english:"December",
days:31,
season:"శిశిర ఋతువు",
position:12
}

];

/* ------------------------------------------
   TELUGU (TRADITIONAL) MONTHS
------------------------------------------ */

const TELUGU_MONTHS = [

{
telugu:"చైత్రం",
english:"Chaitra",
season:"వసంత ఋతువు"
},

{
telugu:"వైశాఖం",
english:"Vaisakha",
season:"గ్రీష్మ ఋతువు"
},

{
telugu:"జ్యేష్ఠం",
english:"Jyeshta",
season:"గ్రీష్మ ఋతువు"
},

{
telugu:"ఆషాఢం",
english:"Ashadha",
season:"వర్షాకాలం"
},

{
telugu:"శ్రావణం",
english:"Shravana",
season:"వర్షాకాలం"
},

{
telugu:"భాద్రపదం",
english:"Bhadrapada",
season:"శరదృతువు"
},

{
telugu:"ఆశ్వయుజం",
english:"Ashwayuja",
season:"శరదృతువు"
},

{
telugu:"కార్తీకం",
english:"Kartika",
season:"హేమంత ఋతువు"
},

{
telugu:"మార్గశిరం",
english:"Margashira",
season:"హేమంత ఋతువు"
},

{
telugu:"పుష్యం",
english:"Pushya",
season:"శిశిర ఋతువు"
},

{
telugu:"మాఘం",
english:"Magha",
season:"శిశిర ఋతువు"
},

{
telugu:"ఫాల్గుణం",
english:"Phalguna",
season:"వసంత ఋతువు"
}

];

/* ------------------------------------------
   WEEKDAY SENTENCES
------------------------------------------ */

const WEEKDAY_SENTENCES = [

"{day} వారంలో ఒక రోజు.",

"నేడు {day}.",

"{day} నాకు ఇష్టమైన రోజు.",

"{day} రోజు మేము పాఠశాలకు వెళ్తాము.",

"{day} రోజు ప్రత్యేక కార్యక్రమం ఉంది."
];

/* ------------------------------------------
   MONTH SENTENCES
------------------------------------------ */

const MONTH_SENTENCES = [

"{month} సంవత్సరంలోని ఒక నెల.",

"{month}లో అనేక కార్యక్రమాలు జరుగుతాయి.",

"{month} నెలలో వాతావరణం మారుతుంది.",

"{month} నెలలో పండుగలు వస్తాయి.",

"{month} సంవత్సరంలోని ముఖ్యమైన నెల."
];

/* ------------------------------------------
   QUIZZES
------------------------------------------ */

const WEEKDAY_QUIZZES = [

{
question:"వారంలో మొదటి రోజు ఏది?",
answer:"ఆదివారం"
},

{
question:"ఆదివారం తర్వాత ఏ రోజు వస్తుంది?",
answer:"సోమవారం"
},

{
question:"శుక్రవారం తర్వాత ఏ రోజు వస్తుంది?",
answer:"శనివారం"
},

{
question:"వారంలో మొత్తం ఎన్ని రోజులు ఉంటాయి?",
answer:"7"
}

];

const MONTH_QUIZZES = [

{
question:"సంవత్సరంలో ఎన్ని నెలలు ఉంటాయి?",
answer:"12"
},

{
question:"జనవరి తర్వాత ఏ నెల వస్తుంది?",
answer:"ఫిబ్రవరి"
},

{
question:"డిసెంబర్ సంవత్సరంలోని ఏ నెల?",
answer:"12వ నెల"
},

{
question:"ఉగాది సాధారణంగా ఏ తెలుగు నెలలో వస్తుంది?",
answer:"చైత్రం"
}

];

/* ------------------------------------------
   ENGINE
------------------------------------------ */

function random(arr){
  return arr[Math.floor(Math.random()*arr.length)];
}

function getRandomWeekday(){
  return random(WEEKDAYS);
}

function getRandomMonth(){
  return random(MONTHS);
}

function generateWeekdaySentence(day){

  return random(WEEKDAY_SENTENCES)
    .replace("{day}", day.telugu);
}

function generateMonthSentence(month){

  return random(MONTH_SENTENCES)
    .replace("{month}", month.telugu);
}

/* ------------------------------------------
   EXAMPLES
------------------------------------------ */

console.log(generateWeekdaySentence(WEEKDAYS[0]));
// ఆదివారం వారంలో ఒక రోజు.

console.log(generateMonthSentence(MONTHS[0]));
// జనవరి సంవత్సరంలోని ఒక నెల.

console.log(getRandomWeekday());
console.log(getRandomMonth());