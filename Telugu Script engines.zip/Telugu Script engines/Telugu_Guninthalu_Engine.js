/* ==========================
   TELUGU AKSHARA + GUNINTHALU ENGINE
========================== */

const TELUGU = {};
const SK = {};

/* ==========================
   AKSHARA ENGINE
========================== */

TELUGU.vowels = [
  "అ","ఆ","ఇ","ఈ","ఉ","ఊ",
  "ఋ","ఎ","ఏ","ఐ","ఒ","ఓ","ఔ",
  "అం","అః"
];

TELUGU.consonants = [
  "క","ఖ","గ","ఘ","ఙ",
  "చ","ఛ","జ","ఝ","ఞ",
  "ట","ఠ","డ","ఢ","ణ",
  "త","థ","ద","ధ","న",
  "ప","ఫ","బ","భ","మ",
  "య","ర","ల","వ",
  "శ","ష","స","హ",
  "ళ","క్ష","ఱ"
];

/* ==========================
   HELPERS
========================== */

TELUGU.pick = function(arr){
  return arr[Math.floor(Math.random()*arr.length)];
};

TELUGU.shuffle = function(arr){
  return [...arr].sort(()=>Math.random()-0.5);
};

/* ==========================
   GUNINTHALU ENGINE
========================== */

TELUGU.guninthalu = [
  {suffix:"",  sound:"a"},
  {suffix:"ా", sound:"aa"},
  {suffix:"ి", sound:"i"},
  {suffix:"ీ", sound:"ii"},
  {suffix:"ు", sound:"u"},
  {suffix:"ూ", sound:"uu"},
  {suffix:"ె", sound:"e"},
  {suffix:"ే", sound:"ee"},
  {suffix:"ై", sound:"ai"},
  {suffix:"ొ", sound:"o"},
  {suffix:"ో", sound:"oo"},
  {suffix:"ౌ", sound:"au"}
];

TELUGU.makeGuninthalu = function(base){
  return TELUGU.guninthalu.map(g => ({
    text: base + g.suffix,
    sound: g.sound
  }));
};

TELUGU.randomGunintham = function(){

  const base = TELUGU.pick(TELUGU.consonants);
  const mark = TELUGU.pick(TELUGU.guninthalu);

  return {
    base: base,
    suffix: mark.suffix,
    sound: mark.sound,
    answer: base + mark.suffix
  };
};

/* ==========================
   WORD BANK
========================== */

TELUGU.wordBank = [
  "కోతి",
  "గాలి",
  "తల్లి",
  "పూలు",
  "మామిడి",
  "నది",
  "బడి",
  "చేప",
  "పాప",
  "రాము"
];

/* ==========================
   SKILLS
========================== */

SK.gread = function(level){

  const q = TELUGU.randomGunintham();

  return {
    type:'read',
    question:'ఈ గుణింతాన్ని చదవండి',
    prompt:q.answer,
    answer:q.answer
  };
};

SK.gmatch = function(level){

  const correct = TELUGU.randomGunintham();

  let options = [correct.answer];

  while(options.length < 4){

    const wrong = TELUGU.randomGunintham().answer;

    if(!options.includes(wrong))
      options.push(wrong);
  }

  options = TELUGU.shuffle(options);

  return {
    type:'mcq',
    question:'సరైన గుణింతాన్ని ఎంచుకోండి',
    prompt:correct.answer,
    answer:correct.answer,
    options:options
  };
};

SK.gcomplete = function(level){

  const q = TELUGU.randomGunintham();

  return {
    type:'input',
    question:'గుణింతం పూర్తి చేయండి',
    prompt:q.base + ' + ' + q.suffix,
    answer:q.answer
  };
};

SK.gsound = function(level){

  const correct = TELUGU.randomGunintham();

  let options = [correct.answer];

  while(options.length < 4){

    const wrong = TELUGU.randomGunintham().answer;

    if(!options.includes(wrong))
      options.push(wrong);
  }

  options = TELUGU.shuffle(options);

  return {
    type:'sound',
    question:'ఈ శబ్దానికి సరైన గుణింతాన్ని ఎంచుకోండి',
    prompt:correct.sound,
    answer:correct.answer,
    options:options
  };
};

SK.gdictation = function(level){

  const q = TELUGU.randomGunintham();

  return {
    type:'dictation',
    question:'విని టైప్ చేయండి',
    audio:q.answer,
    answer:q.answer
  };
};

SK.gwordbuild = function(level){

  const word = TELUGU.pick(TELUGU.wordBank);

  const letters = word.split('');

  const scrambled = TELUGU.shuffle(letters);

  return {
    type:'reorder',
    question:'అక్షరాలను అమర్చి పదం తయారు చేయండి',
    prompt:scrambled,
    answer:word
  };
};

/* ==========================
   TOPIC REGISTRATION
========================== */

const TOPICS = [
{
  id:'guninthalu',
  name:'Guninthalu',
  emoji:'✍️',
  skills:[
    'gread',
    'gmatch',
    'gcomplete',
    'gsound',
    'gdictation',
    'gwordbuild'
  ]
}
];