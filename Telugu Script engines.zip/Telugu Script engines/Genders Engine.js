/* ==========================================
   TELUGU GENDERS ENGINE
   ========================================== */

/* ------------------------------------------
   GENDER CATEGORIES
------------------------------------------ */

const GENDER_CATEGORIES = {

  masculine:"పురుష లింగం",
  feminine:"స్త్రీ లింగం",
  common:"ఉభయ లింగం",
  neuter:"నపుంసక లింగం"

};

/* ------------------------------------------
   GENDER PAIRS
------------------------------------------ */

const GENDERS = [

{
male:"తండ్రి",
female:"తల్లి",
englishMale:"Father",
englishFemale:"Mother",
emoji:"👨👩"
},

{
male:"అన్న",
female:"అక్క",
englishMale:"Brother",
englishFemale:"Sister",
emoji:"👦👧"
},

{
male:"తాత",
female:"అమ్మమ్మ",
englishMale:"Grandfather",
englishFemale:"Grandmother",
emoji:"👴👵"
},

{
male:"రాజు",
female:"రాణి",
englishMale:"King",
englishFemale:"Queen",
emoji:"🤴👸"
},

{
male:"బాలుడు",
female:"బాలిక",
englishMale:"Boy",
englishFemale:"Girl",
emoji:"👦👧"
},

{
male:"ఉపాధ్యాయుడు",
female:"ఉపాధ్యాయురాలు",
englishMale:"Teacher",
englishFemale:"Teacher",
emoji:"👨‍🏫👩‍🏫"
},

{
male:"వైద్యుడు",
female:"వైద్యురాలు",
englishMale:"Doctor",
englishFemale:"Doctor",
emoji:"👨‍⚕️👩‍⚕️"
},

{
male:"నటుడు",
female:"నటి",
englishMale:"Actor",
englishFemale:"Actress",
emoji:"🎭"
},

{
male:"గాయకుడు",
female:"గాయని",
englishMale:"Singer",
englishFemale:"Singer",
emoji:"🎤"
},

{
male:"కుమారుడు",
female:"కుమార్తె",
englishMale:"Son",
englishFemale:"Daughter",
emoji:"👦👧"
},

{
male:"వరుడు",
female:"వధువు",
englishMale:"Bridegroom",
englishFemale:"Bride",
emoji:"🤵👰"
},

{
male:"సింహం",
female:"సింహి",
englishMale:"Lion",
englishFemale:"Lioness",
emoji:"🦁"
},

{
male:"పులి",
female:"ఆడ పులి",
englishMale:"Tiger",
englishFemale:"Tigress",
emoji:"🐅"
},

{
male:"ఎద్దు",
female:"ఆవు",
englishMale:"Bull",
englishFemale:"Cow",
emoji:"🐂🐄"
},

{
male:"కోడి పుంజు",
female:"కోడి",
englishMale:"Rooster",
englishFemale:"Hen",
emoji:"🐓🐔"
}

];

/* ------------------------------------------
   COMMON GENDER WORDS
------------------------------------------ */

const COMMON_GENDER = [

{
telugu:"విద్యార్థి",
english:"Student",
emoji:"🎓"
},

{
telugu:"స్నేహితుడు",
english:"Friend",
emoji:"🤝"
},

{
telugu:"పిల్ల",
english:"Child",
emoji:"🧒"
},

{
telugu:"వ్యక్తి",
english:"Person",
emoji:"🧑"
},

{
telugu:"క్రీడాకారుడు",
english:"Player",
emoji:"⚽"
}

];

/* ------------------------------------------
   NEUTER WORDS
------------------------------------------ */

const NEUTER_WORDS = [

{
telugu:"పుస్తకం",
english:"Book",
emoji:"📚"
},

{
telugu:"బల్ల",
english:"Table",
emoji:"🪑"
},

{
telugu:"చెట్టు",
english:"Tree",
emoji:"🌳"
},

{
telugu:"పువ్వు",
english:"Flower",
emoji:"🌸"
},

{
telugu:"కారు",
english:"Car",
emoji:"🚗"
},

{
telugu:"ఇల్లు",
english:"House",
emoji:"🏠"
},

{
telugu:"పెన్",
english:"Pen",
emoji:"🖊️"
},

{
telugu:"సూర్యుడు",
english:"Sun",
emoji:"☀️"
}

];

/* ------------------------------------------
   SENTENCE TEMPLATES
------------------------------------------ */

const GENDER_TEMPLATES = [

"{male} యొక్క స్త్రీలింగం {female}.",

"{female} యొక్క పురుషలింగం {male}.",

"{male} మరియు {female} ఒక జంట పదాలు.",

"{male} పదం పురుషలింగానికి చెందింది.",

"{female} పదం స్త్రీలింగానికి చెందింది."

];

/* ------------------------------------------
   QUIZZES
------------------------------------------ */

const GENDER_QUIZZES = [

"రాజు యొక్క స్త్రీలింగం ఏమిటి?",

"తల్లి యొక్క పురుషలింగం ఏమిటి?",

"ఉపాధ్యాయుడు యొక్క స్త్రీలింగం ఏమిటి?",

"బాలుడు యొక్క స్త్రీలింగం ఏమిటి?",

"ఎద్దు యొక్క స్త్రీలింగం ఏమిటి?"
];

/* ------------------------------------------
   ENGINE
------------------------------------------ */

function random(arr){
  return arr[Math.floor(Math.random()*arr.length)];
}

function generateGenderSentence(pair){

  return random(GENDER_TEMPLATES)
    .replaceAll("{male}",pair.male)
    .replaceAll("{female}",pair.female);
}

function generateGenderDescription(pair){

  return `${pair.male} - ${pair.female} ఒక లింగ జంట.`;
}

/* ------------------------------------------
   EXAMPLES
------------------------------------------ */

console.log(generateGenderSentence(GENDERS[0]));
// తండ్రి యొక్క స్త్రీలింగం తల్లి.

console.log(generateGenderDescription(GENDERS[3]));
// రాజు - రాణి ఒక లింగ జంట.

console.log(generateGenderSentence(GENDERS[7]));
// నటుడు యొక్క స్త్రీలింగం నటి.