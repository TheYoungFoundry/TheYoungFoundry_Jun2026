/* ==========================================
   TELUGU ANIMAL ENGINE
   ========================================== */

/* ------------------------------------------
   ADJECTIVES
------------------------------------------ */

const ADJECTIVES = [
"అందమైన","చిన్న","పెద్ద","తెలివైన","చురుకైన",
"వేగమైన","శక్తివంతమైన","స్నేహపూర్వకమైన","ధైర్యవంతమైన","బలమైన",
"ముద్దైన","శాంతమైన","ఆకర్షణీయమైన","ఉల్లాసమైన","ఆసక్తికరమైన",
"గర్వమైన","సహజమైన","నాజూకైన","సాహసవంతమైన","సంతోషమైన"
];

/* ------------------------------------------
   ADVERBS
------------------------------------------ */

const ADVERBS = [
"వేగంగా","నెమ్మదిగా","అందంగా","గట్టిగా","శాంతంగా",
"చురుకుగా","జాగ్రత్తగా","సంతోషంగా","తెలివిగా","మెల్లగా",
"ఉత్సాహంగా","హాయిగా","ధైర్యంగా","బలంగా","సహజంగా",
"మధురంగా","శ్రద్ధగా","గర్వంగా","ప్రశాంతంగా","తొందరగా"
];

/* ------------------------------------------
   PLACE CATEGORIES
------------------------------------------ */

const PLACE_CATEGORIES = {

  home:[
    "ఇల్లు",
    "ఆవరణ",
    "తోట"
  ],

  farm:[
    "పొలం",
    "వ్యవసాయ క్షేత్రం",
    "పశువుల షెడ్"
  ],

  forest:[
    "అడవి",
    "వనం",
    "సహజవనం"
  ],

  tree:[
    "చెట్టు",
    "చెట్ల కొమ్మ"
  ],

  water:[
    "చెరువు",
    "నది",
    "సరస్సు"
  ],

  city:[
    "నగరం",
    "వీధి",
    "పార్క్"
  ],

  grassland:[
    "పచ్చిక బయలు",
    "మైదానం"
  ],

  desert:[
    "ఎడారి",
    "ఇసుక ప్రాంతం"
  ],

  garden:[
    "పూల తోట",
    "తోట"
  ],

  hill:[
    "కొండ",
    "పర్వత ప్రాంతం"
  ],

  ground:[
    "నేల",
    "భూమి"
  ]
};

/* ------------------------------------------
   VERB CATEGORIES
------------------------------------------ */

const VERB_CATEGORIES = {

  walking:[
    "నడువు",
    "తిరుగు",
    "సంచరించు",
    "కదులు"
  ],

  running:[
    "పరుగెత్తు",
    "దూసుకుపోవు",
    "వేగంగా కదులు"
  ],

  hunting:[
    "వేటాడు",
    "వెంబడించు",
    "పట్టుకో"
  ],

  climbing:[
    "ఎక్కు",
    "చెట్టు ఎక్కు",
    "పైకి చేరుకో"
  ],

  jumping:[
    "దూకు",
    "గెంతు"
  ],

  swimming:[
    "ఈదు",
    "నీటిలో తేలియాడు"
  ],

  feeding:[
    "తిను",
    "గడ్డి తిను",
    "ఆహారం వెతుకు"
  ],

  sleeping:[
    "నిద్రపో",
    "విశ్రాంతి తీసుకో"
  ],

  guarding:[
    "కాపలా కాయు",
    "రక్షించు"
  ],

  roaring:[
    "గర్జించు",
    "అరుచు"
  ],

  carrying:[
    "మోయు",
    "తరలించు"
  ],

  collecting:[
    "సేకరించు"
  ],

  hiding:[
    "దాగు",
    "దాక్కో"
  ],

  slithering:[
    "పాకు",
    "మెలికలు తిరుగు"
  ],

  bathing:[
    "స్నానం చేయు"
  ],

  playing:[
    "ఆడు",
    "సరదాగా తిరుగు"
  ],

  flying:[
    "ఎగురు",
    "విహరించు"
  ],

  resting:[
    "విశ్రాంతి తీసుకో",
    "పడుకో"
  ]
};

/* ------------------------------------------
   ANIMALS
------------------------------------------ */

const ANIMALS = [

{telugu:"పిల్లి",english:"Cat",emoji:"🐱",actions:["walking","running","hunting","sleeping"],habitats:["home","city"]},

{telugu:"కుక్క",english:"Dog",emoji:"🐶",actions:["walking","running","guarding","playing"],habitats:["home","farm"]},

{telugu:"ఆవు",english:"Cow",emoji:"🐄",actions:["walking","feeding","resting"],habitats:["farm"]},

{telugu:"గేదె",english:"Buffalo",emoji:"🐃",actions:["walking","feeding","swimming"],habitats:["farm","water"]},

{telugu:"మేక",english:"Goat",emoji:"🐐",actions:["walking","running","feeding"],habitats:["farm","hill"]},

{telugu:"గుర్రం",english:"Horse",emoji:"🐎",actions:["running","walking"],habitats:["farm","grassland"]},

{telugu:"గాడిద",english:"Donkey",emoji:"🫏",actions:["walking","carrying"],habitats:["farm"]},

{telugu:"కోతి",english:"Monkey",emoji:"🐒",actions:["climbing","jumping","playing"],habitats:["forest","tree"]},

{telugu:"ఏనుగు",english:"Elephant",emoji:"🐘",actions:["walking","feeding","bathing"],habitats:["forest"]},

{telugu:"సింహం",english:"Lion",emoji:"🦁",actions:["hunting","running","roaring"],habitats:["grassland"]},

{telugu:"పులి",english:"Tiger",emoji:"🐅",actions:["hunting","running","swimming"],habitats:["forest"]},

{telugu:"జింక",english:"Deer",emoji:"🦌",actions:["running","feeding"],habitats:["forest","grassland"]},

{telugu:"ఎలుక",english:"Rat",emoji:"🐀",actions:["running","hiding"],habitats:["home","city"]},

{telugu:"కుందేలు",english:"Rabbit",emoji:"🐇",actions:["jumping","running"],habitats:["grassland"]},

{telugu:"ఎద్దు",english:"Bull",emoji:"🐂",actions:["walking","running"],habitats:["farm"]},

{telugu:"ఒంటె",english:"Camel",emoji:"🐪",actions:["walking","carrying"],habitats:["desert"]},

{telugu:"పంది",english:"Pig",emoji:"🐖",actions:["feeding","walking"],habitats:["farm"]},

{telugu:"నక్క",english:"Fox",emoji:"🦊",actions:["hunting","running"],habitats:["forest"]},

{telugu:"ఎలుగుబంటి",english:"Bear",emoji:"🐻",actions:["hunting","climbing","walking"],habitats:["forest"]},

{telugu:"చిరుత",english:"Leopard",emoji:"🐆",actions:["hunting","running","climbing"],habitats:["forest"]},

{telugu:"ఉడుత",english:"Squirrel",emoji:"🐿️",actions:["climbing","jumping"],habitats:["tree"]},

{telugu:"తోడేలు",english:"Wolf",emoji:"🐺",actions:["hunting","running"],habitats:["forest"]},

{telugu:"చీమ",english:"Ant",emoji:"🐜",actions:["carrying","walking"],habitats:["ground"]},

{telugu:"తేనెటీగ",english:"Honey Bee",emoji:"🐝",actions:["flying","collecting"],habitats:["garden"]},

{telugu:"సీతాకోకచిలుక",english:"Butterfly",emoji:"🦋",actions:["flying"],habitats:["garden"]},

{telugu:"పాము",english:"Snake",emoji:"🐍",actions:["slithering","hunting"],habitats:["forest"]},

{telugu:"మొసలి",english:"Crocodile",emoji:"🐊",actions:["swimming","hunting"],habitats:["water"]},

{telugu:"తాబేలు",english:"Turtle",emoji:"🐢",actions:["walking","swimming"],habitats:["water"]},

{telugu:"జీబ్రా",english:"Zebra",emoji:"🦓",actions:["running","feeding"],habitats:["grassland"]},

{telugu:"పాండా",english:"Panda",emoji:"🐼",actions:["feeding","climbing","resting"],habitats:["forest"]}

];

/* ------------------------------------------
   ENGINE
------------------------------------------ */

function random(arr){
  return arr[Math.floor(Math.random()*arr.length)];
}

function getVerb(animal){
  const category = random(animal.actions);
  return random(VERB_CATEGORIES[category]);
}

function getPlace(animal){
  const habitat = random(animal.habitats);
  return random(PLACE_CATEGORIES[habitat]);
}

function generateSentence(animal){

  const adjective = random(ADJECTIVES);
  const adverb = random(ADVERBS);
  const place = getPlace(animal);
  const verb = getVerb(animal);

  return `${adjective} ${animal.telugu} ${place}లో ${adverb} ${verb}ింది.`;
}

/* Examples */

console.log(generateSentence(ANIMALS[0]));
console.log(generateSentence(ANIMALS[9]));
console.log(generateSentence(ANIMALS[29]));