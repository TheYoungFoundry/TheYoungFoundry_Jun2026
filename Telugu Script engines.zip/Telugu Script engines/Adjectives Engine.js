/* ==========================================
   ADJECTIVES RELATIONS (1-50)
   Telugu + English + Synonyms + Antonyms
   ========================================== */

const ADJECTIVES_RELATIONS = [

{
word:"అందమైన",
english:"Beautiful",
synonyms:[
{telugu:"సుందరమైన",english:"Lovely"},
{telugu:"మనోహరమైన",english:"Charming"},
{telugu:"ఆకర్షణీయమైన",english:"Attractive"}
],
antonyms:[
{telugu:"అందవిహీనమైన",english:"Ugly"}
]
},

{
word:"పెద్ద",
english:"Big",
synonyms:[
{telugu:"విశాలమైన",english:"Large"},
{telugu:"భారీ",english:"Huge"}
],
antonyms:[
{telugu:"చిన్న",english:"Small"}
]
},

{
word:"చిన్న",
english:"Small",
synonyms:[
{telugu:"పొట్టి",english:"Tiny"},
{telugu:"సూక్ష్మ",english:"Minute"}
],
antonyms:[
{telugu:"పెద్ద",english:"Big"}
]
},

{
word:"పొడవైన",
english:"Tall",
synonyms:[
{telugu:"ఎత్తైన",english:"High"},
{telugu:"దీర్ఘమైన",english:"Long"}
],
antonyms:[
{telugu:"పొట్టి",english:"Short"}
]
},

{
word:"పొట్టి",
english:"Short",
synonyms:[
{telugu:"చిన్న",english:"Small"},
{telugu:"తక్కువ ఎత్తు",english:"Low Height"}
],
antonyms:[
{telugu:"పొడవైన",english:"Tall"}
]
},

{
word:"వేగమైన",
english:"Fast",
synonyms:[
{telugu:"శీఘ్రమైన",english:"Rapid"},
{telugu:"త్వరితమైన",english:"Quick"}
],
antonyms:[
{telugu:"నెమ్మదైన",english:"Slow"}
]
},

{
word:"నెమ్మదైన",
english:"Slow",
synonyms:[
{telugu:"మెల్లని",english:"Gentle"},
{telugu:"ఆలస్యమైన",english:"Delayed"}
],
antonyms:[
{telugu:"వేగమైన",english:"Fast"}
]
},

{
word:"బలమైన",
english:"Strong",
synonyms:[
{telugu:"దృఢమైన",english:"Sturdy"},
{telugu:"శక్తివంతమైన",english:"Powerful"}
],
antonyms:[
{telugu:"బలహీనమైన",english:"Weak"}
]
},

{
word:"బలహీనమైన",
english:"Weak",
synonyms:[
{telugu:"నిస్సహాయమైన",english:"Fragile"},
{telugu:"దుర్బలమైన",english:"Feeble"}
],
antonyms:[
{telugu:"బలమైన",english:"Strong"}
]
},

{
word:"తెలివైన",
english:"Intelligent",
synonyms:[
{telugu:"మేధావి",english:"Wise"},
{telugu:"చురుకైన",english:"Smart"}
],
antonyms:[
{telugu:"మూర్ఖమైన",english:"Foolish"}
]
},

{
word:"మూర్ఖమైన",
english:"Foolish",
synonyms:[
{telugu:"అవివేకమైన",english:"Unwise"},
{telugu:"తెలివితక్కువ",english:"Ignorant"}
],
antonyms:[
{telugu:"తెలివైన",english:"Intelligent"}
]
},

{
word:"మంచి",
english:"Good",
synonyms:[
{telugu:"ఉత్తమమైన",english:"Excellent"},
{telugu:"శ్రేష్ఠమైన",english:"Best"}
],
antonyms:[
{telugu:"చెడు",english:"Bad"}
]
},

{
word:"చెడు",
english:"Bad",
synonyms:[
{telugu:"దుష్టమైన",english:"Evil"},
{telugu:"హానికరమైన",english:"Harmful"}
],
antonyms:[
{telugu:"మంచి",english:"Good"}
]
},

{
word:"శుభ్రమైన",
english:"Clean",
synonyms:[
{telugu:"పరిశుభ్రమైన",english:"Neat"},
{telugu:"నిర్మలమైన",english:"Pure"}
],
antonyms:[
{telugu:"మురికైన",english:"Dirty"}
]
},

{
word:"మురికైన",
english:"Dirty",
synonyms:[
{telugu:"మలినమైన",english:"Unclean"},
{telugu:"అపరిశుభ్రమైన",english:"Impure"}
],
antonyms:[
{telugu:"శుభ్రమైన",english:"Clean"}
]
},

{
word:"వేడి",
english:"Hot",
synonyms:[
{telugu:"ఉష్ణమైన",english:"Warm"},
{telugu:"తాపమైన",english:"Heated"}
],
antonyms:[
{telugu:"చల్లని",english:"Cold"}
]
},

{
word:"చల్లని",
english:"Cold",
synonyms:[
{telugu:"శీతలమైన",english:"Cool"},
{telugu:"హిమసమానమైన",english:"Icy"}
],
antonyms:[
{telugu:"వేడి",english:"Hot"}
]
},

{
word:"తీపి",
english:"Sweet",
synonyms:[
{telugu:"మధురమైన",english:"Pleasant"},
{telugu:"రుచికరమైన",english:"Tasty"}
],
antonyms:[
{telugu:"చేదు",english:"Bitter"}
]
},

{
word:"చేదు",
english:"Bitter",
synonyms:[
{telugu:"వగరు",english:"Bitter"},
{telugu:"తీవ్రమైన",english:"Harsh"}
],
antonyms:[
{telugu:"తీపి",english:"Sweet"}
]
},

{
word:"పులుపు",
english:"Sour",
synonyms:[
{telugu:"అమ్లమైన",english:"Acidic"},
{telugu:"పుల్లటి",english:"Tangy"}
],
antonyms:[
{telugu:"తీపి",english:"Sweet"}
]
},

{
word:"ఉప్పు",
english:"Salty",
synonyms:[
{telugu:"లవణీయమైన",english:"Saline"},
{telugu:"ఉప్పగా",english:"Salted"}
],
antonyms:[
{telugu:"చప్పటి",english:"Bland"}
]
},

{
word:"కొత్త",
english:"New",
synonyms:[
{telugu:"నూతన",english:"Modern"},
{telugu:"తాజా",english:"Fresh"}
],
antonyms:[
{telugu:"పాత",english:"Old"}
]
},

{
word:"పాత",
english:"Old",
synonyms:[
{telugu:"పురాతన",english:"Ancient"},
{telugu:"జీర్ణమైన",english:"Aged"}
],
antonyms:[
{telugu:"కొత్త",english:"New"}
]
},

{
word:"సంతోషమైన",
english:"Happy",
synonyms:[
{telugu:"ఆనందమైన",english:"Joyful"},
{telugu:"ఉల్లాసమైన",english:"Cheerful"}
],
antonyms:[
{telugu:"విచారమైన",english:"Sad"}
]
},

{
word:"విచారమైన",
english:"Sad",
synonyms:[
{telugu:"దుఃఖమైన",english:"Sorrowful"},
{telugu:"బాధాకరమైన",english:"Unhappy"}
],
antonyms:[
{telugu:"సంతోషమైన",english:"Happy"}
]
},

{
word:"ధైర్యమైన",
english:"Brave",
synonyms:[
{telugu:"సాహసవంతమైన",english:"Courageous"},
{telugu:"నిర్భయమైన",english:"Fearless"}
],
antonyms:[
{telugu:"పిరికివాడు",english:"Cowardly"}
]
},

{
word:"భయపడే",
english:"Fearful",
synonyms:[
{telugu:"పిరికివాడు",english:"Cowardly"},
{telugu:"ఆందోళనగల",english:"Anxious"}
],
antonyms:[
{telugu:"ధైర్యమైన",english:"Brave"}
]
},

{
word:"భారీ",
english:"Huge",
synonyms:[
{telugu:"విపరీతమైన",english:"Massive"},
{telugu:"విశాలమైన",english:"Gigantic"}
],
antonyms:[
{telugu:"తేలికైన",english:"Light"}
]
},

{
word:"తేలికైన",
english:"Lightweight",
synonyms:[
{telugu:"సులభమైన",english:"Easy"},
{telugu:"భారం లేని",english:"Weightless"}
],
antonyms:[
{telugu:"భారీ",english:"Heavy"}
]
},

{
word:"ప్రకాశవంతమైన",
english:"Bright",
synonyms:[
{telugu:"మెరిసే",english:"Shining"},
{telugu:"కాంతివంతమైన",english:"Radiant"}
],
antonyms:[
{telugu:"మసక",english:"Dim"}
]
},

{
word:"మసక",
english:"Dim",
synonyms:[
{telugu:"మందమైన",english:"Faint"},
{telugu:"చీకటి",english:"Dark"}
],
antonyms:[
{telugu:"ప్రకాశవంతమైన",english:"Bright"}
]
},

{
word:"సులభమైన",
english:"Easy",
synonyms:[
{telugu:"తేలికైన",english:"Simple"},
{telugu:"సాధారణమైన",english:"Straightforward"}
],
antonyms:[
{telugu:"కష్టమైన",english:"Difficult"}
]
},

{
word:"కష్టమైన",
english:"Difficult",
synonyms:[
{telugu:"సంక్లిష్టమైన",english:"Complex"},
{telugu:"గట్టి",english:"Hard"}
],
antonyms:[
{telugu:"సులభమైన",english:"Easy"}
]
},

{
word:"ధనవంతుడు",
english:"Rich",
synonyms:[
{telugu:"సంపన్నుడు",english:"Wealthy"},
{telugu:"ఐశ్వర్యవంతుడు",english:"Affluent"}
],
antonyms:[
{telugu:"పేద",english:"Poor"}
]
},

{
word:"పేద",
english:"Poor",
synonyms:[
{telugu:"నిర్ధనుడు",english:"Needy"},
{telugu:"బీద",english:"Destitute"}
],
antonyms:[
{telugu:"ధనవంతుడు",english:"Rich"}
]
},

{
word:"పూర్తి",
english:"Complete",
synonyms:[
{telugu:"సంపూర్ణ",english:"Entire"},
{telugu:"మొత్తం",english:"Whole"}
],
antonyms:[
{telugu:"అసంపూర్ణ",english:"Incomplete"}
]
},

{
word:"ఖాళీ",
english:"Empty",
synonyms:[
{telugu:"శూన్యమైన",english:"Vacant"},
{telugu:"నిండని",english:"Blank"}
],
antonyms:[
{telugu:"నిండిన",english:"Filled"}
]
},

{
word:"పచ్చని",
english:"Green",
synonyms:[
{telugu:"హరిత",english:"Verdant"},
{telugu:"ఆకుపచ్చ",english:"Greenish"}
],
antonyms:[
{telugu:"ఎండిపోయిన",english:"Dry"}
]
},

{
word:"ఎరుపు",
english:"Red",
synonyms:[
{telugu:"రక్తవర్ణం",english:"Crimson"},
{telugu:"అరుణం",english:"Scarlet"}
],
antonyms:[
{telugu:"లేతరంగు",english:"Pale"}
]
},

{
word:"నీలం",
english:"Blue",
synonyms:[
{telugu:"ఆకాశవర్ణం",english:"Sky Blue"},
{telugu:"నీలవర్ణం",english:"Azure"}
],
antonyms:[
{telugu:"ఎరుపు",english:"Red"}
]
},

{
word:"ఆరోగ్యకరమైన",
english:"Healthy",
synonyms:[
{telugu:"బలవంతమైన",english:"Fit"},
{telugu:"స్వస్థమైన",english:"Well"}
],
antonyms:[
{telugu:"అనారోగ్యకరమైన",english:"Unhealthy"}
]
},

{
word:"అనారోగ్యకరమైన",
english:"Unhealthy",
synonyms:[
{telugu:"అస్వస్థమైన",english:"Sick"},
{telugu:"రోగగ్రస్తమైన",english:"Diseased"}
],
antonyms:[
{telugu:"ఆరోగ్యకరమైన",english:"Healthy"}
]
},

{
word:"సహాయకమైన",
english:"Helpful",
synonyms:[
{telugu:"ఉపయోగకరమైన",english:"Useful"},
{telugu:"తోడ్పడే",english:"Supportive"}
],
antonyms:[
{telugu:"హానికరమైన",english:"Harmful"}
]
},

{
word:"దయగల",
english:"Kind",
synonyms:[
{telugu:"కరుణగల",english:"Compassionate"},
{telugu:"సౌమ్యమైన",english:"Gentle"}
],
antonyms:[
{telugu:"క్రూరమైన",english:"Cruel"}
]
},

{
word:"కఠినమైన",
english:"Strict",
synonyms:[
{telugu:"గట్టి",english:"Firm"},
{telugu:"దృఢమైన",english:"Rigid"}
],
antonyms:[
{telugu:"మృదువైన",english:"Soft"}
]
},

{
word:"వినయమైన",
english:"Humble",
synonyms:[
{telugu:"నమ్రమైన",english:"Modest"},
{telugu:"సౌమ్యమైన",english:"Polite"}
],
antonyms:[
{telugu:"అహంకారమైన",english:"Arrogant"}
]
},

{
word:"గర్విష్టి",
english:"Proud",
synonyms:[
{telugu:"అహంకారమైన",english:"Arrogant"},
{telugu:"దర్పమైన",english:"Conceited"}
],
antonyms:[
{telugu:"వినయమైన",english:"Humble"}
]
},

{
word:"శాంతమైన",
english:"Calm",
synonyms:[
{telugu:"ప్రశాంతమైన",english:"Peaceful"},
{telugu:"నిశ్చలమైన",english:"Tranquil"}
],
antonyms:[
{telugu:"ఆగ్రహమైన",english:"Angry"}
]
},

{
word:"ఆగ్రహమైన",
english:"Angry",
synonyms:[
{telugu:"కోపోద్రిక్తమైన",english:"Furious"},
{telugu:"రోషపూరితమైన",english:"Enraged"}
],
antonyms:[
{telugu:"శాంతమైన",english:"Calm"}
]
}

];

/* Total: 50 Adjectives */