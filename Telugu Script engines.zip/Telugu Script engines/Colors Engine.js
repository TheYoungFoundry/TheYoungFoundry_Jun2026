/* ==========================================
   TELUGU COLORS ENGINE
   ========================================== */

/* ------------------------------------------
   COLOR CATEGORIES
------------------------------------------ */

const COLOR_CATEGORIES = {

  primary:[
    "ఎరుపు",
    "నీలం",
    "పసుపు"
  ],

  secondary:[
    "ఆకుపచ్చ",
    "నారింజ",
    "ఊదా"
  ],

  neutral:[
    "తెలుపు",
    "నలుపు",
    "బూడిద",
    "క్రీమ్"
  ],

  metallic:[
    "బంగారు",
    "వెండి"
  ],

  light:[
    "లేతనీలం",
    "లేతఆకుపచ్చ",
    "పీచ్",
    "లావెండర్"
  ],

  dark:[
    "ముదురు నీలం",
    "ముదురు ఆకుపచ్చ",
    "మరూన్",
    "ఇండిగో"
  ],

  special:[
    "గులాబీ",
    "కాషాయం",
    "వైలెట్",
    "టర్కాయిస్",
    "గోధుమ"
  ]
};

/* ------------------------------------------
   COLOR PROPERTIES
------------------------------------------ */

const COLOR_PROPERTIES = {

  warm:[
    "శక్తివంతమైన",
    "ఉత్సాహభరితమైన",
    "ప్రకాశవంతమైన"
  ],

  cool:[
    "ప్రశాంతమైన",
    "చల్లని",
    "సహజమైన"
  ],

  neutral:[
    "సాధారణమైన",
    "సున్నితమైన",
    "సమతుల్యమైన"
  ],

  luxury:[
    "అందమైన",
    "విలువైన",
    "ఆకర్షణీయమైన"
  ]
};

/* ------------------------------------------
   COLORS
------------------------------------------ */

const COLORS = [

{
telugu:"ఎరుపు",
english:"Red",
emoji:"🔴",
category:"primary",
examples:["గులాబీ","ఆపిల్","టమాట"],
emotion:"శక్తి"
},

{
telugu:"నీలం",
english:"Blue",
emoji:"🔵",
category:"primary",
examples:["ఆకాశం","సముద్రం"],
emotion:"ప్రశాంతత"
},

{
telugu:"ఆకుపచ్చ",
english:"Green",
emoji:"🟢",
category:"secondary",
examples:["ఆకు","చెట్టు","గడ్డి"],
emotion:"ప్రకృతి"
},

{
telugu:"పసుపు",
english:"Yellow",
emoji:"🟡",
category:"primary",
examples:["సూర్యుడు","అరటి"],
emotion:"ఆనందం"
},

{
telugu:"నారింజ",
english:"Orange",
emoji:"🟠",
category:"secondary",
examples:["నారింజ పండు"],
emotion:"ఉత్సాహం"
},

{
telugu:"గులాబీ",
english:"Pink",
emoji:"🌸",
category:"special",
examples:["పువ్వు"],
emotion:"ప్రేమ"
},

{
telugu:"తెలుపు",
english:"White",
emoji:"⚪",
category:"neutral",
examples:["పాలు","మేఘం"],
emotion:"శాంతి"
},

{
telugu:"నలుపు",
english:"Black",
emoji:"⚫",
category:"neutral",
examples:["కాకి"],
emotion:"బలం"
},

{
telugu:"బూడిద",
english:"Gray",
emoji:"◻️",
category:"neutral",
examples:["రాయి"],
emotion:"సమతుల్యత"
},

{
telugu:"ఊదా",
english:"Purple",
emoji:"🟣",
category:"secondary",
examples:["ద్రాక్ష"],
emotion:"గౌరవం"
},

{
telugu:"గోధుమ",
english:"Brown",
emoji:"🟤",
category:"special",
examples:["మట్టి","చెట్టు కాండం"],
emotion:"స్థిరత్వం"
},

{
telugu:"లేతనీలం",
english:"Light Blue",
emoji:"🔹",
category:"light",
examples:["ఆకాశం"],
emotion:"శాంతి"
},

{
telugu:"లేతఆకుపచ్చ",
english:"Light Green",
emoji:"🍃",
category:"light",
examples:["లేత ఆకులు"],
emotion:"తాజాదనం"
},

{
telugu:"బంగారు",
english:"Gold",
emoji:"🥇",
category:"metallic",
examples:["బంగారం"],
emotion:"విజయం"
},

{
telugu:"వెండి",
english:"Silver",
emoji:"🥈",
category:"metallic",
examples:["వెండి పాత్ర"],
emotion:"విలువ"
},

{
telugu:"కాషాయం",
english:"Saffron",
emoji:"🟧",
category:"special",
examples:["జెండా"],
emotion:"ధైర్యం"
},

{
telugu:"ముదురు నీలం",
english:"Dark Blue",
emoji:"🔷",
category:"dark",
examples:["సముద్రం"],
emotion:"లోతు"
},

{
telugu:"ముదురు ఆకుపచ్చ",
english:"Dark Green",
emoji:"🌲",
category:"dark",
examples:["అడవి"],
emotion:"బలం"
},

{
telugu:"క్రీమ్",
english:"Cream",
emoji:"🤍",
category:"neutral",
examples:["క్రీమ్ రంగు గోడ"],
emotion:"సౌమ్యత"
},

{
telugu:"మరూన్",
english:"Maroon",
emoji:"🔴",
category:"dark",
examples:["మరూన్ వస్త్రం"],
emotion:"గంభీరత"
},

{
telugu:"వైలెట్",
english:"Violet",
emoji:"💜",
category:"special",
examples:["వైలెట్ పువ్వు"],
emotion:"సృజనాత్మకత"
},

{
telugu:"ఇండిగో",
english:"Indigo",
emoji:"🔵",
category:"dark",
examples:["ఇండిగో రంగు వస్త్రం"],
emotion:"జ్ఞానం"
},

{
telugu:"టర్కాయిస్",
english:"Turquoise",
emoji:"🩵",
category:"special",
examples:["రత్నం"],
emotion:"శాంతి"
},

{
telugu:"పీచ్",
english:"Peach",
emoji:"🍑",
category:"light",
examples:["పీచ్ పండు"],
emotion:"మృదుత్వం"
},

{
telugu:"లావెండర్",
english:"Lavender",
emoji:"🪻",
category:"light",
examples:["లావెండర్ పువ్వు"],
emotion:"ప్రశాంతత"
}

];

/* ------------------------------------------
   SENTENCE TEMPLATES
------------------------------------------ */

const COLOR_TEMPLATES = [

"{word} ఒక అందమైన రంగు.",

"{word} రంగు చాలా ఆకర్షణీయంగా ఉంటుంది.",

"{word} ప్రకృతిలో తరచుగా కనిపిస్తుంది.",

"{word} రంగు అందరికీ ఇష్టం.",

"{word} రంగు వస్తువులను మరింత అందంగా చేస్తుంది."
];

/* ------------------------------------------
   QUIZ TEMPLATES
------------------------------------------ */

const COLOR_QUIZZES = [

"ఆకాశం సాధారణంగా ఏ రంగులో ఉంటుంది?",

"గడ్డి ఏ రంగులో ఉంటుంది?",

"సూర్యుడు సాధారణంగా ఏ రంగులో కనిపిస్తాడు?",

"పాలు ఏ రంగులో ఉంటాయి?",

"టమాట ఏ రంగులో ఉంటుంది?"
];

/* ------------------------------------------
   ENGINE
------------------------------------------ */

function random(arr){
  return arr[Math.floor(Math.random()*arr.length)];
}

function generateColorSentence(color){

  let sentence =
    random(COLOR_TEMPLATES);

  return sentence.replace(
    "{word}",
    color.telugu
  );
}

function generateColorDescription(color){

  const example =
    random(color.examples);

  return `${color.telugu} (${color.english}) రంగు ${example}లో కనిపిస్తుంది.`;
}

/* ------------------------------------------
   EXAMPLES
------------------------------------------ */

console.log(generateColorSentence(COLORS[0]));

console.log(generateColorDescription(COLORS[2]));

console.log(generateColorDescription(COLORS[13]));