/* ==========================================
   TELUGU NUMBERS ENGINE
   ========================================== */

/* ------------------------------------------
   NUMBERS 1-30
------------------------------------------ */

const NUMBERS = [

{digit:1,telugu:"ఒకటి",english:"One",emoji:"1️⃣"},
{digit:2,telugu:"రెండు",english:"Two",emoji:"2️⃣"},
{digit:3,telugu:"మూడు",english:"Three",emoji:"3️⃣"},
{digit:4,telugu:"నాలుగు",english:"Four",emoji:"4️⃣"},
{digit:5,telugu:"ఐదు",english:"Five",emoji:"5️⃣"},
{digit:6,telugu:"ఆరు",english:"Six",emoji:"6️⃣"},
{digit:7,telugu:"ఏడు",english:"Seven",emoji:"7️⃣"},
{digit:8,telugu:"ఎనిమిది",english:"Eight",emoji:"8️⃣"},
{digit:9,telugu:"తొమ్మిది",english:"Nine",emoji:"9️⃣"},
{digit:10,telugu:"పది",english:"Ten",emoji:"🔟"},

{digit:11,telugu:"పదకొండు",english:"Eleven"},
{digit:12,telugu:"పన్నెండు",english:"Twelve"},
{digit:13,telugu:"పదమూడు",english:"Thirteen"},
{digit:14,telugu:"పద్నాలుగు",english:"Fourteen"},
{digit:15,telugu:"పదిహేను",english:"Fifteen"},
{digit:16,telugu:"పదహారు",english:"Sixteen"},
{digit:17,telugu:"పదిహేడు",english:"Seventeen"},
{digit:18,telugu:"పద్దెనిమిది",english:"Eighteen"},
{digit:19,telugu:"పంతొమ్మిది",english:"Nineteen"},
{digit:20,telugu:"ఇరవై",english:"Twenty"},

{digit:21,telugu:"ఇరవై ఒకటి",english:"Twenty One"},
{digit:22,telugu:"ఇరవై రెండు",english:"Twenty Two"},
{digit:23,telugu:"ఇరవై మూడు",english:"Twenty Three"},
{digit:24,telugu:"ఇరవై నాలుగు",english:"Twenty Four"},
{digit:25,telugu:"ఇరవై ఐదు",english:"Twenty Five"},
{digit:26,telugu:"ఇరవై ఆరు",english:"Twenty Six"},
{digit:27,telugu:"ఇరవై ఏడు",english:"Twenty Seven"},
{digit:28,telugu:"ఇరవై ఎనిమిది",english:"Twenty Eight"},
{digit:29,telugu:"ఇరవై తొమ్మిది",english:"Twenty Nine"},
{digit:30,telugu:"ముప్పై",english:"Thirty"}

];

/* ------------------------------------------
   TENS
------------------------------------------ */

const TENS = [

{digit:10,telugu:"పది"},
{digit:20,telugu:"ఇరవై"},
{digit:30,telugu:"ముప్పై"},
{digit:40,telugu:"నలభై"},
{digit:50,telugu:"యాభై"},
{digit:60,telugu:"అరవై"},
{digit:70,telugu:"డెబ్బై"},
{digit:80,telugu:"ఎనభై"},
{digit:90,telugu:"తొంభై"},
{digit:100,telugu:"వంద"}

];

/* ------------------------------------------
   BIG NUMBERS
------------------------------------------ */

const BIG_NUMBERS = [

{digit:100,telugu:"వంద"},
{digit:1000,telugu:"వెయ్యి"},
{digit:10000,telugu:"పది వేల"},
{digit:100000,telugu:"లక్ష"},
{digit:10000000,telugu:"కోటి"}

];

/* ------------------------------------------
   ORDINAL NUMBERS
------------------------------------------ */

const ORDINALS = [

{digit:1,telugu:"మొదటి"},
{digit:2,telugu:"రెండవ"},
{digit:3,telugu:"మూడవ"},
{digit:4,telugu:"నాల్గవ"},
{digit:5,telugu:"ఐదవ"},
{digit:6,telugu:"ఆరవ"},
{digit:7,telugu:"ఏడవ"},
{digit:8,telugu:"ఎనిమిదవ"},
{digit:9,telugu:"తొమ్మిదవ"},
{digit:10,telugu:"పదవ"}

];

/* ------------------------------------------
   COUNTABLE OBJECTS
------------------------------------------ */

const COUNTABLES = [

"ఆపిల్",
"పుస్తకం",
"పక్షి",
"పిల్లి",
"కారు",
"పువ్వు",
"చెట్టు",
"బంతి",
"పెన్సిల్",
"విద్యార్థి"

];

/* ------------------------------------------
   SENTENCE TEMPLATES
------------------------------------------ */

const NUMBER_TEMPLATES = [

"{n} {obj}లు ఉన్నాయి.",

"నేను {n} {obj}లు చూశాను.",

"బల్లపై {n} {obj}లు ఉన్నాయి.",

"తరగతిలో {n} {obj}లు ఉన్నాయి.",

"తోటలో {n} {obj}లు ఉన్నాయి."
];

/* ------------------------------------------
   ENGINE
------------------------------------------ */

function random(arr){
  return arr[Math.floor(Math.random()*arr.length)];
}

function generateNumberSentence(){

  const num = random(NUMBERS.slice(0,20));
  const obj = random(COUNTABLES);

  return random(NUMBER_TEMPLATES)
    .replace("{n}",num.telugu)
    .replace("{obj}",obj);
}

function describeNumber(number){

  return `${number.telugu} (${number.digit}) ఒక సంఖ్య.`;
}

/* ------------------------------------------
   EXAMPLES
------------------------------------------ */

console.log(generateNumberSentence());
// మూడు పుస్తకాలు ఉన్నాయి.

console.log(describeNumber(NUMBERS[4]));
// ఐదు (5) ఒక సంఖ్య.

console.log(describeNumber(NUMBERS[19]));
// ఇరవై (20) ఒక సంఖ్య.