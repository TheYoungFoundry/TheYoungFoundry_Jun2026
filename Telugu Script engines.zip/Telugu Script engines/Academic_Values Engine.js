/* ==========================================
   ACADEMIC RELATIONS (1-30)
   Telugu + English + Synonyms + Antonyms
   ========================================== */

const ACADEMIC_RELATIONS = [

{
word:"విద్య",
english:"Education",
synonyms:[
{telugu:"అభ్యాసం",english:"Learning"},
{telugu:"శిక్షణ",english:"Training"}
],
antonyms:[
{telugu:"అజ్ఞానం",english:"Ignorance"}
]
},

{
word:"జ్ఞానం",
english:"Knowledge",
synonyms:[
{telugu:"అవగాహన",english:"Understanding"},
{telugu:"విద్య",english:"Learning"}
],
antonyms:[
{telugu:"అజ్ఞానం",english:"Ignorance"}
]
},

{
word:"అజ్ఞానం",
english:"Ignorance",
synonyms:[
{telugu:"తెలియకపోవడం",english:"Unawareness"},
{telugu:"మూర్ఖత్వం",english:"Foolishness"}
],
antonyms:[
{telugu:"జ్ఞానం",english:"Knowledge"}
]
},

{
word:"పుస్తకం",
english:"Book",
synonyms:[
{telugu:"గ్రంథం",english:"Volume"},
{telugu:"పాఠ్యపుస్తకం",english:"Textbook"}
],
antonyms:[
{telugu:"ఖాళీ పేజీ",english:"Blank Page"}
]
},

{
word:"విద్యార్థి",
english:"Student",
synonyms:[
{telugu:"శిష్యుడు",english:"Pupil"},
{telugu:"అభ్యాసకుడు",english:"Learner"}
],
antonyms:[
{telugu:"ఉపాధ్యాయుడు",english:"Teacher"}
]
},

{
word:"ఉపాధ్యాయుడు",
english:"Teacher",
synonyms:[
{telugu:"గురువు",english:"Mentor"},
{telugu:"అధ్యాపకుడు",english:"Instructor"}
],
antonyms:[
{telugu:"విద్యార్థి",english:"Student"}
]
},

{
word:"పరీక్ష",
english:"Examination",
synonyms:[
{telugu:"టెస్ట్",english:"Test"},
{telugu:"మూల్యాంకనం",english:"Assessment"}
],
antonyms:[
{telugu:"విశ్రాంతి",english:"Break"}
]
},

{
word:"అభ్యాసం",
english:"Practice",
synonyms:[
{telugu:"సాధన",english:"Exercise"},
{telugu:"శిక్షణ",english:"Training"}
],
antonyms:[
{telugu:"నిర్లక్ష్యం",english:"Neglect"}
]
},

{
word:"పరిశోధన",
english:"Research",
synonyms:[
{telugu:"అన్వేషణ",english:"Exploration"},
{telugu:"విచారణ",english:"Investigation"}
],
antonyms:[
{telugu:"అజ్ఞానం",english:"Ignorance"}
]
},

{
word:"అవగాహన",
english:"Understanding",
synonyms:[
{telugu:"గ్రహింపు",english:"Comprehension"},
{telugu:"జ్ఞానం",english:"Knowledge"}
],
antonyms:[
{telugu:"అపార్థం",english:"Misunderstanding"}
]
},

{
word:"విశ్లేషణ",
english:"Analysis",
synonyms:[
{telugu:"పరిశీలన",english:"Examination"},
{telugu:"విమర్శ",english:"Evaluation"}
],
antonyms:[
{telugu:"సంక్షిప్తీకరణ",english:"Oversimplification"}
]
},

{
word:"పరిశీలన",
english:"Observation",
synonyms:[
{telugu:"గమనింపు",english:"Inspection"},
{telugu:"వీక్షణ",english:"Observation"}
],
antonyms:[
{telugu:"అశ్రద్ధ",english:"Neglect"}
]
},

{
word:"ప్రశ్న",
english:"Question",
synonyms:[
{telugu:"సందేహం",english:"Query"},
{telugu:"విచారణ",english:"Inquiry"}
],
antonyms:[
{telugu:"సమాధానం",english:"Answer"}
]
},

{
word:"సమాధానం",
english:"Answer",
synonyms:[
{telugu:"జవాబు",english:"Reply"},
{telugu:"ప్రత్యుత్తరం",english:"Response"}
],
antonyms:[
{telugu:"ప్రశ్న",english:"Question"}
]
},

{
word:"విజ్ఞానం",
english:"Science",
synonyms:[
{telugu:"శాస్త్రం",english:"Scientific Study"},
{telugu:"సైన్స్",english:"Science"}
],
antonyms:[
{telugu:"మూఢనమ్మకం",english:"Superstition"}
]
},

{
word:"గణితం",
english:"Mathematics",
synonyms:[
{telugu:"లెక్కలు",english:"Arithmetic"},
{telugu:"మ్యాథ్స్",english:"Math"}
],
antonyms:[
{telugu:"అనిశ్చితి",english:"Uncertainty"}
]
},

{
word:"చరిత్ర",
english:"History",
synonyms:[
{telugu:"గతచరిత్ర",english:"Past Records"},
{telugu:"ఇతిహాసం",english:"Chronicle"}
],
antonyms:[
{telugu:"భవిష్యత్తు",english:"Future"}
]
},

{
word:"భూగోళశాస్త్రం",
english:"Geography",
synonyms:[
{telugu:"భూవిజ్ఞానం",english:"Earth Studies"},
{telugu:"జియోగ్రఫీ",english:"Geography"}
],
antonyms:[
{telugu:"ఖగోళశాస్త్రం",english:"Astronomy"}
]
},

{
word:"ప్రాజెక్ట్",
english:"Project",
synonyms:[
{telugu:"కార్యక్రమం",english:"Assignment"},
{telugu:"పని",english:"Task"}
],
antonyms:[
{telugu:"విశ్రాంతి",english:"Rest"}
]
},

{
word:"హోంవర్క్",
english:"Homework",
synonyms:[
{telugu:"గృహపాఠం",english:"Home Assignment"},
{telugu:"అభ్యాసపని",english:"Practice Work"}
],
antonyms:[
{telugu:"సెలవు",english:"Holiday"}
]
},

{
word:"గ్రంథాలయం",
english:"Library",
synonyms:[
{telugu:"పుస్తకాలయం",english:"Book House"},
{telugu:"లైబ్రరీ",english:"Library"}
],
antonyms:[
{telugu:"ఖాళీ గది",english:"Empty Room"}
]
},

{
word:"తరగతి",
english:"Classroom",
synonyms:[
{telugu:"క్లాస్",english:"Class"},
{telugu:"బోధనగది",english:"Teaching Room"}
],
antonyms:[
{telugu:"ఆటస్థలం",english:"Playground"}
]
},

{
word:"సర్టిఫికెట్",
english:"Certificate",
synonyms:[
{telugu:"ప్రమాణపత్రం",english:"Credential"},
{telugu:"ధృవీకరణ పత్రం",english:"Certification"}
],
antonyms:[
{telugu:"అనర్హత",english:"Disqualification"}
]
},

{
word:"ల్యాబ్",
english:"Laboratory",
synonyms:[
{telugu:"ప్రయోగశాల",english:"Lab"},
{telugu:"పరిశోధనశాల",english:"Research Lab"}
],
antonyms:[
{telugu:"సిద్ధాంత గది",english:"Theory Room"}
]
},

{
word:"ప్రయోగం",
english:"Experiment",
synonyms:[
{telugu:"పరీక్షణ",english:"Testing"},
{telugu:"అనుభవ పరీక్ష",english:"Trial"}
],
antonyms:[
{telugu:"సిద్ధాంతం",english:"Theory"}
]
},

{
word:"సిలబస్",
english:"Syllabus",
synonyms:[
{telugu:"పాఠ్యప్రణాళిక",english:"Curriculum"},
{telugu:"పాఠ్యాంశాలు",english:"Course Content"}
],
antonyms:[
{telugu:"ప్రణాళికలేమి",english:"No Curriculum"}
]
},

{
word:"అసైన్‌మెంట్",
english:"Assignment",
synonyms:[
{telugu:"పని",english:"Task"},
{telugu:"ప్రాజెక్ట్",english:"Project"}
],
antonyms:[
{telugu:"విశ్రాంతి",english:"Free Time"}
]
},

{
word:"కంప్యూటర్",
english:"Computer",
synonyms:[
{telugu:"గణన యంత్రం",english:"Computing Machine"},
{telugu:"సిస్టమ్",english:"System"}
],
antonyms:[
{telugu:"మానవ గణన",english:"Manual Calculation"}
]
},

{
word:"లక్ష్యం",
english:"Goal",
synonyms:[
{telugu:"గమ్యం",english:"Destination"},
{telugu:"ఉద్దేశ్యం",english:"Objective"}
],
antonyms:[
{telugu:"దిశలేమి",english:"Aimlessness"}
]
},

{
word:"సాధన",
english:"Achievement",
synonyms:[
{telugu:"విజయం",english:"Success"},
{telugu:"ఫలితం",english:"Accomplishment"}
],
antonyms:[
{telugu:"విఫలం",english:"Failure"}
]
}

];

/* ==========================================
   VALUES & LEADERSHIP RELATIONS (1-20)
   ========================================== */

const VALUES_LEADERSHIP_RELATIONS = [

{
word:"నిజాయితీ",
english:"Honesty",
synonyms:[
{telugu:"సత్యనిష్ఠ",english:"Integrity"},
{telugu:"నిక్కచ్చితనం",english:"Truthfulness"}
],
antonyms:[
{telugu:"మోసం",english:"Dishonesty"}
]
},

{
word:"వినయం",
english:"Humility",
synonyms:[
{telugu:"నమ్రత",english:"Modesty"},
{telugu:"సౌమ్యత",english:"Gentleness"}
],
antonyms:[
{telugu:"అహంకారం",english:"Arrogance"}
]
},

{
word:"అహంకారం",
english:"Arrogance",
synonyms:[
{telugu:"గర్వం",english:"Pride"},
{telugu:"దర్పం",english:"Ego"}
],
antonyms:[
{telugu:"వినయం",english:"Humility"}
]
},

{
word:"బాధ్యత",
english:"Responsibility",
synonyms:[
{telugu:"కర్తవ్యం",english:"Duty"},
{telugu:"జవాబుదారీతనం",english:"Accountability"}
],
antonyms:[
{telugu:"నిర్లక్ష్యం",english:"Negligence"}
]
},

{
word:"క్రమశిక్షణ",
english:"Discipline",
synonyms:[
{telugu:"శిస్తు",english:"Order"},
{telugu:"నియమపాలన",english:"Self-Control"}
],
antonyms:[
{telugu:"అశ్రద్ధ",english:"Indiscipline"}
]
},

{
word:"నాయకత్వం",
english:"Leadership",
synonyms:[
{telugu:"మార్గదర్శకత్వం",english:"Guidance"},
{telugu:"నిర్వహణ",english:"Management"}
],
antonyms:[
{telugu:"అనుసరణ",english:"Following"}
]
},

{
word:"సహకారం",
english:"Cooperation",
synonyms:[
{telugu:"తోడ్పాటు",english:"Support"},
{telugu:"సహాయం",english:"Assistance"}
],
antonyms:[
{telugu:"విరోధం",english:"Opposition"}
]
},

{
word:"దయ",
english:"Kindness",
synonyms:[
{telugu:"కరుణ",english:"Compassion"},
{telugu:"సౌమ్యత",english:"Gentleness"}
],
antonyms:[
{telugu:"క్రూరత్వం",english:"Cruelty"}
]
},

{
word:"కరుణ",
english:"Compassion",
synonyms:[
{telugu:"దయ",english:"Kindness"},
{telugu:"సానుభూతి",english:"Empathy"}
],
antonyms:[
{telugu:"కఠినత్వం",english:"Harshness"}
]
},

{
word:"సహనం",
english:"Patience",
synonyms:[
{telugu:"ఓర్పు",english:"Tolerance"},
{telugu:"శాంతం",english:"Calmness"}
],
antonyms:[
{telugu:"అసహనం",english:"Impatience"}
]
},

{
word:"ఓర్పు",
english:"Tolerance",
synonyms:[
{telugu:"సహనం",english:"Patience"},
{telugu:"భరించే శక్తి",english:"Endurance"}
],
antonyms:[
{telugu:"అసహనం",english:"Intolerance"}
]
},

{
word:"నమ్మకం",
english:"Trust",
synonyms:[
{telugu:"విశ్వాసం",english:"Faith"},
{telugu:"ఆధారం",english:"Reliance"}
],
antonyms:[
{telugu:"అవిశ్వాసం",english:"Distrust"}
]
},

{
word:"ఆత్మవిశ్వాసం",
english:"Confidence",
synonyms:[
{telugu:"ధైర్యం",english:"Self-Belief"},
{telugu:"నమ్మకం",english:"Confidence"}
],
antonyms:[
{telugu:"సందేహం",english:"Doubt"}
]
},

{
word:"సంకల్పం",
english:"Determination",
synonyms:[
{telugu:"దృఢనిశ్చయం",english:"Resolve"},
{telugu:"పట్టుదల",english:"Perseverance"}
],
antonyms:[
{telugu:"అనిశ్చితి",english:"Indecision"}
]
},

{
word:"పట్టుదల",
english:"Perseverance",
synonyms:[
{telugu:"సంకల్పం",english:"Determination"},
{telugu:"నిబద్ధత",english:"Dedication"}
],
antonyms:[
{telugu:"వదిలేయడం",english:"Giving Up"}
]
},

{
word:"నిబద్ధత",
english:"Commitment",
synonyms:[
{telugu:"అంకితభావం",english:"Dedication"},
{telugu:"పట్టుదల",english:"Devotion"}
],
antonyms:[
{telugu:"అస్థిరత్వం",english:"Lack of Commitment"}
]
},

{
word:"గౌరవం",
english:"Respect",
synonyms:[
{telugu:"మర్యాద",english:"Courtesy"},
{telugu:"సన్మానం",english:"Honor"}
],
antonyms:[
{telugu:"అవమానం",english:"Disrespect"}
]
},

{
word:"సృజనాత్మకత",
english:"Creativity",
synonyms:[
{telugu:"నవీనత",english:"Innovation"},
{telugu:"కల్పనాశక్తి",english:"Imagination"}
],
antonyms:[
{telugu:"అనుకరణ",english:"Imitation"}
]
},

{
word:"ప్రేరణ",
english:"Inspiration",
synonyms:[
{telugu:"ఉత్సాహం",english:"Motivation"},
{telugu:"ఉద్దీపన",english:"Encouragement"}
],
antonyms:[
{telugu:"నిరుత్సాహం",english:"Discouragement"}
]
},

{
word:"సేవాభావం",
english:"Service Mindset",
synonyms:[
{telugu:"పరోపకారం",english:"Helping Others"},
{telugu:"సేవ",english:"Service"}
],
antonyms:[
{telugu:"స్వార్థం",english:"Selfishness"}
]
}

];

/* Totals
Academic Words: 30
Values & Leadership Words: 20
Grand Total Across All Files:
50 Adjectives
50 Verbs
30 Emotions
30 Academic
20 Values/Leadership

= 180 Vocabulary Relations
*/