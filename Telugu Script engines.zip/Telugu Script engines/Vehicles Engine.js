/* ==========================================
   TELUGU VEHICLES ENGINE
   ========================================== */

/* ------------------------------------------
   VEHICLE CATEGORIES
------------------------------------------ */

const VEHICLE_CATEGORIES = {

  road:[
    "సైకిల్",
    "మోటార్ సైకిల్",
    "కారు",
    "బస్సు",
    "లారీ",
    "ఆటో",
    "రిక్షా",
    "వాన్",
    "జీప్",
    "స్కూటర్",
    "అంబులెన్స్",
    "ఫైర్ ఇంజిన్",
    "ట్యాంకర్",
    "రోలర్"
  ],

  rail:[
    "రైలు",
    "మెట్రో"
  ],

  air:[
    "విమానం",
    "హెలికాప్టర్",
    "రోకెట్"
  ],

  water:[
    "పడవ",
    "ఓడ",
    "సబ్‌మరైన్"
  ],

  construction:[
    "ట్రాక్టర్",
    "బుల్డోజర్",
    "క్రేన్",
    "రోలర్"
  ]

};

/* ------------------------------------------
   VEHICLE ACTIONS
------------------------------------------ */

const VEHICLE_ACTIONS = {

  travel:[
    "ప్రయాణించు",
    "ముందుకు వెళ్లు",
    "గమ్యస్థానానికి చేరుకో"
  ],

  transport:[
    "ప్రయాణికులను తీసుకెళ్ళు",
    "సరుకులు తరలించు",
    "రవాణా చేయు"
  ],

  fly:[
    "ఎగురు",
    "ఆకాశంలో ప్రయాణించు"
  ],

  sail:[
    "నీటిపై ప్రయాణించు",
    "తేలియాడు"
  ],

  rescue:[
    "సహాయం చేయు",
    "ప్రాణాలను కాపాడు"
  ],

  construct:[
    "నిర్మాణ పనులు చేయు",
    "భూమిని చదును చేయు",
    "బరువులు ఎత్తు"
  ]
};

/* ------------------------------------------
   VEHICLES
------------------------------------------ */

const VEHICLES = [

{
telugu:"సైకిల్",
english:"Bicycle",
emoji:"🚲",
category:"road",
speed:"నెమ్మది",
fuel:"లేదు",
actions:["travel"]
},

{
telugu:"మోటార్ సైకిల్",
english:"Motorcycle",
emoji:"🏍️",
category:"road",
speed:"వేగం",
fuel:"పెట్రోల్",
actions:["travel"]
},

{
telugu:"కారు",
english:"Car",
emoji:"🚗",
category:"road",
speed:"వేగం",
fuel:"పెట్రోల్",
actions:["travel","transport"]
},

{
telugu:"బస్సు",
english:"Bus",
emoji:"🚌",
category:"road",
speed:"మధ్యస్థ",
fuel:"డీజిల్",
actions:["transport"]
},

{
telugu:"లారీ",
english:"Truck",
emoji:"🚛",
category:"road",
speed:"మధ్యస్థ",
fuel:"డీజిల్",
actions:["transport"]
},

{
telugu:"ఆటో",
english:"Auto Rickshaw",
emoji:"🛺",
category:"road",
speed:"మధ్యస్థ",
fuel:"పెట్రోల్",
actions:["transport"]
},

{
telugu:"రైలు",
english:"Train",
emoji:"🚆",
category:"rail",
speed:"వేగం",
fuel:"విద్యుత్",
actions:["travel","transport"]
},

{
telugu:"విమానం",
english:"Airplane",
emoji:"✈️",
category:"air",
speed:"చాలా వేగం",
fuel:"విమాన ఇంధనం",
actions:["fly"]
},

{
telugu:"హెలికాప్టర్",
english:"Helicopter",
emoji:"🚁",
category:"air",
speed:"వేగం",
fuel:"విమాన ఇంధనం",
actions:["fly","rescue"]
},

{
telugu:"పడవ",
english:"Boat",
emoji:"🚤",
category:"water",
speed:"నెమ్మది",
fuel:"లేదు",
actions:["sail"]
},

{
telugu:"ఓడ",
english:"Ship",
emoji:"🚢",
category:"water",
speed:"మధ్యస్థ",
fuel:"డీజిల్",
actions:["sail","transport"]
},

{
telugu:"ట్రాక్టర్",
english:"Tractor",
emoji:"🚜",
category:"construction",
speed:"నెమ్మది",
fuel:"డీజిల్",
actions:["construct"]
},

{
telugu:"అంబులెన్స్",
english:"Ambulance",
emoji:"🚑",
category:"road",
speed:"వేగం",
fuel:"డీజిల్",
actions:["rescue"]
},

{
telugu:"ఫైర్ ఇంజిన్",
english:"Fire Engine",
emoji:"🚒",
category:"road",
speed:"వేగం",
fuel:"డీజిల్",
actions:["rescue"]
},

{
telugu:"మెట్రో",
english:"Metro",
emoji:"🚇",
category:"rail",
speed:"వేగం",
fuel:"విద్యుత్",
actions:["transport"]
},

{
telugu:"రిక్షా",
english:"Rickshaw",
emoji:"🛺",
category:"road",
speed:"నెమ్మది",
fuel:"లేదు",
actions:["transport"]
},

{
telugu:"వాన్",
english:"Van",
emoji:"🚐",
category:"road",
speed:"మధ్యస్థ",
fuel:"డీజిల్",
actions:["transport"]
},

{
telugu:"జీప్",
english:"Jeep",
emoji:"🚙",
category:"road",
speed:"వేగం",
fuel:"డీజిల్",
actions:["travel"]
},

{
telugu:"స్కూటర్",
english:"Scooter",
emoji:"🛵",
category:"road",
speed:"మధ్యస్థ",
fuel:"పెట్రోల్",
actions:["travel"]
},

{
telugu:"బుల్డోజర్",
english:"Bulldozer",
emoji:"🚜",
category:"construction",
speed:"నెమ్మది",
fuel:"డీజిల్",
actions:["construct"]
},

{
telugu:"క్రేన్",
english:"Crane",
emoji:"🏗️",
category:"construction",
speed:"నెమ్మది",
fuel:"డీజిల్",
actions:["construct"]
},

{
telugu:"ట్యాంకర్",
english:"Tanker",
emoji:"🚚",
category:"road",
speed:"మధ్యస్థ",
fuel:"డీజిల్",
actions:["transport"]
},

{
telugu:"రోలర్",
english:"Road Roller",
emoji:"🚜",
category:"construction",
speed:"నెమ్మది",
fuel:"డీజిల్",
actions:["construct"]
},

{
telugu:"సబ్‌మరైన్",
english:"Submarine",
emoji:"🚢",
category:"water",
speed:"మధ్యస్థ",
fuel:"అణు శక్తి",
actions:["sail"]
},

{
telugu:"రోకెట్",
english:"Rocket",
emoji:"🚀",
category:"air",
speed:"అత్యంత వేగం",
fuel:"రాకెట్ ఇంధనం",
actions:["fly"]
}

];

/* ------------------------------------------
   SENTENCE TEMPLATES
------------------------------------------ */

const VEHICLE_TEMPLATES = [

"{word} ఒక ముఖ్యమైన రవాణా సాధనం.",

"{word} ప్రయాణానికి ఉపయోగపడుతుంది.",

"{word} ప్రజలను ఒక ప్రదేశం నుండి మరొక ప్రదేశానికి తీసుకెళ్తుంది.",

"{word} ఆధునిక రవాణాలో ముఖ్యమైన పాత్ర పోషిస్తుంది.",

"{word} సమయం ఆదా చేస్తుంది."
];

/* ------------------------------------------
   QUIZ TEMPLATES
------------------------------------------ */

const VEHICLE_QUIZZES = [

"ఆకాశంలో ప్రయాణించే వాహనం ఏది?",

"రైల్వే పట్టాలపై నడిచే వాహనం ఏది?",

"అత్యవసర వైద్య సేవలకు ఉపయోగించే వాహనం ఏది?",

"పొలంలో ఉపయోగించే వాహనం ఏది?",

"నీటిలో ప్రయాణించే వాహనం ఏది?"
];

/* ------------------------------------------
   ENGINE
------------------------------------------ */

function random(arr){
  return arr[Math.floor(Math.random()*arr.length)];
}

function generateVehicleSentence(vehicle){

  return random(VEHICLE_TEMPLATES)
    .replace("{word}", vehicle.telugu);
}

function generateVehicleDescription(vehicle){

  return `${vehicle.telugu} (${vehicle.english}) ఒక ${vehicle.category} వాహనం. దీని వేగం ${vehicle.speed}.`;
}

/* ------------------------------------------
   EXAMPLES
------------------------------------------ */

console.log(generateVehicleSentence(VEHICLES[0]));
// సైకిల్ ఒక ముఖ్యమైన రవాణా సాధనం.

console.log(generateVehicleDescription(VEHICLES[7]));
// విమానం (Airplane) ఒక air వాహనం. దీని వేగం చాలా వేగం.

console.log(generateVehicleDescription(VEHICLES[24]));
// రాకెట్ (Rocket) ఒక air వాహనం. దీని వేగం అత్యంత వేగం.