/* ==========================================
   TELUGU VEGETABLE ENGINE
   ========================================== */

/* ------------------------------------------
   ADJECTIVES
------------------------------------------ */

const VEGETABLE_ADJECTIVES = [
"తాజా",
"ఆరోగ్యకరమైన",
"పోషకమైన",
"రుచికరమైన",
"పచ్చని",
"శుభ్రమైన",
"సహజమైన",
"మృదువైన",
"కరకరలాడే",
"తియ్యని",
"పులుపు",
"కారం",
"విటమిన్లు కలిగిన",
"శక్తినిచ్చే",
"ఆకర్షణీయమైన",
"రంగురంగుల",
"తక్కువ కొవ్వు కలిగిన",
"స్వచ్ఛమైన",
"ఉపయోగకరమైన",
"పండిన"
];

/* ------------------------------------------
   COLORS
------------------------------------------ */

const VEGETABLE_COLORS = [
"ఆకుపచ్చ",
"ఎరుపు",
"పసుపు",
"తెలుపు",
"ఊదా",
"నారింజ రంగు",
"గోధుమ రంగు"
];

/* ------------------------------------------
   TASTES
------------------------------------------ */

const VEGETABLE_TASTES = [
"తీపి",
"పులుపు",
"కారం",
"చేదు",
"రుచికరమైన",
"మృదువైన",
"కరకరలాడే",
"తాజా"
];

/* ------------------------------------------
   SHAPES
------------------------------------------ */

const VEGETABLE_SHAPES = [
"గుండ్రం",
"పొడవైన",
"అండాకారం",
"పెద్ద",
"చిన్న",
"సిలిండర్ ఆకారం"
];

/* ------------------------------------------
   USES
------------------------------------------ */

const VEGETABLE_USES = [
"కూర",
"పప్పు",
"సలాడ్",
"సూప్",
"పచ్చడి",
"ఫ్రై",
"కూరగాయల కూర",
"స్నాక్"
];

/* ------------------------------------------
   VEGETABLES
------------------------------------------ */

const VEGETABLES = [

{
telugu:"టమాట",
english:"Tomato",
emoji:"🍅",
colors:["ఎరుపు"],
tastes:["పులుపు","రుచికరమైన"],
shapes:["గుండ్రం"],
uses:["కూర","సలాడ్","సూప్"]
},

{
telugu:"వంకాయ",
english:"Brinjal",
emoji:"🍆",
colors:["ఊదా"],
tastes:["మృదువైన"],
shapes:["అండాకారం"],
uses:["కూర","ఫ్రై"]
},

{
telugu:"బెండకాయ",
english:"Okra",
emoji:"🟢",
colors:["ఆకుపచ్చ"],
tastes:["మృదువైన"],
shapes:["పొడవైన"],
uses:["కూర","ఫ్రై"]
},

{
telugu:"దొండకాయ",
english:"Ivy Gourd",
emoji:"🥒",
colors:["ఆకుపచ్చ"],
tastes:["రుచికరమైన"],
shapes:["పొడవైన"],
uses:["కూర","ఫ్రై"]
},

{
telugu:"బీరకాయ",
english:"Ridge Gourd",
emoji:"🥒",
colors:["ఆకుపచ్చ"],
tastes:["మృదువైన"],
shapes:["పొడవైన"],
uses:["కూర","పచ్చడి"]
},

{
telugu:"సొరకాయ",
english:"Bottle Gourd",
emoji:"🥒",
colors:["ఆకుపచ్చ"],
tastes:["మృదువైన"],
shapes:["పొడవైన"],
uses:["కూర","సూప్"]
},

{
telugu:"కాకరకాయ",
english:"Bitter Gourd",
emoji:"🥒",
colors:["ఆకుపచ్చ"],
tastes:["చేదు"],
shapes:["పొడవైన"],
uses:["కూర","ఫ్రై"]
},

{
telugu:"గుమ్మడికాయ",
english:"Pumpkin",
emoji:"🎃",
colors:["నారింజ రంగు"],
tastes:["తీపి"],
shapes:["పెద్ద"],
uses:["కూర","సూప్"]
},

{
telugu:"ఉల్లిపాయ",
english:"Onion",
emoji:"🧅",
colors:["తెలుపు","ఊదా"],
tastes:["కారం"],
shapes:["గుండ్రం"],
uses:["కూర","సలాడ్"]
},

{
telugu:"బంగాళదుంప",
english:"Potato",
emoji:"🥔",
colors:["గోధుమ రంగు"],
tastes:["మృదువైన"],
shapes:["అండాకారం"],
uses:["కూర","ఫ్రై","స్నాక్"]
},

{
telugu:"క్యారెట్",
english:"Carrot",
emoji:"🥕",
colors:["నారింజ రంగు"],
tastes:["తీపి"],
shapes:["పొడవైన"],
uses:["సలాడ్","కూర"]
},

{
telugu:"ముల్లంగి",
english:"Radish",
emoji:"🤍",
colors:["తెలుపు"],
tastes:["కారం"],
shapes:["పొడవైన"],
uses:["సలాడ్","కూర"]
},

{
telugu:"చిలగడదుంప",
english:"Sweet Potato",
emoji:"🍠",
colors:["గోధుమ రంగు"],
tastes:["తీపి"],
shapes:["అండాకారం"],
uses:["స్నాక్","కూర"]
},

{
telugu:"క్యాబేజీ",
english:"Cabbage",
emoji:"🥬",
colors:["ఆకుపచ్చ"],
tastes:["తాజా"],
shapes:["గుండ్రం"],
uses:["సలాడ్","కూర"]
},

{
telugu:"కాలీఫ్లవర్",
english:"Cauliflower",
emoji:"🥦",
colors:["తెలుపు"],
tastes:["మృదువైన"],
shapes:["గుండ్రం"],
uses:["కూర","ఫ్రై"]
},

{
telugu:"బఠాణీ",
english:"Peas",
emoji:"🟢",
colors:["ఆకుపచ్చ"],
tastes:["తీపి"],
shapes:["చిన్న"],
uses:["కూర","సూప్"]
},

{
telugu:"మిరపకాయ",
english:"Chilli",
emoji:"🌶️",
colors:["ఎరుపు","ఆకుపచ్చ"],
tastes:["కారం"],
shapes:["పొడవైన"],
uses:["పచ్చడి","కూర"]
},

{
telugu:"పాలకూర",
english:"Spinach",
emoji:"🥬",
colors:["ఆకుపచ్చ"],
tastes:["తాజా"],
shapes:["ఆకు"],
uses:["కూర","పప్పు"]
},

{
telugu:"మెంతికూర",
english:"Fenugreek Leaves",
emoji:"🌿",
colors:["ఆకుపచ్చ"],
tastes:["చేదు"],
shapes:["ఆకు"],
uses:["కూర","పప్పు"]
},

{
telugu:"గోంగూర",
english:"Roselle Leaves",
emoji:"🍃",
colors:["ఆకుపచ్చ"],
tastes:["పులుపు"],
shapes:["ఆకు"],
uses:["పచ్చడి","పప్పు"]
},

{
telugu:"చిక్కుడు",
english:"Broad Beans",
emoji:"🫛",
colors:["ఆకుపచ్చ"],
tastes:["రుచికరమైన"],
shapes:["పొడవైన"],
uses:["కూర"]
},

{
telugu:"బీన్స్",
english:"Beans",
emoji:"🫛",
colors:["ఆకుపచ్చ"],
tastes:["రుచికరమైన"],
shapes:["పొడవైన"],
uses:["కూర"]
},

{
telugu:"మొక్కజొన్న",
english:"Corn",
emoji:"🌽",
colors:["పసుపు"],
tastes:["తీపి"],
shapes:["పొడవైన"],
uses:["స్నాక్","సూప్"]
},

{
telugu:"అల్లం",
english:"Ginger",
emoji:"🫚",
colors:["గోధుమ రంగు"],
tastes:["కారం"],
shapes:["వంకర ఆకారం"],
uses:["పచ్చడి","కూర"]
},

{
telugu:"వెల్లుల్లి",
english:"Garlic",
emoji:"🧄",
colors:["తెలుపు"],
tastes:["కారం"],
shapes:["గుండ్రం"],
uses:["కూర","పచ్చడి"]
},

{
telugu:"బీట్‌రూట్",
english:"Beetroot",
emoji:"🟣",
colors:["ఊదా"],
tastes:["తీపి"],
shapes:["గుండ్రం"],
uses:["సలాడ్","కూర"]
},

{
telugu:"సెలరీ",
english:"Celery",
emoji:"🥬",
colors:["ఆకుపచ్చ"],
tastes:["తాజా"],
shapes:["పొడవైన"],
uses:["సలాడ్","సూప్"]
},

{
telugu:"బ్రోకలీ",
english:"Broccoli",
emoji:"🥦",
colors:["ఆకుపచ్చ"],
tastes:["తాజా"],
shapes:["గుండ్రం"],
uses:["సూప్","కూర"]
},

{
telugu:"లెట్యూస్",
english:"Lettuce",
emoji:"🥬",
colors:["ఆకుపచ్చ"],
tastes:["తాజా"],
shapes:["ఆకు"],
uses:["సలాడ్"]
},

{
telugu:"కీరదోస",
english:"Cucumber",
emoji:"🥒",
colors:["ఆకుపచ్చ"],
tastes:["తాజా"],
shapes:["పొడవైన"],
uses:["సలాడ్"]
},

{
telugu:"దోసకాయ",
english:"Yellow Cucumber",
emoji:"🥒",
colors:["పసుపు"],
tastes:["తాజా"],
shapes:["గుండ్రం"],
uses:["సలాడ్","పచ్చడి"]
},

{
telugu:"పచ్చిమిర్చి",
english:"Green Chilli",
emoji:"🌶️",
colors:["ఆకుపచ్చ"],
tastes:["కారం"],
shapes:["పొడవైన"],
uses:["పచ్చడి","కూర"]
},

{
telugu:"సెనగకాయ",
english:"Chickpea Pod",
emoji:"🫛",
colors:["ఆకుపచ్చ"],
tastes:["రుచికరమైన"],
shapes:["పొడవైన"],
uses:["కూర"]
},

{
telugu:"మష్రూమ్",
english:"Mushroom",
emoji:"🍄",
colors:["తెలుపు"],
tastes:["మృదువైన"],
shapes:["గుండ్రం"],
uses:["సూప్","కూర"]
},

{
telugu:"కరివేపాకు",
english:"Curry Leaves",
emoji:"🌿",
colors:["ఆకుపచ్చ"],
tastes:["సువాసనగల"],
shapes:["ఆకు"],
uses:["కూర","పచ్చడి"]
}

];

/* ------------------------------------------
   ENGINE
------------------------------------------ */

function random(arr){
  return arr[Math.floor(Math.random()*arr.length)];
}

function generateVegetableDescription(vegetable){

  const color = random(vegetable.colors);
  const taste = random(vegetable.tastes);
  const shape = random(vegetable.shapes);
  const use = random(vegetable.uses);

  return `${vegetable.telugu} ఒక ${color} రంగు, ${taste} ${shape} కూరగాయ. దీనిని ${use}లో ఉపయోగిస్తారు.`;
}

/* ------------------------------------------
   EXAMPLES
------------------------------------------ */

console.log(generateVegetableDescription(VEGETABLES[0]));
console.log(generateVegetableDescription(VEGETABLES[10]));
console.log(generateVegetableDescription(VEGETABLES[34]));