/* ==========================================
   TELUGU SCHOOL ENGINE
   ========================================== */

/* ------------------------------------------
   SCHOOL CATEGORIES
------------------------------------------ */

const SCHOOL_CATEGORIES = {

  people:[
    "విద్యార్థి",
    "ఉపాధ్యాయుడు",
    "ప్రిన్సిపాల్",
    "స్నేహితుడు"
  ],

  places:[
    "పాఠశాల",
    "తరగతి",
    "గ్రంథాలయం",
    "ల్యాబ్",
    "గది"
  ],

  stationery:[
    "పెన్సిల్",
    "రబ్బరు",
    "పెన్",
    "స్కేలు",
    "చాక్",
    "నోట్‌బుక్"
  ],

  furniture:[
    "బల్ల",
    "కుర్చీ",
    "బ్లాక్‌బోర్డ్"
  ],

  subjects:[
    "గణితం",
    "విజ్ఞానం"
  ],

  technology:[
    "కంప్యూటర్",
    "ల్యాప్‌టాప్",
    "క్యాల్క్యులేటర్"
  ],

  activities:[
    "హోంవర్క్",
    "పరీక్ష",
    "ప్రాజెక్ట్",
    "పాఠం",
    "ప్రయోగం",
    "అసైన్‌మెంట్",
    "వర్క్‌షీట్"
  ]
};

/* ------------------------------------------
   ACTIONS
------------------------------------------ */

const SCHOOL_ACTIONS = {

  study:[
    "చదువు",
    "నేర్చుకో",
    "అభ్యసించు",
    "అర్థం చేసుకో"
  ],

  write:[
    "వ్రాయు",
    "గమనికలు తీసుకో",
    "సమాధానం వ్రాయు"
  ],

  teach:[
    "బోధించు",
    "వివరించు",
    "సహాయం చేయు"
  ],

  read:[
    "చదువు",
    "పరిశీలించు"
  ],

  calculate:[
    "లెక్కించు",
    "గణించు"
  ],

  experiment:[
    "పరీక్షించు",
    "ప్రయోగం చేయు",
    "గమనించు"
  ]
};

/* ------------------------------------------
   SCHOOL ITEMS
------------------------------------------ */

const SCHOOL = [

{
telugu:"పాఠశాల",
english:"School",
emoji:"🏫",
category:"place",
actions:["study"]
},

{
telugu:"విద్యార్థి",
english:"Student",
emoji:"🧑‍🎓",
category:"person",
actions:["study","write","read"]
},

{
telugu:"ఉపాధ్యాయుడు",
english:"Teacher",
emoji:"👨‍🏫",
category:"person",
actions:["teach","write"]
},

{
telugu:"తరగతి",
english:"Classroom",
emoji:"🏫",
category:"place",
actions:["study"]
},

{
telugu:"పుస్తకం",
english:"Book",
emoji:"📚",
category:"object",
actions:["read"]
},

{
telugu:"పెన్సిల్",
english:"Pencil",
emoji:"✏️",
category:"object",
actions:["write"]
},

{
telugu:"రబ్బరు",
english:"Eraser",
emoji:"🩹",
category:"object",
actions:["write"]
},

{
telugu:"బ్యాగ్",
english:"School Bag",
emoji:"🎒",
category:"object",
actions:["carry"]
},

{
telugu:"బల్ల",
english:"Desk",
emoji:"🪑",
category:"object",
actions:["study"]
},

{
telugu:"కుర్చీ",
english:"Chair",
emoji:"🪑",
category:"object",
actions:["sit"]
},

{
telugu:"బ్లాక్‌బోర్డ్",
english:"Blackboard",
emoji:"⬛",
category:"object",
actions:["teach"]
},

{
telugu:"చాక్",
english:"Chalk",
emoji:"✏️",
category:"object",
actions:["write"]
},

{
telugu:"నోట్‌బుక్",
english:"Notebook",
emoji:"📒",
category:"object",
actions:["write"]
},

{
telugu:"హోంవర్క్",
english:"Homework",
emoji:"📝",
category:"activity",
actions:["study","write"]
},

{
telugu:"పరీక్ష",
english:"Exam",
emoji:"📋",
category:"activity",
actions:["write","study"]
},

{
telugu:"గ్రంథాలయం",
english:"Library",
emoji:"📚",
category:"place",
actions:["read","study"]
},

{
telugu:"ప్రిన్సిపాల్",
english:"Principal",
emoji:"👨‍💼",
category:"person",
actions:["teach"]
},

{
telugu:"స్నేహితుడు",
english:"Friend",
emoji:"👦",
category:"person",
actions:["study"]
},

{
telugu:"గణితం",
english:"Mathematics",
emoji:"➕",
category:"subject",
actions:["calculate","study"]
},

{
telugu:"విజ్ఞానం",
english:"Science",
emoji:"🔬",
category:"subject",
actions:["experiment","study"]
},

{
telugu:"కంప్యూటర్",
english:"Computer",
emoji:"💻",
category:"technology",
actions:["study"]
},

{
telugu:"ల్యాప్‌టాప్",
english:"Laptop",
emoji:"💻",
category:"technology",
actions:["study"]
},

{
telugu:"ప్రాజెక్ట్",
english:"Project",
emoji:"📂",
category:"activity",
actions:["study","write"]
},

{
telugu:"పాఠం",
english:"Lesson",
emoji:"📖",
category:"activity",
actions:["study","read"]
},

{
telugu:"గది",
english:"Room",
emoji:"🏠",
category:"place",
actions:["study"]
},

{
telugu:"క్యాల్క్యులేటర్",
english:"Calculator",
emoji:"🧮",
category:"technology",
actions:["calculate"]
},

{
telugu:"పెన్",
english:"Pen",
emoji:"🖊️",
category:"object",
actions:["write"]
},

{
telugu:"స్కేలు",
english:"Scale",
emoji:"📏",
category:"object",
actions:["measure"]
},

{
telugu:"మ్యాప్",
english:"Map",
emoji:"🗺️",
category:"object",
actions:["read"]
},

{
telugu:"ల్యాబ్",
english:"Laboratory",
emoji:"🔬",
category:"place",
actions:["experiment"]
},

{
telugu:"ప్రయోగం",
english:"Experiment",
emoji:"🧪",
category:"activity",
actions:["experiment"]
},

{
telugu:"సర్టిఫికెట్",
english:"Certificate",
emoji:"📜",
category:"object",
actions:["receive"]
},

{
telugu:"అసైన్‌మెంట్",
english:"Assignment",
emoji:"📄",
category:"activity",
actions:["write","study"]
},

{
telugu:"సిలబస్",
english:"Syllabus",
emoji:"📑",
category:"object",
actions:["read"]
},

{
telugu:"వర్క్‌షీట్",
english:"Worksheet",
emoji:"📋",
category:"activity",
actions:["write","study"]
}

];

/* ------------------------------------------
   SENTENCE GENERATOR
------------------------------------------ */

const SCHOOL_TEMPLATES = [

"{word}తో విద్యార్థి నేర్చుకున్నాడు.",
"{word}ను ఉపాధ్యాయుడు ఉపయోగించాడు.",
"{word}లో పిల్లలు చదువుతున్నారు.",
"{word} విద్యకు చాలా ముఖ్యమైనది.",
"{word} ద్వారా కొత్త విషయాలు తెలుసుకుంటారు."

];

function random(arr){
  return arr[Math.floor(Math.random()*arr.length)];
}

function generateSchoolSentence(item){

  let sentence =
    random(SCHOOL_TEMPLATES);

  return sentence.replace(
    "{word}",
    item.telugu
  );
}

/* ------------------------------------------
   EXAMPLES
------------------------------------------ */

console.log(generateSchoolSentence(SCHOOL[0]));
console.log(generateSchoolSentence(SCHOOL[5]));
console.log(generateSchoolSentence(SCHOOL[20]));