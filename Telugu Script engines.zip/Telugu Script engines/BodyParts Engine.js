/* ==========================================
   TELUGU BODY PARTS ENGINE
   ========================================== */

/* ------------------------------------------
   BODY FUNCTIONS
------------------------------------------ */

const BODY_FUNCTIONS = {

  seeing:[
    "చూడటం",
    "గమనించడం",
    "పరిశీలించడం"
  ],

  hearing:[
    "వినడం",
    "శబ్దాలను గుర్తించడం"
  ],

  smelling:[
    "వాసన చూడటం",
    "సువాసన గుర్తించడం"
  ],

  speaking:[
    "మాట్లాడటం",
    "పలకడం",
    "చెప్పడం"
  ],

  eating:[
    "తినడం",
    "నమలడం",
    "రుచి చూడడం"
  ],

  touching:[
    "తాకడం",
    "పట్టుకోవడం",
    "అనుభూతి చెందడం"
  ],

  walking:[
    "నడవడం",
    "పరుగెత్తడం",
    "దూకడం"
  ],

  thinking:[
    "ఆలోచించడం",
    "గుర్తుంచుకోవడం",
    "నేర్చుకోవడం"
  ],

  pumping:[
    "రక్తాన్ని పంపించడం",
    "శరీరానికి శక్తినివ్వడం"
  ],

  breathing:[
    "శ్వాస తీసుకోవడం",
    "ఆక్సిజన్ అందించడం"
  ]
};

/* ------------------------------------------
   BODY PARTS
------------------------------------------ */

const BODY_PARTS = [

{
telugu:"తల",
english:"Head",
emoji:"🧑",
category:"outer",
functions:["thinking"]
},

{
telugu:"కన్ను",
english:"Eye",
emoji:"👁️",
category:"sense",
functions:["seeing"]
},

{
telugu:"ముక్కు",
english:"Nose",
emoji:"👃",
category:"sense",
functions:["smelling"]
},

{
telugu:"చెవి",
english:"Ear",
emoji:"👂",
category:"sense",
functions:["hearing"]
},

{
telugu:"నోరు",
english:"Mouth",
emoji:"👄",
category:"sense",
functions:["speaking","eating"]
},

{
telugu:"పెదవి",
english:"Lip",
emoji:"👄",
category:"outer",
functions:["speaking"]
},

{
telugu:"పంటి",
english:"Tooth",
emoji:"🦷",
category:"outer",
functions:["eating"]
},

{
telugu:"నాలుక",
english:"Tongue",
emoji:"👅",
category:"sense",
functions:["speaking","eating"]
},

{
telugu:"మెడ",
english:"Neck",
emoji:"🧑",
category:"outer",
functions:["movement"]
},

{
telugu:"భుజం",
english:"Shoulder",
emoji:"💪",
category:"outer",
functions:["movement"]
},

{
telugu:"చేయి",
english:"Hand",
emoji:"✋",
category:"outer",
functions:["touching"]
},

{
telugu:"వేలు",
english:"Finger",
emoji:"☝️",
category:"outer",
functions:["touching"]
},

{
telugu:"గోరు",
english:"Nail",
emoji:"💅",
category:"outer",
functions:["protection"]
},

{
telugu:"ఛాతీ",
english:"Chest",
emoji:"🫁",
category:"outer",
functions:["breathing"]
},

{
telugu:"కడుపు",
english:"Stomach",
emoji:"🍽️",
category:"inner",
functions:["digestion"]
},

{
telugu:"వెన్ను",
english:"Back",
emoji:"🧍",
category:"outer",
functions:["support"]
},

{
telugu:"కాలు",
english:"Leg",
emoji:"🦵",
category:"outer",
functions:["walking"]
},

{
telugu:"మోకాలు",
english:"Knee",
emoji:"🦵",
category:"outer",
functions:["walking"]
},

{
telugu:"పాదం",
english:"Foot",
emoji:"🦶",
category:"outer",
functions:["walking"]
},

{
telugu:"జుట్టు",
english:"Hair",
emoji:"💇",
category:"outer",
functions:["protection"]
},

{
telugu:"కన్నుబొమ్మ",
english:"Eyebrow",
emoji:"👁️",
category:"outer",
functions:["protection"]
},

{
telugu:"గడ్డం",
english:"Beard",
emoji:"🧔",
category:"outer",
functions:["protection"]
},

{
telugu:"చర్మం",
english:"Skin",
emoji:"🖐️",
category:"outer",
functions:["touching"]
},

{
telugu:"గుండె",
english:"Heart",
emoji:"❤️",
category:"inner",
functions:["pumping"]
},

{
telugu:"మెదడు",
english:"Brain",
emoji:"🧠",
category:"inner",
functions:["thinking"]
},

{
telugu:"మణికట్టు",
english:"Wrist",
emoji:"✋",
category:"outer",
functions:["movement"]
},

{
telugu:"మోచేయి",
english:"Elbow",
emoji:"💪",
category:"outer",
functions:["movement"]
},

{
telugu:"మడమ",
english:"Heel",
emoji:"🦶",
category:"outer",
functions:["walking"]
},

{
telugu:"పిక్క",
english:"Cheek",
emoji:"😊",
category:"outer",
functions:["speaking"]
},

{
telugu:"పలుకు",
english:"Speech",
emoji:"🗣️",
category:"ability",
functions:["speaking"]
},

{
telugu:"రక్తం",
english:"Blood",
emoji:"🩸",
category:"inner",
functions:["pumping"]
},

{
telugu:"ఎముక",
english:"Bone",
emoji:"🦴",
category:"inner",
functions:["support"]
},

{
telugu:"నరం",
english:"Nerve",
emoji:"⚡",
category:"inner",
functions:["thinking"]
},

{
telugu:"ఊపిరితిత్తి",
english:"Lung",
emoji:"🫁",
category:"inner",
functions:["breathing"]
},

{
telugu:"కాలేయం",
english:"Liver",
emoji:"🫀",
category:"inner",
functions:["digestion"]
}

];

/* ------------------------------------------
   BODY SENTENCE TEMPLATES
------------------------------------------ */

const BODY_TEMPLATES = [

"{word} మన శరీరంలో ముఖ్యమైన భాగం.",

"{word} ద్వారా మనం చాలా పనులు చేస్తాము.",

"{word} ఆరోగ్యంగా ఉండాలి.",

"{word} శరీరానికి ఉపయోగపడుతుంది.",

"{word} మన దైనందిన జీవితంలో ముఖ్యమైనది."
];

/* ------------------------------------------
   QUIZ TEMPLATES
------------------------------------------ */

const BODY_QUIZZES = [

"మనం చూడటానికి ఏ భాగం ఉపయోగిస్తాము?",

"మనం వినటానికి ఏ భాగం ఉపయోగిస్తాము?",

"మనం నడవటానికి ఏ భాగం ఉపయోగిస్తాము?",

"మనం ఆలోచించటానికి ఏ భాగం ఉపయోగిస్తాము?",

"మనం వాసన చూడటానికి ఏ భాగం ఉపయోగిస్తాము?"
];

/* ------------------------------------------
   ENGINE
------------------------------------------ */

function random(arr){
  return arr[Math.floor(Math.random()*arr.length)];
}

function generateBodySentence(part){

  let sentence =
    random(BODY_TEMPLATES);

  return sentence.replace(
    "{word}",
    part.telugu
  );
}

function generateBodyDescription(part){

  return `${part.telugu} (${part.english}) శరీరంలోని ఒక ముఖ్యమైన భాగం.`;
}

/* ------------------------------------------
   EXAMPLES
------------------------------------------ */

console.log(generateBodySentence(BODY_PARTS[0]));
console.log(generateBodySentence(BODY_PARTS[1]));
console.log(generateBodyDescription(BODY_PARTS[24]));