/* ==========================================
   TELUGU FESTIVALS ENGINE
   ========================================== */

/* ------------------------------------------
   FESTIVAL CATEGORIES
------------------------------------------ */

const FESTIVAL_CATEGORIES = {

  hindu:[
    "సంక్రాంతి",
    "ఉగాది",
    "దీపావళి",
    "దసరా",
    "వినాయక చవితి",
    "శ్రీరామనవమి",
    "కృష్ణాష్టమి",
    "మహాశివరాత్రి",
    "నవరాత్రులు",
    "కనుమ",
    "భోగి",
    "ముక్కోటి ఏకాదశి",
    "గణేష్ ఉత్సవం",
    "గురు పౌర్ణిమ",
    "వైకుంఠ ఏకాదశి",
    "కార్తీక దీపోత్సవం",
    "నాగుల చవితి",
    "వరలక్ష్మీ వ్రతం",
    "అట్ల తద్దె",
    "రథసప్తమి",
    "హనుమజ్జయంతి",
    "సుబ్రహ్మణ్య షష్ఠి"
  ],

  muslim:[
    "రంజాన్",
    "బక్రీద్"
  ],

  christian:[
    "క్రిస్మస్",
    "ఈస్టర్"
  ],

  cultural:[
    "హోలీ",
    "రాఖీ",
    "బతుకమ్మ",
    "బోనాలు"
  ]

};

/* ------------------------------------------
   FESTIVAL ACTIVITIES
------------------------------------------ */

const FESTIVAL_ACTIVITIES = {

  celebration:[
    "జరుపుకొను",
    "ఆనందించు",
    "కుటుంబంతో గడపు"
  ],

  prayer:[
    "పూజచేయు",
    "ప్రార్థించు",
    "దేవుడిని ఆరాధించు"
  ],

  decoration:[
    "అలంకరించు",
    "ముగ్గులు వేయు",
    "దీపాలు వెలిగించు"
  ],

  sharing:[
    "స్వీట్లు పంచు",
    "బహుమతులు ఇవ్వు",
    "శుభాకాంక్షలు చెప్పు"
  ],

  cultural:[
    "పాటలు పాడు",
    "నృత్యం చేయు",
    "సాంప్రదాయ కార్యక్రమాల్లో పాల్గొను"
  ]
};

/* ------------------------------------------
   FESTIVALS
------------------------------------------ */

const FESTIVALS = [

{
telugu:"సంక్రాంతి",
english:"Sankranti",
emoji:"🪁",
category:"hindu",
season:"జనవరి",
activities:["celebration","decoration","sharing"]
},

{
telugu:"ఉగాది",
english:"Ugadi",
emoji:"🌿",
category:"hindu",
season:"మార్చి/ఏప్రిల్",
activities:["celebration","prayer"]
},

{
telugu:"దీపావళి",
english:"Diwali",
emoji:"🪔",
category:"hindu",
season:"అక్టోబర్/నవంబర్",
activities:["decoration","celebration","sharing"]
},

{
telugu:"దసరా",
english:"Dasara",
emoji:"🏹",
category:"hindu",
season:"అక్టోబర్",
activities:["celebration","prayer"]
},

{
telugu:"వినాయక చవితి",
english:"Vinayaka Chavithi",
emoji:"🐘",
category:"hindu",
season:"ఆగస్టు/సెప్టెంబర్",
activities:["prayer","celebration"]
},

{
telugu:"శ్రీరామనవమి",
english:"Sri Rama Navami",
emoji:"🏹",
category:"hindu",
season:"మార్చి/ఏప్రిల్",
activities:["prayer"]
},

{
telugu:"కృష్ణాష్టమి",
english:"Krishna Janmashtami",
emoji:"🦚",
category:"hindu",
season:"ఆగస్టు",
activities:["prayer","celebration"]
},

{
telugu:"హోలీ",
english:"Holi",
emoji:"🎨",
category:"cultural",
season:"మార్చి",
activities:["celebration","cultural"]
},

{
telugu:"రాఖీ",
english:"Raksha Bandhan",
emoji:"🎀",
category:"cultural",
season:"ఆగస్టు",
activities:["sharing"]
},

{
telugu:"బక్రీద్",
english:"Bakrid",
emoji:"🌙",
category:"muslim",
season:"ఇస్లామిక్ క్యాలెండర్",
activities:["prayer","sharing"]
},

{
telugu:"రంజాన్",
english:"Ramadan",
emoji:"☪️",
category:"muslim",
season:"ఇస్లామిక్ క్యాలెండర్",
activities:["prayer"]
},

{
telugu:"క్రిస్మస్",
english:"Christmas",
emoji:"🎄",
category:"christian",
season:"డిసెంబర్",
activities:["celebration","sharing"]
},

{
telugu:"ఈస్టర్",
english:"Easter",
emoji:"✝️",
category:"christian",
season:"మార్చి/ఏప్రిల్",
activities:["prayer","celebration"]
},

{
telugu:"మహాశివరాత్రి",
english:"Maha Shivaratri",
emoji:"🔱",
category:"hindu",
season:"ఫిబ్రవరి/మార్చి",
activities:["prayer"]
},

{
telugu:"నవరాత్రులు",
english:"Navaratri",
emoji:"🪔",
category:"hindu",
season:"సెప్టెంబర్/అక్టోబర్",
activities:["prayer","cultural"]
},

{
telugu:"బతుకమ్మ",
english:"Bathukamma",
emoji:"🌺",
category:"cultural",
season:"సెప్టెంబర్/అక్టోబర్",
activities:["cultural","celebration"]
},

{
telugu:"బోనాలు",
english:"Bonalu",
emoji:"🥘",
category:"cultural",
season:"జూలై",
activities:["prayer","celebration"]
},

{
telugu:"కనుమ",
english:"Kanuma",
emoji:"🐄",
category:"hindu",
season:"జనవరి",
activities:["celebration"]
},

{
telugu:"భోగి",
english:"Bhogi",
emoji:"🔥",
category:"hindu",
season:"జనవరి",
activities:["celebration"]
},

{
telugu:"ముక్కోటి ఏకాదశి",
english:"Mukkoti Ekadashi",
emoji:"🛕",
category:"hindu",
season:"డిసెంబర్/జనవరి",
activities:["prayer"]
},

{
telugu:"గణేష్ ఉత్సవం",
english:"Ganesh Utsavam",
emoji:"🐘",
category:"hindu",
season:"సెప్టెంబర్",
activities:["prayer","celebration"]
},

{
telugu:"గురు పౌర్ణిమ",
english:"Guru Purnima",
emoji:"🙏",
category:"hindu",
season:"జూలై",
activities:["prayer"]
},

{
telugu:"వైకుంఠ ఏకాదశి",
english:"Vaikuntha Ekadashi",
emoji:"🚪",
category:"hindu",
season:"డిసెంబర్/జనవరి",
activities:["prayer"]
},

{
telugu:"కార్తీక దీపోత్సవం",
english:"Karthika Deepotsavam",
emoji:"🪔",
category:"hindu",
season:"నవంబర్",
activities:["decoration","prayer"]
},

{
telugu:"నాగుల చవితి",
english:"Nagula Chavithi",
emoji:"🐍",
category:"hindu",
season:"నవంబర్",
activities:["prayer"]
},

{
telugu:"వరలక్ష్మీ వ్రతం",
english:"Varalakshmi Vratham",
emoji:"🌺",
category:"hindu",
season:"ఆగస్టు",
activities:["prayer"]
},

{
telugu:"అట్ల తద్దె",
english:"Atla Tadde",
emoji:"🥞",
category:"hindu",
season:"అక్టోబర్",
activities:["celebration"]
},

{
telugu:"రథసప్తమి",
english:"Ratha Saptami",
emoji:"☀️",
category:"hindu",
season:"ఫిబ్రవరి",
activities:["prayer"]
},

{
telugu:"హనుమజ్జయంతి",
english:"Hanuman Jayanti",
emoji:"🐒",
category:"hindu",
season:"ఏప్రిల్",
activities:["prayer"]
},

{
telugu:"సుబ్రహ్మణ్య షష్ఠి",
english:"Subrahmanya Shashti",
emoji:"🦚",
category:"hindu",
season:"డిసెంబర్",
activities:["prayer"]
}

];

/* ------------------------------------------
   SENTENCE TEMPLATES
------------------------------------------ */

const FESTIVAL_TEMPLATES = [

"{word} ఒక ప్రముఖ పండుగ.",

"{word}ను ప్రజలు ఎంతో ఆనందంగా జరుపుకుంటారు.",

"{word} సమయంలో కుటుంబ సభ్యులు కలిసి పండుగను ఆస్వాదిస్తారు.",

"{word} భారతదేశంలో ప్రసిద్ధమైన పండుగ.",

"{word} సాంప్రదాయం మరియు సంస్కృతిని ప్రతిబింబిస్తుంది."
];

/* ------------------------------------------
   DESCRIPTION ENGINE
------------------------------------------ */

function random(arr){
  return arr[Math.floor(Math.random()*arr.length)];
}

function generateFestivalSentence(festival){

  let sentence =
    random(FESTIVAL_TEMPLATES);

  return sentence.replace(
    "{word}",
    festival.telugu
  );
}

function generateFestivalDescription(festival){

  return `${festival.telugu} (${festival.english}) ${festival.season}లో జరుపుకునే ${festival.category} పండుగ.`;
}

/* ------------------------------------------
   EXAMPLES
------------------------------------------ */

console.log(generateFestivalSentence(FESTIVALS[0]));

console.log(generateFestivalDescription(FESTIVALS[2]));

console.log(generateFestivalDescription(FESTIVALS[15]));