/* ==========================================
   TELUGU SEASONS ENGINE
   ========================================== */

/* ------------------------------------------
   SEASON CATEGORIES
------------------------------------------ */

const SEASON_CATEGORIES = {

  spring:[
    "వసంత ఋతువు"
  ],

  summer:[
    "గ్రీష్మ ఋతువు"
  ],

  monsoon:[
    "వర్షాకాలం"
  ],

  autumn:[
    "శరదృతువు"
  ],

  prewinter:[
    "హేమంత ఋతువు"
  ],

  winter:[
    "శిశిర ఋతువు"
  ]

};

/* ------------------------------------------
   SEASONS
------------------------------------------ */

const SEASONS = [

{
telugu:"వసంత ఋతువు",
english:"Spring",
emoji:"🌸",
months:["ఫాల్గుణం","చైత్రం"],
weather:["చల్లని","ఆహ్లాదకరమైన"],
nature:["పూలు పూస్తాయి","చెట్లు పచ్చగా మారుతాయి"],
activities:["విహారయాత్ర","తోటపని"]
},

{
telugu:"గ్రీష్మ ఋతువు",
english:"Summer",
emoji:"☀️",
months:["వైశాఖం","జ్యేష్ఠం"],
weather:["వేడి","ఎండ"],
nature:["సూర్యకాంతి ఎక్కువగా ఉంటుంది"],
activities:["మామిడి పండ్లు తినడం","చల్లని పానీయాలు తాగడం"]
},

{
telugu:"వర్షాకాలం",
english:"Monsoon",
emoji:"🌧️",
months:["ఆషాఢం","శ్రావణం"],
weather:["వర్షం","తేమ"],
nature:["చెట్లు పచ్చగా ఉంటాయి","నదులు నిండుతాయి"],
activities:["గొడుగు ఉపయోగించడం","వర్షంలో ఆడటం"]
},

{
telugu:"శరదృతువు",
english:"Autumn",
emoji:"🍂",
months:["భాద్రపదం","ఆశ్వయుజం"],
weather:["మధ్యస్థ ఉష్ణోగ్రత"],
nature:["ఆకులు రాలుతాయి"],
activities:["పండుగలు జరుపుకోవడం"]
},

{
telugu:"హేమంత ఋతువు",
english:"Pre-Winter",
emoji:"🌾",
months:["కార్తీకం","మార్గశిరం"],
weather:["చల్లని వాతావరణం"],
nature:["పంటలు పండుతాయి"],
activities:["వ్యవసాయ పనులు"]
},

{
telugu:"శిశిర ఋతువు",
english:"Winter",
emoji:"❄️",
months:["పుష్యం","మాఘం"],
weather:["చలి","మంచు"],
nature:["ఉదయాన్నే పొగమంచు ఉంటుంది"],
activities:["వెచ్చని దుస్తులు ధరించడం"]
}

];

/* ------------------------------------------
   WEATHER WORDS
------------------------------------------ */

const WEATHER_WORDS = [

"ఎండ",
"వర్షం",
"చలి",
"గాలి",
"మంచు",
"తేమ",
"సూర్యకాంతి",
"పొగమంచు"

];

/* ------------------------------------------
   SEASON ACTIVITIES
------------------------------------------ */

const SEASON_ACTIVITIES = [

"పండుగలు జరుపుకోవడం",
"వ్యవసాయం చేయడం",
"పండ్లు తినడం",
"ప్రయాణాలు చేయడం",
"తోటపని చేయడం",
"ఆటలు ఆడడం",
"వర్షంలో ఆడడం",
"వెచ్చని దుస్తులు ధరించడం"

];

/* ------------------------------------------
   SENTENCE TEMPLATES
------------------------------------------ */

const SEASON_TEMPLATES = [

"{word} సంవత్సరంలోని ముఖ్యమైన ఋతువు.",

"{word} సమయంలో వాతావరణంలో మార్పులు కనిపిస్తాయి.",

"{word} ప్రకృతిని అందంగా మారుస్తుంది.",

"{word}లో ప్రత్యేకమైన కార్యకలాపాలు జరుగుతాయి.",

"{word} ప్రతి సంవత్సరం వస్తుంది."
];

/* ------------------------------------------
   QUIZ QUESTIONS
------------------------------------------ */

const SEASON_QUIZZES = [

"ఎండ ఎక్కువగా ఉండే ఋతువు ఏది?",

"వర్షాలు ఎక్కువగా పడే ఋతువు ఏది?",

"చలి ఎక్కువగా ఉండే ఋతువు ఏది?",

"పూలు ఎక్కువగా పూసే ఋతువు ఏది?",

"మామిడి పండ్లు ఎక్కువగా వచ్చే ఋతువు ఏది?"
];

/* ------------------------------------------
   ENGINE
------------------------------------------ */

function random(arr){
  return arr[Math.floor(Math.random()*arr.length)];
}

function generateSeasonSentence(season){

  return random(SEASON_TEMPLATES)
    .replace("{word}", season.telugu);
}

function generateSeasonDescription(season){

  const weather =
    random(season.weather);

  return `${season.telugu} (${season.english}) సమయంలో సాధారణంగా ${weather} వాతావరణం ఉంటుంది.`;
}

function generateSeasonFact(season){

  const fact =
    random(season.nature);

  return `${season.telugu}లో ${fact}.`;
}

/* ------------------------------------------
   EXAMPLES
------------------------------------------ */

console.log(generateSeasonSentence(SEASONS[0]));
// వసంత ఋతువు సంవత్సరంలోని ముఖ్యమైన ఋతువు.

console.log(generateSeasonDescription(SEASONS[2]));
// వర్షాకాలం (Monsoon) సమయంలో సాధారణంగా వర్షం వాతావరణం ఉంటుంది.

console.log(generateSeasonFact(SEASONS[1]));
// గ్రీష్మ ఋతువులో సూర్యకాంతి ఎక్కువగా ఉంటుంది.