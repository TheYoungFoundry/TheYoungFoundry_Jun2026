/* ==========================================
   TELUGU NATURE ENGINE
   ========================================== */

/* ------------------------------------------
   NATURE CATEGORIES
------------------------------------------ */

const NATURE_CATEGORIES = {

  sky:[
    "సూర్యుడు",
    "చంద్రుడు",
    "నక్షత్రం",
    "ఆకాశం",
    "మేఘం",
    "ఇంద్రధనుస్సు"
  ],

  weather:[
    "వర్షం",
    "గాలి",
    "తుఫాను",
    "మెరుపు",
    "ఉరుము",
    "మంచు",
    "సూర్యకాంతి",
    "సమీరము"
  ],

  water:[
    "నది",
    "సముద్రం",
    "చెరువు",
    "జలపాతం"
  ],

  land:[
    "భూమి",
    "రాయి",
    "ఇసుక",
    "కొండ",
    "పర్వతం"
  ],

  plants:[
    "చెట్టు",
    "పువ్వు",
    "ఆకు",
    "అడవి"
  ],

  seasons:[
    "వసంతం",
    "గ్రీష్మం",
    "వర్షాకాలం",
    "శరదృతువు",
    "హేమంతం",
    "శీతాకాలం"
  ],

  light:[
    "వెలుగు",
    "చీకటి"
  ]

};

/* ------------------------------------------
   ADJECTIVES
------------------------------------------ */

const NATURE_ADJECTIVES = [

"అందమైన",
"విశాలమైన",
"ప్రకాశవంతమైన",
"శాంతమైన",
"సహజమైన",
"ఆకర్షణీయమైన",
"రంగురంగుల",
"సుందరమైన",
"పచ్చని",
"చల్లని",
"వెచ్చని",
"మృదువైన",
"గంభీరమైన",
"అద్భుతమైన",
"మనోహరమైన",
"ప్రశాంతమైన",
"స్వచ్ఛమైన",
"విశిష్టమైన",
"మెరిసే",
"శోభాయమానమైన"

];

/* ------------------------------------------
   ACTIONS
------------------------------------------ */

const NATURE_ACTIONS = {

  shine:[
    "ప్రకాశించు",
    "మెరవు",
    "వెలుగునివ్వు"
  ],

  flow:[
    "ప్రవహించు",
    "ముందుకు సాగు",
    "వంపులు తిరుగు"
  ],

  grow:[
    "పెరుగు",
    "వికసించు",
    "అభివృద్ధి చెందు"
  ],

  fall:[
    "పడు",
    "కురియు",
    "కిందకు రా"
  ],

  blow:[
    "వీసు",
    "వేగంగా కదులు",
    "చుట్టూ వ్యాపించు"
  ],

  bloom:[
    "పూయు",
    "వికసించు",
    "పరిమళించు"
  ],

  rise:[
    "ఉదయించు",
    "పైకి ఎగసిపోవు",
    "కనిపించు"
  ],

  change:[
    "మార్పు చెందు",
    "రూపాంతరం చెందు",
    "మారుతూ ఉండు"
  ]

};

/* ------------------------------------------
   NATURE ITEMS
------------------------------------------ */

const NATURE = [

{
telugu:"సూర్యుడు",
english:"Sun",
emoji:"☀️",
category:"sky",
actions:["shine","rise"]
},

{
telugu:"చంద్రుడు",
english:"Moon",
emoji:"🌙",
category:"sky",
actions:["shine","rise"]
},

{
telugu:"నక్షత్రం",
english:"Star",
emoji:"⭐",
category:"sky",
actions:["shine"]
},

{
telugu:"ఆకాశం",
english:"Sky",
emoji:"🌌",
category:"sky",
actions:["change"]
},

{
telugu:"మేఘం",
english:"Cloud",
emoji:"☁️",
category:"sky",
actions:["change","fall"]
},

{
telugu:"వర్షం",
english:"Rain",
emoji:"🌧️",
category:"weather",
actions:["fall"]
},

{
telugu:"గాలి",
english:"Wind",
emoji:"💨",
category:"weather",
actions:["blow"]
},

{
telugu:"నది",
english:"River",
emoji:"🏞️",
category:"water",
actions:["flow"]
},

{
telugu:"సముద్రం",
english:"Sea",
emoji:"🌊",
category:"water",
actions:["flow"]
},

{
telugu:"కొండ",
english:"Hill",
emoji:"⛰️",
category:"land",
actions:["change"]
},

{
telugu:"చెట్టు",
english:"Tree",
emoji:"🌳",
category:"plants",
actions:["grow"]
},

{
telugu:"పువ్వు",
english:"Flower",
emoji:"🌸",
category:"plants",
actions:["bloom"]
},

{
telugu:"ఆకు",
english:"Leaf",
emoji:"🍃",
category:"plants",
actions:["grow","fall"]
},

{
telugu:"అడవి",
english:"Forest",
emoji:"🌲",
category:"plants",
actions:["grow"]
},

{
telugu:"భూమి",
english:"Earth",
emoji:"🌍",
category:"land",
actions:["change"]
},

{
telugu:"రాయి",
english:"Rock",
emoji:"🪨",
category:"land",
actions:["change"]
},

{
telugu:"ఇసుక",
english:"Sand",
emoji:"🏖️",
category:"land",
actions:["change"]
},

{
telugu:"చెరువు",
english:"Pond",
emoji:"🏞️",
category:"water",
actions:["flow"]
},

{
telugu:"జలపాతం",
english:"Waterfall",
emoji:"🌊",
category:"water",
actions:["flow","fall"]
},

{
telugu:"సూర్యకాంతి",
english:"Sunlight",
emoji:"☀️",
category:"weather",
actions:["shine"]
},

{
telugu:"ఇంద్రధనుస్సు",
english:"Rainbow",
emoji:"🌈",
category:"sky",
actions:["shine"]
},

{
telugu:"తుఫాను",
english:"Storm",
emoji:"🌪️",
category:"weather",
actions:["blow"]
},

{
telugu:"మెరుపు",
english:"Lightning",
emoji:"⚡",
category:"weather",
actions:["shine"]
},

{
telugu:"ఉరుము",
english:"Thunder",
emoji:"⛈️",
category:"weather",
actions:["change"]
},

{
telugu:"మంచు",
english:"Snow",
emoji:"❄️",
category:"weather",
actions:["fall"]
},

{
telugu:"వెలుగు",
english:"Light",
emoji:"💡",
category:"light",
actions:["shine"]
},

{
telugu:"చీకటి",
english:"Darkness",
emoji:"🌑",
category:"light",
actions:["change"]
},

{
telugu:"వసంతం",
english:"Spring",
emoji:"🌷",
category:"season",
actions:["grow","bloom"]
},

{
telugu:"గ్రీష్మం",
english:"Summer",
emoji:"☀️",
category:"season",
actions:["shine"]
},

{
telugu:"శరదృతువు",
english:"Autumn",
emoji:"🍂",
category:"season",
actions:["fall"]
},

{
telugu:"హేమంతం",
english:"Pre-Winter",
emoji:"🌾",
category:"season",
actions:["change"]
},

{
telugu:"శీతాకాలం",
english:"Winter",
emoji:"❄️",
category:"season",
actions:["fall"]
},

{
telugu:"వర్షాకాలం",
english:"Monsoon",
emoji:"🌧️",
category:"season",
actions:["fall"]
},

{
telugu:"సమీరము",
english:"Breeze",
emoji:"🍃",
category:"weather",
actions:["blow"]
},

{
telugu:"పర్వతం",
english:"Mountain",
emoji:"🏔️",
category:"land",
actions:["change"]
}

];

/* ------------------------------------------
   SENTENCE TEMPLATES
------------------------------------------ */

const NATURE_TEMPLATES = [

"{word} ప్రకృతిలో ఒక అందమైన భాగం.",

"{word} మనకు చాలా ఉపయోగకరమైనది.",

"{word} ప్రకృతిని మరింత అందంగా చేస్తుంది.",

"{word} మన జీవితానికి ముఖ్యమైనది.",

"{word} సహజసిద్ధమైన అద్భుతం."

];

/* ------------------------------------------
   DESCRIPTION ENGINE
------------------------------------------ */

function random(arr){
  return arr[Math.floor(Math.random()*arr.length)];
}

function generateNatureSentence(item){

  let sentence =
    random(NATURE_TEMPLATES);

  return sentence.replace(
    "{word}",
    item.telugu
  );
}

function generateNatureDescription(item){

  const adjective =
    random(NATURE_ADJECTIVES);

  return `${item.telugu} (${item.english}) ప్రకృతిలోని ఒక ${adjective} అంశం.`;
}

/* ------------------------------------------
   EXAMPLES
------------------------------------------ */

console.log(generateNatureSentence(NATURE[0]));
console.log(generateNatureSentence(NATURE[10]));
console.log(generateNatureDescription(NATURE[20]));