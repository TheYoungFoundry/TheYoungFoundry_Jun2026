/* ==========================================
   TELUGU PROFESSIONS ENGINE
   ========================================== */

/* ------------------------------------------
   PROFESSION CATEGORIES
------------------------------------------ */

const PROFESSION_CATEGORIES = {

  education:[
    "ఉపాధ్యాయుడు"
  ],

  healthcare:[
    "వైద్యుడు",
    "నర్సు"
  ],

  engineering:[
    "ఇంజనీర్",
    "ప్రోగ్రామర్",
    "డిజైనర్",
    "ఆర్కిటెక్ట్"
  ],

  agriculture:[
    "రైతు"
  ],

  public_service:[
    "పోలీసు",
    "భద్రతా సిబ్బంది"
  ],

  law:[
    "న్యాయవాది"
  ],

  science:[
    "శాస్త్రవేత్త"
  ],

  business:[
    "వ్యాపారి",
    "మేనేజర్"
  ],

  transport:[
    "డ్రైవర్",
    "పైలట్"
  ],

  skilled_trades:[
    "వడ్రంగి",
    "కుమ్మరి",
    "దర్జీ",
    "ప్లంబర్",
    "ఎలక్ట్రీషియన్",
    "కార్మికుడు"
  ],

  arts:[
    "చిత్రకారుడు",
    "గాయకుడు",
    "నటుడు",
    "రచయిత",
    "కవి",
    "ఫోటోగ్రాఫర్"
  ],

  media:[
    "పత్రికా రచయిత"
  ],

  hospitality:[
    "వంటవాడు"
  ]
};

/* ------------------------------------------
   WORKPLACES
------------------------------------------ */

const WORKPLACES = {

  school:["పాఠశాల","కళాశాల"],
  hospital:["ఆసుపత్రి","క్లినిక్"],
  office:["కార్యాలయం","కంపెనీ"],
  farm:["పొలం"],
  court:["కోర్టు"],
  laboratory:["ల్యాబ్"],
  road:["రోడ్డు","వీధి"],
  airport:["విమానాశ్రయం"],
  workshop:["వర్క్‌షాప్"],
  studio:["స్టూడియో"],
  stage:["వేదిక"],
  kitchen:["వంటగది"],
  newsroom:["న్యూస్ కార్యాలయం"]
};

/* ------------------------------------------
   PROFESSION ACTIONS
------------------------------------------ */

const PROFESSION_ACTIONS = {

  teach:[
    "బోధించు",
    "నేర్పించు",
    "వివరించు"
  ],

  heal:[
    "చికిత్స చేయు",
    "సహాయం చేయు",
    "ఆరోగ్యాన్ని మెరుగుపరచు"
  ],

  build:[
    "నిర్మించు",
    "రూపకల్పన చేయు",
    "అభివృద్ధి చేయు"
  ],

  grow:[
    "పండించు",
    "వ్యవసాయం చేయు"
  ],

  protect:[
    "రక్షించు",
    "భద్రత కల్పించు"
  ],

  research:[
    "పరిశోధించు",
    "అన్వేషించు"
  ],

  manage:[
    "నిర్వహించు",
    "సమన్వయం చేయు"
  ],

  drive:[
    "నడుపు",
    "ప్రయాణించు"
  ],

  create:[
    "సృష్టించు",
    "రూపొందించు"
  ],

  write:[
    "వ్రాయు",
    "రచించు"
  ],

  repair:[
    "బాగుచేయు",
    "మరమ్మత్తు చేయు"
  ],

  cook:[
    "వంటచేయు",
    "ఆహారం తయారుచేయు"
  ]
};

/* ------------------------------------------
   PROFESSIONS
------------------------------------------ */

const PROFESSIONS = [

{
telugu:"ఉపాధ్యాయుడు",
english:"Teacher",
emoji:"👨‍🏫",
category:"education",
workplace:"school",
actions:["teach"]
},

{
telugu:"వైద్యుడు",
english:"Doctor",
emoji:"👨‍⚕️",
category:"healthcare",
workplace:"hospital",
actions:["heal"]
},

{
telugu:"ఇంజనీర్",
english:"Engineer",
emoji:"👷",
category:"engineering",
workplace:"office",
actions:["build"]
},

{
telugu:"రైతు",
english:"Farmer",
emoji:"🌾",
category:"agriculture",
workplace:"farm",
actions:["grow"]
},

{
telugu:"పోలీసు",
english:"Police Officer",
emoji:"👮",
category:"public_service",
workplace:"road",
actions:["protect"]
},

{
telugu:"న్యాయవాది",
english:"Lawyer",
emoji:"⚖️",
category:"law",
workplace:"court",
actions:["write","manage"]
},

{
telugu:"శాస్త్రవేత్త",
english:"Scientist",
emoji:"🔬",
category:"science",
workplace:"laboratory",
actions:["research"]
},

{
telugu:"వ్యాపారి",
english:"Businessman",
emoji:"💼",
category:"business",
workplace:"office",
actions:["manage"]
},

{
telugu:"డ్రైవర్",
english:"Driver",
emoji:"🚗",
category:"transport",
workplace:"road",
actions:["drive"]
},

{
telugu:"పైలట్",
english:"Pilot",
emoji:"✈️",
category:"transport",
workplace:"airport",
actions:["drive"]
},

{
telugu:"నర్సు",
english:"Nurse",
emoji:"👩‍⚕️",
category:"healthcare",
workplace:"hospital",
actions:["heal"]
},

{
telugu:"కార్మికుడు",
english:"Worker",
emoji:"🛠️",
category:"skilled_trades",
workplace:"workshop",
actions:["build"]
},

{
telugu:"వడ్రంగి",
english:"Carpenter",
emoji:"🪚",
category:"skilled_trades",
workplace:"workshop",
actions:["build"]
},

{
telugu:"కుమ్మరి",
english:"Potter",
emoji:"🏺",
category:"skilled_trades",
workplace:"workshop",
actions:["create"]
},

{
telugu:"దర్జీ",
english:"Tailor",
emoji:"🧵",
category:"skilled_trades",
workplace:"workshop",
actions:["create"]
},

{
telugu:"చిత్రకారుడు",
english:"Painter",
emoji:"🎨",
category:"arts",
workplace:"studio",
actions:["create"]
},

{
telugu:"గాయకుడు",
english:"Singer",
emoji:"🎤",
category:"arts",
workplace:"stage",
actions:["create"]
},

{
telugu:"నటుడు",
english:"Actor",
emoji:"🎭",
category:"arts",
workplace:"stage",
actions:["create"]
},

{
telugu:"రచయిత",
english:"Writer",
emoji:"✍️",
category:"arts",
workplace:"office",
actions:["write"]
},

{
telugu:"కవి",
english:"Poet",
emoji:"📖",
category:"arts",
workplace:"office",
actions:["write"]
},

{
telugu:"ప్రోగ్రామర్",
english:"Programmer",
emoji:"💻",
category:"engineering",
workplace:"office",
actions:["build"]
},

{
telugu:"డిజైనర్",
english:"Designer",
emoji:"🖌️",
category:"engineering",
workplace:"studio",
actions:["create"]
},

{
telugu:"మేనేజర్",
english:"Manager",
emoji:"📊",
category:"business",
workplace:"office",
actions:["manage"]
},

{
telugu:"పత్రికా రచయిత",
english:"Journalist",
emoji:"📰",
category:"media",
workplace:"newsroom",
actions:["write"]
},

{
telugu:"ఫోటోగ్రాఫర్",
english:"Photographer",
emoji:"📷",
category:"arts",
workplace:"studio",
actions:["create"]
},

{
telugu:"వంటవాడు",
english:"Cook",
emoji:"👨‍🍳",
category:"hospitality",
workplace:"kitchen",
actions:["cook"]
},

{
telugu:"భద్రతా సిబ్బంది",
english:"Security Guard",
emoji:"🛡️",
category:"public_service",
workplace:"office",
actions:["protect"]
},

{
telugu:"ప్లంబర్",
english:"Plumber",
emoji:"🔧",
category:"skilled_trades",
workplace:"workshop",
actions:["repair"]
},

{
telugu:"ఎలక్ట్రీషియన్",
english:"Electrician",
emoji:"💡",
category:"skilled_trades",
workplace:"workshop",
actions:["repair"]
},

{
telugu:"ఆర్కిటెక్ట్",
english:"Architect",
emoji:"🏗️",
category:"engineering",
workplace:"office",
actions:["build","create"]
}

];

/* ------------------------------------------
   SENTENCE TEMPLATES
------------------------------------------ */

const PROFESSION_TEMPLATES = [

"{word} సమాజానికి ఎంతో ఉపయోగపడే వృత్తి.",

"{word} తన పనిని నిబద్ధతతో చేస్తాడు.",

"{word} ప్రజలకు సేవ అందిస్తాడు.",

"{word} తన నైపుణ్యంతో ఇతరులకు సహాయం చేస్తాడు.",

"{word} సమాజ అభివృద్ధికి తోడ్పడతాడు."
];

/* ------------------------------------------
   ENGINE
------------------------------------------ */

function random(arr){
  return arr[Math.floor(Math.random()*arr.length)];
}

function generateProfessionSentence(profession){

  return random(PROFESSION_TEMPLATES)
    .replace("{word}", profession.telugu);
}

function generateProfessionDescription(profession){

  return `${profession.telugu} (${profession.english}) ఒక ${profession.category} వృత్తి.`;
}

/* ------------------------------------------
   EXAMPLES
------------------------------------------ */

console.log(generateProfessionSentence(PROFESSIONS[0]));
// ఉపాధ్యాయుడు సమాజానికి ఎంతో ఉపయోగపడే వృత్తి.

console.log(generateProfessionDescription(PROFESSIONS[3]));
// రైతు (Farmer) ఒక agriculture వృత్తి.

console.log(generateProfessionDescription(PROFESSIONS[20]));
// ప్రోగ్రామర్ (Programmer) ఒక engineering వృత్తి.