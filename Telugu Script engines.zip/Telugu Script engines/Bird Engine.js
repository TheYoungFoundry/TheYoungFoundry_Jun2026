/* ==========================================
   TELUGU LANGUAGE ENGINE
   Birds + Adjectives + Adverbs + Places
   Smart Sentence Generator
   ========================================== */

/* ------------------------------------------
   ADJECTIVES
------------------------------------------ */

const ADJECTIVES = [
  "అందమైన","చిన్న","పెద్ద","రంగురంగుల","తెలివైన",
  "చురుకైన","వేగమైన","శక్తివంతమైన","మృదువైన","నలుపు",
  "తెలుపు","పచ్చని","ఎరుపు","నీలం","పసుపు",
  "ప్రకాశవంతమైన","సంతోషమైన","ఉత్సాహమైన","శాంతమైన","స్నేహపూర్వకమైన",
  "ధైర్యవంతమైన","బలమైన","పొడవైన","పొట్టి","మంచి",
  "ఆకర్షణీయమైన","వింతైన","అరుదైన","స్వచ్ఛమైన","సుందరమైన",
  "ముద్దైన","గర్వమైన","ప్రత్యేకమైన","చల్లని","వెచ్చని",
  "సహజమైన","కాంతివంతమైన","నాజూకైన","సాహసవంతమైన","స్వేచ్ఛాయుతమైన",
  "ఆనందమైన","ఆసక్తికరమైన","ఉల్లాసమైన","శ్రద్ధగల","క్రమశిక్షణగల",
  "ప్రతిభావంతమైన","చాకచక్యమైన","మధురమైన","అద్భుతమైన","ఆరోగ్యవంతమైన"
];

/* ------------------------------------------
   ADVERBS
------------------------------------------ */

const ADVERBS = [
  "వేగంగా","నెమ్మదిగా","అందంగా","గట్టిగా","శాంతంగా",
  "చురుకుగా","జాగ్రత్తగా","ఎత్తుగా","దూరంగా","సులభంగా",
  "సంతోషంగా","నిశ్శబ్దంగా","తెలివిగా","మెల్లగా","ఆసక్తిగా",
  "ఉత్సాహంగా","స్వేచ్ఛగా","క్రమంగా","హాయిగా","అద్భుతంగా",
  "స్పష్టంగా","ధైర్యంగా","బలంగా","నైపుణ్యంగా","సురక్షితంగా",
  "అప్రమత్తంగా","ఆకర్షణీయంగా","సహజంగా","స్నేహపూర్వకంగా","మధురంగా",
  "శ్రద్ధగా","వినయంగా","నిబద్ధతతో","విశ్వాసంగా","గర్వంగా",
  "ఆనందంగా","సమర్థంగా","ప్రశాంతంగా","కచ్చితంగా","తొందరగా",
  "సరదాగా","స్వల్పంగా","అత్యంతంగా","పూర్తిగా","విశేషంగా",
  "అలవోకగా","నిరంతరం","తరచుగా","అప్పుడప్పుడు","అకస్మాత్తుగా"
];

/* ------------------------------------------
   PLACES BY CATEGORY
------------------------------------------ */

const PLACE_CATEGORIES = {

  tree:[
    "చెట్టు",
    "చెట్ల కొమ్మ",
    "వేప చెట్టు",
    "మామిడి చెట్టు"
  ],

  water:[
    "చెరువు",
    "సరస్సు",
    "నది",
    "కుంట",
    "సముద్రం"
  ],

  forest:[
    "అడవి",
    "వనం",
    "వర్షారణ్యం",
    "సహజవనం"
  ],

  city:[
    "నగరం",
    "పార్క్",
    "వీధి",
    "పాఠశాల"
  ],

  farm:[
    "పొలం",
    "వ్యవసాయ క్షేత్రం"
  ],

  sky:[
    "ఆకాశం",
    "మేఘాల మధ్య"
  ],

  ice:[
    "మంచు ప్రదేశం",
    "ధృవ ప్రాంతం"
  ]
};

/* ------------------------------------------
   VERB CATEGORIES
------------------------------------------ */

const VERB_CATEGORIES = {

  flying:[
    "ఎగురు",
    "విహరించు",
    "రెక్కలు విప్పు",
    "గాలిలో తేలియాడు",
    "వాలిపోవు"
  ],

  singing:[
    "కూయు",
    "పాడు",
    "ఆలపించు",
    "కూత వేయు",
    "పిలువు"
  ],

  walking:[
    "నడువు",
    "తిరుగు",
    "సంచరించు",
    "కదులు",
    "వెతుకు"
  ],

  running:[
    "పరుగెత్తు",
    "దూసుకుపోవు",
    "వేగంగా కదులు",
    "పోటీ పడు",
    "ముందుకు దూకు"
  ],

  swimming:[
    "ఈదు",
    "నీటిలో తేలియాడు",
    "నీటిని చీల్చు",
    "మునుగు",
    "చెరువులో తిరుగు"
  ],

  hunting:[
    "వేటాడు",
    "వెంబడించు",
    "పట్టుకో",
    "దాడి చేయు",
    "ఆహారం వెతుకు"
  ],

  nesting:[
    "గూడు కట్టు",
    "గుడ్లు పెట్టు",
    "పిల్లలను కాపాడు",
    "గూడును సంరక్షించు",
    "కొమ్మలు సేకరించు"
  ],

  feeding:[
    "తిను",
    "గింజలు తిను",
    "పండ్లు తిను",
    "నీరు తాగు",
    "ఆహారం సేకరించు"
  ]
};

/* ------------------------------------------
   35 BIRDS
------------------------------------------ */

const BIRDS = [

{telugu:"కాకి",english:"Crow",emoji:"🐦",actions:["flying","walking","feeding","nesting"],habitats:["tree","city"]},

{telugu:"పావురం",english:"Pigeon",emoji:"🕊️",actions:["flying","walking","feeding"],habitats:["city"]},

{telugu:"చిలుక",english:"Parrot",emoji:"🦜",actions:["flying","singing","feeding","nesting"],habitats:["tree","forest"]},

{telugu:"కోయిల",english:"Cuckoo",emoji:"🐦",actions:["flying","singing"],habitats:["tree","forest"]},

{telugu:"నెమలి",english:"Peacock",emoji:"🦚",actions:["walking","running","nesting"],habitats:["forest","farm"]},

{telugu:"గువ్వ",english:"Sparrow",emoji:"🐦",actions:["flying","feeding","nesting"],habitats:["tree","city"]},

{telugu:"బాతు",english:"Duck",emoji:"🦆",actions:["swimming","walking","feeding"],habitats:["water"]},

{telugu:"కొంగ",english:"Stork",emoji:"🦩",actions:["walking","feeding"],habitats:["water"]},

{telugu:"డేగ",english:"Hawk",emoji:"🦅",actions:["flying","hunting"],habitats:["sky","forest"]},

{telugu:"గద్ద",english:"Vulture",emoji:"🦅",actions:["flying","hunting"],habitats:["sky"]},

{telugu:"కోడి",english:"Hen",emoji:"🐔",actions:["walking","feeding","nesting"],habitats:["farm"]},

{telugu:"పుంజు",english:"Rooster",emoji:"🐓",actions:["walking","singing"],habitats:["farm"]},

{telugu:"హంస",english:"Swan",emoji:"🦢",actions:["swimming","walking"],habitats:["water"]},

{telugu:"గుడ్లగూబ",english:"Owl",emoji:"🦉",actions:["flying","hunting"],habitats:["forest","tree"]},

{telugu:"పిచ్చుక",english:"House Sparrow",emoji:"🐦",actions:["flying","feeding"],habitats:["city","tree"]},

{telugu:"రాబందు",english:"Kite",emoji:"🦅",actions:["flying","hunting"],habitats:["sky"]},

{telugu:"పరుగు పిట్ట",english:"Swift",emoji:"🐦",actions:["flying"],habitats:["sky"]},

{telugu:"చేపపిట్ట",english:"Kingfisher",emoji:"🐦",actions:["hunting","flying"],habitats:["water"]},

{telugu:"కొంగపిట్ట",english:"Heron",emoji:"🐦",actions:["walking","feeding"],habitats:["water"]},

{telugu:"ఫ్లామింగో",english:"Flamingo",emoji:"🦩",actions:["walking","feeding"],habitats:["water"]},

{telugu:"పెంగ్విన్",english:"Penguin",emoji:"🐧",actions:["swimming","walking"],habitats:["ice","water"]},

{telugu:"ఆస్ట్రిచ్",english:"Ostrich",emoji:"🐦",actions:["running","walking"],habitats:["farm"]},

{telugu:"ఈగిల్",english:"Eagle",emoji:"🦅",actions:["flying","hunting"],habitats:["sky","forest"]},

{telugu:"ఫాల్కన్",english:"Falcon",emoji:"🦅",actions:["flying","hunting"],habitats:["sky"]},

{telugu:"హార్న్‌బిల్",english:"Hornbill",emoji:"🐦",actions:["flying","feeding"],habitats:["forest","tree"]},

{telugu:"వుడ్‌పెక్కర్",english:"Woodpecker",emoji:"🐦",actions:["feeding","nesting"],habitats:["tree"]},

{telugu:"మైనా",english:"Myna",emoji:"🐦",actions:["singing","flying"],habitats:["city","tree"]},

{telugu:"కానరీ",english:"Canary",emoji:"🐤",actions:["singing","flying"],habitats:["tree"]},

{telugu:"స్వాలో",english:"Swallow",emoji:"🐦",actions:["flying"],habitats:["sky"]},

{telugu:"క్రేన్",english:"Crane",emoji:"🦩",actions:["walking","feeding"],habitats:["water"]},

{telugu:"పెలికాన్",english:"Pelican",emoji:"🐦",actions:["feeding","flying"],habitats:["water"]},

{telugu:"కింగ్‌ఫిషర్",english:"Kingfisher",emoji:"🐦",actions:["hunting","flying"],habitats:["water"]},

{telugu:"పారట్",english:"Parrot",emoji:"🦜",actions:["flying","singing"],habitats:["forest","tree"]},

{telugu:"మాకా",english:"Macaw",emoji:"🦜",actions:["flying","singing"],habitats:["forest","tree"]},

{telugu:"అల్బాట్రాస్",english:"Albatross",emoji:"🐦",actions:["flying"],habitats:["sky","water"]}

];

/* ------------------------------------------
   ENGINE
------------------------------------------ */

function random(arr){
  return arr[Math.floor(Math.random()*arr.length)];
}

function getVerb(bird){
  const category = random(bird.actions);
  return random(VERB_CATEGORIES[category]);
}

function getPlace(bird){
  const habitat = random(bird.habitats);
  return random(PLACE_CATEGORIES[habitat]);
}

function generateSentence(bird){

  const adjective = random(ADJECTIVES);
  const adverb = random(ADVERBS);
  const place = getPlace(bird);
  const verb = getVerb(bird);

  return `${adjective} ${bird.telugu} ${place}లో ${adverb} ${verb}ింది.`;
}

/* Example */

console.log(generateSentence(BIRDS[0]));
console.log(generateSentence(BIRDS[4]));
console.log(generateSentence(BIRDS[20]));