
/*===========Skill Registration==========*/

{
 id:'animals',
 name:'Animals',
 emoji:'🐘',
 skills:[
   'animalRead',
   'animalMissing',
   'animalScramble',
   'animalCategory',
   'animalSentence'
 ]
}

/* ==========================
   HELPERS
========================== */

SK.wordScramble = function(category){

  const word =
    TELUGU.randomWord(category);

  return {
    type:'reorder',
    question:'అక్షరాలను అమర్చండి',
    prompt:scrambleWord(word),
    answer:word
  };

};
function makeOptions(correct,list,count=4){
  let options=[correct];
  while(options.length<count){
    const item=pick(list);
    if(!options.includes(item))
      options.push(item);
  }
  return shuffle(options);
}

function makeMissingWord(word){
  const pos =
    Math.floor(Math.random()*word.length);
  return (
    word.substring(0,pos) +
    "_" +
    word.substring(pos+1)
  );
}
function makeImageQuestion(item){

  return {
    image:item.image,
    answer:item.word
  };

}
function makeSentence(item){

  if(
    !item.actions ||
    !item.places
  )
    return item.word;

  const action=
    pick(item.actions);

  const place=
    pick(item.places);
  return `${item.word} ${place}లో ${action}.`;
}

function makeBlankSentence(item){

  const action=
    pick(item.actions);
  const place=
    pick(item.places);
  return {
    prompt:
      `${item.word} ${place}లో ______.`,
    answer:action
  };
}
function byGrade(list,grade){

  return list.filter(
    x => x.grade <= grade
  );
}

function randomByGrade(list,grade){

  const filtered =
    byGrade(list,grade);

  return pick(filtered);

}
function createQuestion(
  question,
  prompt,
  answer,
  type="input"
){

  return {
    type,
    question,
    prompt,
    answer
  };

}

/*===========Animals======================*/
TELUGU.words = {
animals:[ "పిల్లి", "కుక్క", "ఆవు", "గేదె", "మేక", "గుర్రం", "గాడిద", "కోతి", "ఏనుగు", "సింహం", "పులి", "జింక", "ఎలుక", "కుందేలు", "ఎద్దు", "ఒంటె", "పంది",
 "నక్క", "ఎలుగుబంటి", "చిరుత", "ఉడుత", "తోడేలు", "చీమ", "తేనెటీగ", "సీతాకోకచిలుక", "పాము", "మొసలి", "తాబేలు", "జీబ్రా", "పాండా"],

birds:["కాకి","పావురం","చిలుక","కోయిల","నెమలి","గువ్వ","బాతు","కొంగ","డేగ","గద్ద","కోడి","పుంజు","హంస","గుడ్లగూబ","పిచ్చుక","రాబందు","పరుగు పిట్ట","చేపపిట్ట","కొంగపిట్ట","ఫ్లామింగో","పెంగ్విన్","ఆస్ట్రిచ్","ఈగిల్","ఫాల్కన్","హార్న్‌బిల్","వుడ్‌పెక్కర్","మైనా","కానరీ","స్వాలో","క్రేన్","పెలికాన్","కింగ్‌ఫిషర్","పారట్","మాకా","అల్బాట్రాస్"],

fruits:["మామిడి","అరటి","ద్రాక్ష","జామ","సపోటా","నారింజ","దానిమ్మ","బొప్పాయి","పుచ్చకాయ","ఖర్బూజ","అనాస","ఉసిరి","నిమ్మ","సీతాఫలం","రేగిపండు",
"కొబ్బరి","చింతపండు","బత్తాయి","అత్తి","ఖర్జూరం","స్ట్రాబెర్రీ","కివి","పీచ్","పేర్","ఆపిల్","ప్లమ్","చెర్రీ","బ్లూబెర్రీ","రాస్ప్‌బెర్రీ","అవకాడో","లీచీ","రాంబుటాన్","డ్రాగన్ ఫ్రూట్","జాక్‌ఫ్రూట్","మల్బెర్రీ"],

vegetables:["టమాట","వంకాయ","బెండకాయ","దొండకాయ","బీరకాయ","సొరకాయ","కాకరకాయ","గుమ్మడికాయ","ఉల్లిపాయ","బంగాళదుంప","క్యారెట్","ముల్లంగి","చిలగడదుంప","క్యాబేజీ","కాలీఫ్లవర్","బఠాణీ","మిరపకాయ","పాలకూర","మెంతికూర","గోంగూర","చిక్కుడు","బీన్స్","మొక్కజొన్న","అల్లం","వెల్లుల్లి","బీట్‌రూట్","సెలరీ","బ్రోకలీ","లెట్యూస్","కీరదోస","దోసకాయ","పచ్చిమిర్చి","సెనగకాయ","మష్రూమ్","కరివేపాకు"],

school:["పాఠశాల","విద్యార్థి","ఉపాధ్యాయుడు","తరగతి","పుస్తకం","పెన్సిల్","రబ్బరు","బ్యాగ్","బల్ల","కుర్చీ","బ్లాక్‌బోర్డ్","చాక్","నోట్‌బుక్","హోంవర్క్","పరీక్ష",
"గ్రంథాలయం","ప్రిన్సిపాల్","స్నేహితుడు","గణితం","విజ్ఞానం","కంప్యూటర్","ల్యాప్‌టాప్","ప్రాజెక్ట్","పాఠం","గది","క్యాల్క్యులేటర్","పెన్","స్కేలు","మ్యాప్","ల్యాబ్",
"ప్రయోగం","సర్టిఫికెట్","అసైన్‌మెంట్","సిలబస్","వర్క్‌షీట్"],

body:["తల","కన్ను","ముక్కు","చెవి","నోరు","పెదవి","పంటి","నాలుక","మెడ","భుజం","చేయి","వేలు","గోరు","ఛాతీ","కడుపు","వెన్ను","కాలు","మోకాలు","పాదం","జుట్టు","కన్నుబొమ్మ","గడ్డం","చర్మం","గుండె","మెదడు","మణికట్టు","మోచేయి","మడమ","పిక్క","పలుకు","రక్తం","ఎముక","నరం","ఊపిరితిత్తి","కాలేయం"],

nature:["సూర్యుడు","చంద్రుడు","నక్షత్రం","ఆకాశం","మేఘం","వర్షం","గాలి","నది","సముద్రం","కొండ","చెట్టు","పువ్వు","ఆకు","అడవి","భూమి","రాయి","ఇసుక","చెరువు","జలపాతం","సూర్యకాంతి","ఇంద్రధనుస్సు","తుఫాను","మెరుపు","ఉరుము","మంచు","వెలుగు","చీకటి","వసంతం","గ్రీష్మం","శరదృతువు","హేమంతం","శీతాకాలం","వర్షాకాలం","సమీరము","పర్వతం"],

actions:["తిను","తాగు","నడువు","పరుగెత్తు","చదువు","రాయి","చూడు","విను","ఆడు","పాడు","నవ్వు","ఏడు","నిద్రపో","కూర్చో","నిలబడు","ఎక్కు","దుగు","తెరువు","మూయు","తెచ్చు","ఇవ్వు","తీసుకో","పిలువు","మాట్లాడు","ఆలోచించు","గీయు","కడుగు","వంటచేయు","కొను","అమ్ము","దాచు","వెతుకు","పంపు","సహాయం చేయు","పట్టుకో",
"వదులు","కట్టు","విప్పు","ప్రయాణించు","సృష్టించు","దూకు","గెలుచు","నేర్చుకో","బోధించు","శుభ్రం చేయు","సాగు","పెంచు","పండించు","రక్షించు","అన్వేషించు"],

places:["ఇల్లు","పాఠశాల","గ్రంథాలయం","ఆసుపత్రి","దేవాలయం","పార్క్","తోట","బజారు","దుకాణం","బ్యాంకు","తపాలా కార్యాలయం","రైల్వే స్టేషన్","విమానాశ్రయం","రోడ్డు","వీధి","గ్రామం","పట్టణం","నగరం","పొలం","అడవి","సముద్రతీరం","కొండ","చెరువు","నది","వంతెన","క్రీడామైదానం","మ్యూజియం","జూ","సినిమాహాలు","హోటల్","రెస్టారెంట్","కార్యాలయం","ఫ్యాక్టరీ","బస్ స్టాండ్","విశ్వవిద్యాలయం","కళాశాల","దేవస్థానం","షాపింగ్ మాల్","గ్రౌండ్","పర్యాటక స్థలం","పోలీస్ స్టేషన్","ఫైర్ స్టేషన్","కోర్టు","ల్యాబ్","వేదిక","ఎగ్జిబిషన్","అక్వేరియం","పుస్తక దుకాణం","స్టేడియం","ఆటస్థలం"],

colors:["ఎరుపు","నీలం","ఆకుపచ్చ","పసుపు","నారింజ","గులాబీ","తెలుపు","నలుపు","బూడిద","ఊదా","గోధుమ","లేతనీలం","లేతఆకుపచ్చ","బంగారు","వెండి",
"కాషాయం","ముదురు నీలం","ముదురు ఆకుపచ్చ","క్రీమ్","మరూన్","వైలెట్","ఇండిగో","టర్కాయిస్","పీచ్","లావెండర్"],

vehicles:["సైకిల్","మోటార్ సైకిల్","కారు","బస్సు","లారీ","ఆటో","రైలు","విమానం","హెలికాప్టర్","పడవ","ఓడ","ట్రాక్టర్","అంబులెన్స్","ఫైర్ ఇంజిన్","మెట్రో","రిక్షా","వాన్","జీప్","స్కూటర్","బుల్డోజర్","క్రేన్","ట్యాంకర్","రోలర్","సబ్‌మరైన్","రోకెట్"],

professions:["ఉపాధ్యాయుడు","వైద్యుడు","ఇంజనీర్","రైతు","పోలీసు","న్యాయవాది","శాస్త్రవేత్త","వ్యాపారి","డ్రైవర్","పైలట్","నర్సు","కార్మికుడు","వడ్రంగి","కుమ్మరి","దర్జీ","చిత్రకారుడు","గాయకుడు","నటుడు","రచయిత","కవి","ప్రోగ్రామర్","డిజైనర్","మేనేజర్","పత్రికా రచయిత","ఫోటోగ్రాఫర్","వంటవాడు","భద్రతా సిబ్బంది","ప్లంబర్","ఎలక్ట్రీషియన్","ఆర్కిటెక్ట్"],

festivals:[
"సంక్రాంతి","ఉగాది","దీపావళి","దసరా","వినాయక చవితి","శ్రీరామనవమి","కృష్ణాష్టమి","హోలీ","రాఖీ","బక్రీద్","రంజాన్","క్రిస్మస్","ఈస్టర్","మహాశివరాత్రి","నవరాత్రులు","బతుకమ్మ","బోనాలు","కనుమ","భోగి","ముక్కోటి ఏకాదశి","గణేష్ ఉత్సవం","గురు పౌర్ణిమ","వైకుంఠ ఏకాదశి","కార్తీక దీపోత్సవం","నాగుల చవితి","వరలక్ష్మీ వ్రతం","అట్ల తద్దె","రథసప్తమి","హనుమజ్జయంతి","సుబ్రహ్మణ్య షష్ఠి"]
};


/*===========Animals engine======================*/

TELUGU.pick = function(arr){
  return arr[Math.floor(Math.random()*arr.length)];
};

TELUGU.shuffle = function(arr){
  return [...arr].sort(()=>Math.random()-0.5);
};

TELUGU.randomWord = function(category){

  const list = TELUGU.words[category];

  return TELUGU.pick(list);

};

/*=================Skill 1 - Reading Skills =============================*/

SK.wordRead = function(category){

  const item =
    TELUGU.randomWord(category);

  return {
    question:"ఈ పదాన్ని చదవండి",
    prompt:item,
    answer:item
  };

};
/*=================Skill 2 - Missing Letter=============================*/

SK.wordMissing = function(category){

  const word =
    TELUGU.randomWord(category);

  return {
    type:"input",
    question:"ఖాళీని పూరించండి",
    prompt:makeMissingWord(word),
    answer:word
  };

};
/*=================Skill 3 - Scramble=============================*/
SK.wordScramble = function(category){

  const word =
    TELUGU.randomWord(category);

  return {
    type:"reorder",
    question:"అక్షరాలను అమర్చి పదం తయారు చేయండి",
    prompt:scrambleWord(word),
    answer:word
  };

/*=================Skill 4 - word Category=============================*/

SK.wordCategory = function(category){

  const word =
    TELUGU.randomWord(category);

  const categories =
    Object.keys(TELUGU.words);

  let options = [category];

  while(options.length < 4){

    const c = pick(categories);

    if(!options.includes(c))
      options.push(c);

  }

  return {
    type:"mcq",
    question:"ఈ పదం ఏ వర్గానికి చెందుతుంది?",
    prompt:word,
    answer:category,
    options:shuffle(options)
  };

};

/*=================Skill 5 - Sentence Builder=============================*/
SK.wordSentence = function(category){

  const word =
    TELUGU.randomWord(category);

  let sentence = "";

  switch(category){

    case 'animals':
      sentence =
        `${word} అడవిలో ఉంది.`;
      break;

    case 'birds':
      sentence =
        `${word} ఆకాశంలో ఎగురుతోంది.`;
      break;

    case 'fruits':
      sentence =
        `${word} చాలా తీపిగా ఉంది.`;
      break;

    case 'vegetables':
      sentence =
        `${word} ఆరోగ్యానికి మంచిది.`;
      break;

    default:
      sentence =
        `${word} ఒక మంచి పదం.`;
  }

  return {
    type:'sentence',
    question:'వాక్యం చదవండి',
    prompt:sentence,
    answer:sentence
  };

};



/*===========Animals======================*/
const animals = [
{
  word:"పిల్లి",
  english:"Cat",
  category:"animal",
  grade:1,
  gender:"neutral",
  actions:["నడుస్తుంది","పరుగెడుతుంది","నిద్రపోతుంది"],
  places:["ఇల్లు","తోట"]
},
{
  word:"కుక్క",
  english:"Dog",
  category:"animal",
  grade:1,
  gender:"neutral",
  actions:["పరుగెడుతుంది","మొరుగుతుంది","ఆడుతుంది"],
  places:["ఇల్లు","తోట"]
},
{
  word:"ఆవు",
  english:"Cow",
  category:"animal",
  grade:1,
  gender:"neutral",
  actions:["మేస్తుంది","నడుస్తుంది","తింటుంది"],
  places:["పొలం","గడ్డి మైదానం"]
},
{
  word:"గేదె",
  english:"Buffalo",
  category:"animal",
  grade:1,
  gender:"neutral",
  actions:["మేస్తుంది","నడుస్తుంది","నీటిలో ఉంటుంది"],
  places:["పొలం","చెరువు"]
},
{
  word:"మేక",
  english:"Goat",
  category:"animal",
  grade:1,
  gender:"neutral",
  actions:["మేస్తుంది","దూకుతుంది","నడుస్తుంది"],
  places:["పొలం","గడ్డి మైదానం"]
},
{
  word:"గుర్రం",
  english:"Horse",
  category:"animal",
  grade:1,
  gender:"neutral",
  actions:["పరుగెడుతుంది","నడుస్తుంది","దూకుతుంది"],
  places:["పొలం","గుర్రపు శాల"]
},
{
  word:"గాడిద",
  english:"Donkey",
  category:"animal",
  grade:1,
  gender:"neutral",
  actions:["నడుస్తుంది","బరువులు మోస్తుంది"],
  places:["గ్రామం","పొలం"]
},
{
  word:"కోతి",
  english:"Monkey",
  category:"animal",
  grade:1,
  gender:"neutral",
  actions:["ఎక్కుతుంది","దూకుతుంది","తింటుంది"],
  places:["చెట్టు","అడవి","జూ"]
},
{
  word:"ఏనుగు",
  english:"Elephant",
  category:"animal",
  grade:1,
  gender:"neutral",
  actions:["నడుస్తుంది","స్నానం చేస్తుంది","తింటుంది"],
  places:["అడవి","జూ"]
},
{
  word:"సింహం",
  english:"Lion",
  category:"animal",
  grade:1,
  gender:"neutral",
  actions:["గర్జిస్తుంది","నడుస్తుంది","వేటాడుతుంది"],
  places:["అడవి","జూ"]
},
{
  word:"పులి",
  english:"Tiger",
  category:"animal",
  grade:1,
  gender:"neutral",
  actions:["వేటాడుతుంది","పరుగెడుతుంది","నడుస్తుంది"],
  places:["అడవి","జూ"]
},
{
  word:"జింక",
  english:"Deer",
  category:"animal",
  grade:1,
  gender:"neutral",
  actions:["పరుగెడుతుంది","మేస్తుంది","దూకుతుంది"],
  places:["అడవి","గడ్డి మైదానం"]
},
{
  word:"ఎలుక",
  english:"Mouse",
  category:"animal",
  grade:1,
  gender:"neutral",
  actions:["పరుగెడుతుంది","దాక్కుంటుంది","తింటుంది"],
  places:["ఇల్లు","పొలం"]
},
{
  word:"కుందేలు",
  english:"Rabbit",
  category:"animal",
  grade:1,
  gender:"neutral",
  actions:["దూకుతుంది","పరుగెడుతుంది","తింటుంది"],
  places:["తోట","అడవి"]
},
{
  word:"ఎద్దు",
  english:"Bull",
  category:"animal",
  grade:1,
  gender:"neutral",
  actions:["దున్నుతుంది","నడుస్తుంది","మేస్తుంది"],
  places:["పొలం"]
},
{
  word:"ఒంటె",
  english:"Camel",
  category:"animal",
  grade:2,
  gender:"neutral",
  actions:["నడుస్తుంది","బరువులు మోస్తుంది"],
  places:["ఎడారి"]
},
{
  word:"పంది",
  english:"Pig",
  category:"animal",
  grade:2,
  gender:"neutral",
  actions:["తింటుంది","నడుస్తుంది"],
  places:["పొలం"]
},
{
  word:"నక్క",
  english:"Fox",
  category:"animal",
  grade:2,
  gender:"neutral",
  actions:["పరుగెడుతుంది","వేటాడుతుంది"],
  places:["అడవి"]
},
{
  word:"ఎలుగుబంటి",
  english:"Bear",
  category:"animal",
  grade:2,
  gender:"neutral",
  actions:["నడుస్తుంది","తింటుంది","ఎక్కుతుంది"],
  places:["అడవి"]
},
{
  word:"చిరుత",
  english:"Leopard",
  category:"animal",
  grade:2,
  gender:"neutral",
  actions:["పరుగెడుతుంది","వేటాడుతుంది","ఎక్కుతుంది"],
  places:["అడవి"]
},
{
  word:"ఉడుత",
  english:"Squirrel",
  category:"animal",
  grade:2,
  gender:"neutral",
  actions:["ఎక్కుతుంది","పరుగెడుతుంది"],
  places:["చెట్టు","తోట"]
},
{
  word:"తోడేలు",
  english:"Wolf",
  category:"animal",
  grade:2,
  gender:"neutral",
  actions:["పరుగెడుతుంది","వేటాడుతుంది"],
  places:["అడవి"]
},
{
  word:"చీమ",
  english:"Ant",
  category:"animal",
  grade:1,
  gender:"neutral",
  actions:["నడుస్తుంది","ఆహారం మోస్తుంది"],
  places:["నేల","పుట్ట"]
},
{
  word:"తేనెటీగ",
  english:"Honey Bee",
  category:"animal",
  grade:1,
  gender:"neutral",
  actions:["ఎగురుతుంది","తేనె సేకరిస్తుంది"],
  places:["పూల తోట"]
},
{
  word:"సీతాకోకచిలుక",
  english:"Butterfly",
  category:"animal",
  grade:1,
  gender:"neutral",
  actions:["ఎగురుతుంది","పూలపై వాలుతుంది"],
  places:["తోట"]
},
{
  word:"పాము",
  english:"Snake",
  category:"animal",
  grade:2,
  gender:"neutral",
  actions:["పాకుతుంది","దాక్కుంటుంది"],
  places:["అడవి","పొలం"]
},
{
  word:"మొసలి",
  english:"Crocodile",
  category:"animal",
  grade:2,
  gender:"neutral",
  actions:["ఈదుతుంది","వేటాడుతుంది"],
  places:["నది","చెరువు"]
},
{
  word:"తాబేలు",
  english:"Turtle",
  category:"animal",
  grade:2,
  gender:"neutral",
  actions:["నడుస్తుంది","ఈదుతుంది"],
  places:["చెరువు","సముద్రం"]
},
{
  word:"జీబ్రా",
  english:"Zebra",
  category:"animal",
  grade:2,
  gender:"neutral",
  actions:["పరుగెడుతుంది","మేస్తుంది"],
  places:["గడ్డి మైదానం","జూ"]
},
{
  word:"పాండా",
  english:"Panda",
  category:"animal",
  grade:2,
  gender:"neutral",
  actions:["తింటుంది","ఎక్కుతుంది"],
  places:["అడవి","జూ"]
}
];