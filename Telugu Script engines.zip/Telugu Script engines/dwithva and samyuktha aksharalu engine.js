/* =========================================================
   TELUGU DWITVAKSHARA & SAMYUKTAKSHARA ENGINE
   =========================================================

   Features:
   ✓ Dwitvakshara Words
   ✓ Samyuktakshara Words
   ✓ Word Recognition Quiz
   ✓ Fill in the Blanks
   ✓ Sentence Quiz
   ✓ Reading Practice
   ✓ Dictation
   ✓ Story Generation

   ========================================================= */


/* =========================================================
   DWITVAKSHARA WORDS
   ========================================================= */

const DWITVAKSHARA_DB = {

"క్క":[
"అక్క","అక్కయ్య","పక్కన","చుక్క","చుక్కలు",
"ముక్క","ముక్కలు","చెక్క","ఎక్కు","ఎక్కడం"
],

"గ్గ":[
"మొగ్గ","మొగ్గలు","బుగ్గ","బుగ్గలు","దగ్గర",
"దగ్గు","తగ్గు","మగ్గం"
],

"చ్చ":[
"పచ్చ","మచ్చ","పుచ్చకాయ","నిచ్చెన",
"కచ్చితం","గుచ్చం","తెచ్చు"
],

"జ్జ":[
"బుజ్జి","మజ్జిగ","గుజ్జు",
"గజ్జెలు","బజ్జి","సజ్జలు"
],

"ట్ట":[
"కట్ట","బుట్ట","గుట్ట",
"మట్టి","పట్టణం","పట్టీ"
],

"డ్డ":[
"గడ్డ","గడ్డం","అడ్డం",
"గొడ్డలి","దొడ్డి"
],

"న్న":[
"అన్న","అన్నం","చిన్న",
"కన్ను","వెన్న","సున్నా"
],

"ప్ప":[
"కప్ప","పప్పు","చెప్పు",
"తప్పు","నిప్పు"
],

"బ్బ":[
"డబ్బు","అబ్బాయి",
"దిబ్బ","బొబ్బట్లు"
],

"మ్మ":[
"అమ్మ","బొమ్మ",
"తమ్ముడు","నమ్మకం",
"కుమ్మరి"
],

"ల్ల":[
"పిల్ల","బల్ల",
"తల్లి","పల్లె",
"మల్లె"
]

};


/* =========================================================
   SAMYUKTAKSHARA WORDS
   ========================================================= */

const SAMYUKTA_DB = {

"క్ష":[
"క్షమ",
"క్షీరం",
"క్షేత్రం",
"క్షణం",
"అక్షరం",
"లక్ష్యం",
"సాక్ష్యం",
"క్షమాపణ",
"క్షౌరం",
"క్షత్రియుడు"
],

"త్ర":[
"మిత్రుడు",
"చిత్రం",
"యాత్ర",
"పాత్ర",
"నేత్రం",
"శత్రువు",
"సూత్రం",
"గోత్రం",
"త్రయం",
"త్రాడు"
],

"జ్ఞ":[
"జ్ఞానం",
"విజ్ఞానం",
"అజ్ఞానం",
"జ్ఞాపకం",
"జ్ఞాని",
"ప్రజ్ఞ",
"జ్ఞేయం"
],

"శ్ర":[
"శ్రీ",
"శ్రద్ధ",
"శ్రమ",
"శ్రావణం",
"శ్రేయస్సు",
"శ్రుతి",
"శ్రేణి"
],

"ప్ర":[
"ప్రపంచం",
"ప్రకృతి",
"ప్రయాణం",
"ప్రార్థన",
"ప్రజలు",
"ప్రకాశం"
],

"గ్ర":[
"గ్రామం",
"గ్రంథం",
"గ్రహం",
"గ్రూప్",
"గ్రంథాలయం"
],

"క్ర":[
"క్రికెట్",
"క్ర‌మం",
"క్రియ",
"క్రాంతి",
"క్రూరం"
],

"బ్ర":[
"బ్రహ్మ",
"బ్రతుకు",
"బ్రిడ్జ్",
"బ్రాహ్మణుడు"
],

"ద్ర":[
"ద్రాక్ష",
"ద్రవం",
"ద్రుమం",
"ద్రోహం"
]
};


/* =========================================================
   SENTENCES
   ========================================================= */

const SAMYUKTA_SENTENCES = [

"క్షమ గొప్ప గుణం.",

"అక్షరం తెలుగు భాషకు ఆధారం.",

"లక్ష్యం ఉంటే విజయం సాధించవచ్చు.",

"మిత్రుడు నాకు సహాయం చేశాడు.",

"చిత్రం చాలా అందంగా ఉంది.",

"యాత్ర ఆనందంగా జరిగింది.",

"జ్ఞానం మనిషిని గొప్పవాడిని చేస్తుంది.",

"విజ్ఞానం ప్రపంచాన్ని మార్చుతుంది.",

"శ్రద్ధగా చదవాలి.",

"శ్రీరాముడు ఆదర్శ పురుషుడు.",

"ప్రకృతి అందంగా ఉంటుంది.",

"గ్రామం ప్రశాంతంగా ఉంటుంది.",

"ద్రాక్ష పండు తియ్యగా ఉంటుంది."

];


/* =========================================================
   STORIES
   ========================================================= */

const READING_STORIES = [

"అన్న తన మిత్రుడితో కలిసి గ్రామానికి వెళ్లాడు. అక్కడ ప్రకృతి అందాలను చూసి ఆనందించాడు.",

"రాము శ్రద్ధగా చదివి విజ్ఞానం సంపాదించాడు. అతని లక్ష్యం వైద్యుడు కావడం.",

"అమ్మ ద్రాక్ష పండ్లు కొనిచ్చింది. తమ్ముడు ఆనందంగా తిన్నాడు.",

"పిల్లలు యాత్రకు వెళ్లి పెద్ద పర్వతాన్ని చూశారు. వారు ప్రకృతి అందాలను ఆస్వాదించారు."

];


/* =========================================================
   HELPERS
   ========================================================= */

function random(arr){
  return arr[Math.floor(Math.random()*arr.length)];
}


/* =========================================================
   DWITVAKSHARA QUIZ
   ========================================================= */

function generateDwitvaQuiz(){

  const groups =
    Object.keys(DWITVAKSHARA_DB);

  const group =
    random(groups);

  const word =
    random(DWITVAKSHARA_DB[group]);

  return {

    type:"dwitva",

    question:
      `"${word}" లో ద్విత్వాక్షరం ఏది?`,

    answer:group

  };

}


/* =========================================================
   SAMYUKTA QUIZ
   ========================================================= */

function generateSamyuktaQuiz(){

  const groups =
    Object.keys(SAMYUKTA_DB);

  const group =
    random(groups);

  const word =
    random(SAMYUKTA_DB[group]);

  return {

    type:"samyukta",

    question:
      `"${word}" లో సంయుక్తాక్షరం ఏది?`,

    answer:group

  };

}


/* =========================================================
   FILL BLANKS
   ========================================================= */

function generateFillBlank(){

  const questions = [

    {
      question:"అ___రం",
      answer:"క్ష"
    },

    {
      question:"మి___డు",
      answer:"త్ర"
    },

    {
      question:"___ానం",
      answer:"జ్ఞ"
    },

    {
      question:"___ద్ధ",
      answer:"శ్ర"
    },

    {
      question:"చు___",
      answer:"క్క"
    },

    {
      question:"అ___",
      answer:"న్న"
    }

  ];

  return random(questions);

}


/* =========================================================
   SENTENCE QUIZ
   ========================================================= */

function generateSentenceQuiz(){

  return {

    type:"sentence",

    sentence:
      random(SAMYUKTA_SENTENCES)

  };

}


/* =========================================================
   READING CARD
   ========================================================= */

function generateReadingCard(){

  const groups =
    Object.keys(SAMYUKTA_DB);

  const group =
    random(groups);

  return {

    aksharam:group,

    words:SAMYUKTA_DB[group]

  };

}


/* =========================================================
   DICTATION
   ========================================================= */

function generateDictation(){

  const groups =
    Object.keys(SAMYUKTA_DB);

  const group =
    random(groups);

  return {

    word:
      random(SAMYUKTA_DB[group])

  };

}


/* =========================================================
   STORY GENERATOR
   ========================================================= */

function generateStory(){

  return random(READING_STORIES);

}


/* =========================================================
   PROGRESS STATS
   ========================================================= */

function getStats(){

  let dwitvaWords = 0;
  let samyuktaWords = 0;

  Object.values(DWITVAKSHARA_DB)
    .forEach(arr=>dwitvaWords += arr.length);

  Object.values(SAMYUKTA_DB)
    .forEach(arr=>samyuktaWords += arr.length);

  return {

    dwitvaksharaGroups:
      Object.keys(DWITVAKSHARA_DB).length,

    samyuktaGroups:
      Object.keys(SAMYUKTA_DB).length,

    dwitvaksharaWords:
      dwitvaWords,

    samyuktaWords:
      samyuktaWords,

    totalSentences:
      SAMYUKTA_SENTENCES.length,

    totalStories:
      READING_STORIES.length

  };

}


/* =========================================================
   SAMPLE USAGE
   ========================================================= */

console.log(generateDwitvaQuiz());

console.log(generateSamyuktaQuiz());

console.log(generateFillBlank());

console.log(generateSentenceQuiz());

console.log(generateReadingCard());

console.log(generateDictation());

console.log(generateStory());

console.log(getStats());