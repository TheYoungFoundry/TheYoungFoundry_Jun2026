/* ==========================================
   VERBS RELATIONS (1-50)
   Telugu + English + Synonyms + Antonyms
   ========================================== */

const VERBS_RELATIONS = [

{
word:"తిను",
english:"Eat",
synonyms:[
{telugu:"భుజించు",english:"Consume"},
{telugu:"ఆరగించు",english:"Devour"}
],
antonyms:[
{telugu:"ఉపవాసం చేయు",english:"Fast"}
]
},

{
word:"తాగు",
english:"Drink",
synonyms:[
{telugu:"సేవించు",english:"Consume"},
{telugu:"పానం చేయు",english:"Sip"}
],
antonyms:[
{telugu:"విరమించు",english:"Abstain"}
]
},

{
word:"చదువు",
english:"Study",
synonyms:[
{telugu:"అభ్యసించు",english:"Learn"},
{telugu:"నేర్చుకో",english:"Acquire Knowledge"}
],
antonyms:[
{telugu:"నిర్లక్ష్యం చేయు",english:"Ignore"}
]
},

{
word:"రాయి",
english:"Write",
synonyms:[
{telugu:"లిఖించు",english:"Record"},
{telugu:"వ్రాయు",english:"Compose"}
],
antonyms:[
{telugu:"తుడిచివేయు",english:"Erase"}
]
},

{
word:"చూడు",
english:"See",
synonyms:[
{telugu:"వీక్షించు",english:"Observe"},
{telugu:"గమనించు",english:"Notice"}
],
antonyms:[
{telugu:"పట్టించుకోకు",english:"Ignore"}
]
},

{
word:"విను",
english:"Listen",
synonyms:[
{telugu:"శ్రద్ధగా విను",english:"Hear Carefully"},
{telugu:"ఆలకించు",english:"Listen"}
],
antonyms:[
{telugu:"పట్టించుకోకు",english:"Ignore"}
]
},

{
word:"నడువు",
english:"Walk",
synonyms:[
{telugu:"సంచరించు",english:"Move"},
{telugu:"ప్రయాణించు",english:"Travel"}
],
antonyms:[
{telugu:"నిలబడు",english:"Stand Still"}
]
},

{
word:"పరుగెత్తు",
english:"Run",
synonyms:[
{telugu:"దౌడు తీయు",english:"Sprint"},
{telugu:"వేగంగా నడువు",english:"Rush"}
],
antonyms:[
{telugu:"ఆగు",english:"Stop"}
]
},

{
word:"ఆడు",
english:"Play",
synonyms:[
{telugu:"క్రీడించు",english:"Participate"},
{telugu:"వినోదించు",english:"Enjoy"}
],
antonyms:[
{telugu:"పని చేయు",english:"Work"}
]
},

{
word:"పాడు",
english:"Sing",
synonyms:[
{telugu:"గానం చేయు",english:"Chant"},
{telugu:"ఆలపించు",english:"Perform"}
],
antonyms:[
{telugu:"మౌనంగా ఉండు",english:"Remain Silent"}
]
},

{
word:"నవ్వు",
english:"Laugh",
synonyms:[
{telugu:"చిరునవ్వు చిందించు",english:"Smile"},
{telugu:"హాసించు",english:"Laugh"}
],
antonyms:[
{telugu:"ఏడు",english:"Cry"}
]
},

{
word:"ఏడు",
english:"Cry",
synonyms:[
{telugu:"రోదించు",english:"Weep"},
{telugu:"విలపించు",english:"Lament"}
],
antonyms:[
{telugu:"నవ్వు",english:"Laugh"}
]
},

{
word:"నిద్రపో",
english:"Sleep",
synonyms:[
{telugu:"విశ్రాంతి తీసుకో",english:"Rest"},
{telugu:"శయనించు",english:"Sleep"}
],
antonyms:[
{telugu:"మేల్కొను",english:"Wake Up"}
]
},

{
word:"కూర్చో",
english:"Sit",
synonyms:[
{telugu:"ఆసీనమవు",english:"Be Seated"},
{telugu:"విశ్రాంతి తీసుకో",english:"Rest"}
],
antonyms:[
{telugu:"నిలబడు",english:"Stand"}
]
},

{
word:"నిలబడు",
english:"Stand",
synonyms:[
{telugu:"నిటారుగా ఉండు",english:"Remain Upright"},
{telugu:"లేచి ఉండు",english:"Stay Standing"}
],
antonyms:[
{telugu:"కూర్చో",english:"Sit"}
]
},

{
word:"ఎక్కు",
english:"Climb",
synonyms:[
{telugu:"ఆరోహించు",english:"Ascend"},
{telugu:"పైకి వెళ్లు",english:"Go Up"}
],
antonyms:[
{telugu:"దుగు",english:"Descend"}
]
},

{
word:"దుగు",
english:"Descend",
synonyms:[
{telugu:"కిందకు వెళ్లు",english:"Go Down"},
{telugu:"అవరోహించు",english:"Descend"}
],
antonyms:[
{telugu:"ఎక్కు",english:"Climb"}
]
},

{
word:"తెరువు",
english:"Open",
synonyms:[
{telugu:"విప్పు",english:"Uncover"},
{telugu:"ప్రారంభించు",english:"Open Up"}
],
antonyms:[
{telugu:"మూయు",english:"Close"}
]
},

{
word:"మూయు",
english:"Close",
synonyms:[
{telugu:"బంద్ చేయు",english:"Shut"},
{telugu:"ఆపు",english:"Seal"}
],
antonyms:[
{telugu:"తెరువు",english:"Open"}
]
},

{
word:"తెచ్చు",
english:"Bring",
synonyms:[
{telugu:"తీసుకురా",english:"Carry"},
{telugu:"సమకూర్చు",english:"Provide"}
],
antonyms:[
{telugu:"తీసుకుపో",english:"Take Away"}
]
},

{
word:"ఇవ్వు",
english:"Give",
synonyms:[
{telugu:"అందించు",english:"Provide"},
{telugu:"దానం చేయు",english:"Donate"}
],
antonyms:[
{telugu:"తీసుకో",english:"Take"}
]
},

{
word:"తీసుకో",
english:"Take",
synonyms:[
{telugu:"స్వీకరించు",english:"Accept"},
{telugu:"పొందు",english:"Receive"}
],
antonyms:[
{telugu:"ఇవ్వు",english:"Give"}
]
},

{
word:"పిలువు",
english:"Call",
synonyms:[
{telugu:"ఆహ్వానించు",english:"Invite"},
{telugu:"సంబోధించు",english:"Address"}
],
antonyms:[
{telugu:"పంపివేయు",english:"Dismiss"}
]
},

{
word:"మాట్లాడు",
english:"Speak",
synonyms:[
{telugu:"సంభాషించు",english:"Converse"},
{telugu:"చర్చించు",english:"Talk"}
],
antonyms:[
{telugu:"మౌనంగా ఉండు",english:"Remain Silent"}
]
},

{
word:"ఆలోచించు",
english:"Think",
synonyms:[
{telugu:"పరిశీలించు",english:"Consider"},
{telugu:"చింతించు",english:"Reflect"}
],
antonyms:[
{telugu:"ఆలోచించకుండా చేయు",english:"Act Thoughtlessly"}
]
},

{
word:"గీయు",
english:"Draw",
synonyms:[
{telugu:"చిత్రించు",english:"Sketch"},
{telugu:"రూపకల్పన చేయు",english:"Design"}
],
antonyms:[
{telugu:"తుడిచివేయు",english:"Erase"}
]
},

{
word:"కడుగు",
english:"Wash",
synonyms:[
{telugu:"శుభ్రపరచు",english:"Clean"},
{telugu:"పరిశుభ్రం చేయు",english:"Wash Thoroughly"}
],
antonyms:[
{telugu:"మురికిచేయు",english:"Dirty"}
]
},

{
word:"వంటచేయు",
english:"Cook",
synonyms:[
{telugu:"ఆహారం తయారు చేయు",english:"Prepare Food"},
{telugu:"పాకం చేయు",english:"Cook"}
],
antonyms:[
{telugu:"పచ్చిగా ఉంచు",english:"Leave Raw"}
]
},

{
word:"కొను",
english:"Buy",
synonyms:[
{telugu:"కొనుగోలు చేయు",english:"Purchase"},
{telugu:"సంపాదించు",english:"Acquire"}
],
antonyms:[
{telugu:"అమ్ము",english:"Sell"}
]
},

{
word:"అమ్ము",
english:"Sell",
synonyms:[
{telugu:"విక్రయించు",english:"Market"},
{telugu:"అందజేయు",english:"Trade"}
],
antonyms:[
{telugu:"కొను",english:"Buy"}
]
},

{
word:"దాచు",
english:"Hide",
synonyms:[
{telugu:"మరుగు పరచు",english:"Conceal"},
{telugu:"గోప్యంగా ఉంచు",english:"Keep Secret"}
],
antonyms:[
{telugu:"బయటపెట్టు",english:"Reveal"}
]
},

{
word:"వెతుకు",
english:"Search",
synonyms:[
{telugu:"అన్వేషించు",english:"Explore"},
{telugu:"శోధించు",english:"Seek"}
],
antonyms:[
{telugu:"వదిలేయు",english:"Ignore"}
]
},

{
word:"పంపు",
english:"Send",
synonyms:[
{telugu:"రవాణా చేయు",english:"Dispatch"},
{telugu:"అందించు",english:"Forward"}
],
antonyms:[
{telugu:"ఆపివేయు",english:"Hold Back"}
]
},

{
word:"సహాయం చేయు",
english:"Help",
synonyms:[
{telugu:"తోడ్పడు",english:"Support"},
{telugu:"ఉపకరించు",english:"Assist"}
],
antonyms:[
{telugu:"అడ్డుకో",english:"Hinder"}
]
},

{
word:"పట్టుకో",
english:"Catch",
synonyms:[
{telugu:"బిగిగా పట్టుకో",english:"Grip"},
{telugu:"స్వాధీనం చేసుకో",english:"Seize"}
],
antonyms:[
{telugu:"వదులు",english:"Release"}
]
},

{
word:"వదులు",
english:"Release",
synonyms:[
{telugu:"విముక్తి కల్పించు",english:"Free"},
{telugu:"విడిచిపెట్టు",english:"Let Go"}
],
antonyms:[
{telugu:"పట్టుకో",english:"Hold"}
]
},

{
word:"కట్టు",
english:"Tie",
synonyms:[
{telugu:"బంధించు",english:"Bind"},
{telugu:"కలుపు",english:"Fasten"}
],
antonyms:[
{telugu:"విప్పు",english:"Untie"}
]
},

{
word:"విప్పు",
english:"Untie",
synonyms:[
{telugu:"వదులు",english:"Loosen"},
{telugu:"తెరువు",english:"Open"}
],
antonyms:[
{telugu:"కట్టు",english:"Tie"}
]
},

{
word:"ప్రయాణించు",
english:"Travel",
synonyms:[
{telugu:"సంచరించు",english:"Journey"},
{telugu:"వెళ్ళు",english:"Move Around"}
],
antonyms:[
{telugu:"ఒకేచోట ఉండు",english:"Stay"}
]
},

{
word:"సృష్టించు",
english:"Create",
synonyms:[
{telugu:"రూపొందించు",english:"Develop"},
{telugu:"నిర్మించు",english:"Build"}
],
antonyms:[
{telugu:"నాశనం చేయు",english:"Destroy"}
]
},

{
word:"దూకు",
english:"Jump",
synonyms:[
{telugu:"ఎగురు",english:"Leap"},
{telugu:"గెంతు",english:"Hop"}
],
antonyms:[
{telugu:"నిలుచు",english:"Stay Still"}
]
},

{
word:"గెలుచు",
english:"Win",
synonyms:[
{telugu:"విజయం సాధించు",english:"Succeed"},
{telugu:"జయించు",english:"Conquer"}
],
antonyms:[
{telugu:"ఓడిపో",english:"Lose"}
]
},

{
word:"ఓడిపో",
english:"Lose",
synonyms:[
{telugu:"పరాజయం పొందు",english:"Fail"},
{telugu:"విఫలమవు",english:"Be Defeated"}
],
antonyms:[
{telugu:"గెలుచు",english:"Win"}
]
},

{
word:"నేర్చుకో",
english:"Learn",
synonyms:[
{telugu:"అభ్యసించు",english:"Study"},
{telugu:"గ్రహించు",english:"Understand"}
],
antonyms:[
{telugu:"మర్చిపో",english:"Forget"}
]
},

{
word:"బోధించు",
english:"Teach",
synonyms:[
{telugu:"నేర్పించు",english:"Educate"},
{telugu:"వివరించు",english:"Instruct"}
],
antonyms:[
{telugu:"నేర్చుకో",english:"Learn"}
]
},

{
word:"శుభ్రం చేయు",
english:"Clean",
synonyms:[
{telugu:"పరిశుభ్రం చేయు",english:"Sanitize"},
{telugu:"కడుగు",english:"Wash"}
],
antonyms:[
{telugu:"మురికిచేయు",english:"Dirty"}
]
},

{
word:"సాగు",
english:"Cultivate",
synonyms:[
{telugu:"వ్యవసాయం చేయు",english:"Farm"},
{telugu:"పెంపకం చేయు",english:"Grow"}
],
antonyms:[
{telugu:"నాశనం చేయు",english:"Destroy"}
]
},

{
word:"పెంచు",
english:"Increase",
synonyms:[
{telugu:"వృద్ధి చేయు",english:"Expand"},
{telugu:"అభివృద్ధి చేయు",english:"Enhance"}
],
antonyms:[
{telugu:"తగ్గించు",english:"Reduce"}
]
},

{
word:"పండించు",
english:"Grow",
synonyms:[
{telugu:"సాగు చేయు",english:"Cultivate"},
{telugu:"ఉత్పత్తి చేయు",english:"Produce"}
],
antonyms:[
{telugu:"నాశనం చేయు",english:"Destroy"}
]
},

{
word:"రక్షించు",
english:"Protect",
synonyms:[
{telugu:"కాపాడు",english:"Guard"},
{telugu:"సంరక్షించు",english:"Preserve"}
],
antonyms:[
{telugu:"హాని చేయు",english:"Harm"}
]
},

{
word:"అన్వేషించు",
english:"Explore",
synonyms:[
{telugu:"పరిశోధించు",english:"Investigate"},
{telugu:"వెతుకు",english:"Search"}
],
antonyms:[
{telugu:"వదిలేయు",english:"Ignore"}
]
}

];

/* Total: 50 Verbs */