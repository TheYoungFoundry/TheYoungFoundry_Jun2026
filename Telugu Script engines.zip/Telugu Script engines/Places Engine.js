/* ==========================================
   TELUGU PLACES ENGINE
   ========================================== */

/* ------------------------------------------
   PLACE CATEGORIES
------------------------------------------ */

const PLACE_CATEGORIES = {

  home:[
    "ఇల్లు"
  ],

  education:[
    "పాఠశాల",
    "గ్రంథాలయం",
    "విశ్వవిద్యాలయం",
    "కళాశాల",
    "ల్యాబ్"
  ],

  healthcare:[
    "ఆసుపత్రి"
  ],

  religious:[
    "దేవాలయం",
    "దేవస్థానం"
  ],

  recreation:[
    "పార్క్",
    "ఆటస్థలం",
    "క్రీడామైదానం",
    "స్టేడియం",
    "జూ",
    "అక్వేరియం",
    "సినిమాహాలు"
  ],

  shopping:[
    "బజారు",
    "దుకాణం",
    "షాపింగ్ మాల్",
    "పుస్తక దుకాణం"
  ],

  transport:[
    "రైల్వే స్టేషన్",
    "విమానాశ్రయం",
    "బస్ స్టాండ్",
    "వంతెన",
    "రోడ్డు",
    "వీధి"
  ],

  government:[
    "పోలీస్ స్టేషన్",
    "ఫైర్ స్టేషన్",
    "కోర్టు",
    "తపాలా కార్యాలయం",
    "బ్యాంకు"
  ],

  work:[
    "కార్యాలయం",
    "ఫ్యాక్టరీ"
  ],

  nature:[
    "పొలం",
    "అడవి",
    "సముద్రతీరం",
    "కొండ",
    "చెరువు",
    "నది"
  ],

  tourism:[
    "పర్యాటక స్థలం",
    "మ్యూజియం",
    "ఎగ్జిబిషన్"
  ],

  hospitality:[
    "హోటల్",
    "రెస్టారెంట్"
  ],

  events:[
    "వేదిక",
    "గ్రౌండ్"
  ]
};

/* ------------------------------------------
   ACTIVITIES
------------------------------------------ */

const PLACE_ACTIVITIES = {

  learn:[
    "చదువు",
    "నేర్చుకో",
    "పరిశోధించు",
    "అభ్యసించు"
  ],

  play:[
    "ఆడు",
    "పరుగెత్తు",
    "పోటీపడు"
  ],

  pray:[
    "ప్రార్థించు",
    "పూజచేయు"
  ],

  shop:[
    "కొను",
    "అమ్ము",
    "ఎంచుకో"
  ],

  travel:[
    "ప్రయాణించు",
    "వెళ్ళు",
    "చేరుకో"
  ],

  work:[
    "పనిచేయు",
    "సృష్టించు",
    "నిర్వహించు"
  ],

  explore:[
    "అన్వేషించు",
    "చూడు",
    "పరిశీలించు"
  ],

  relax:[
    "విశ్రాంతి తీసుకో",
    "ఆనందించు"
  ],

  eat:[
    "తిను",
    "తాగు"
  ],

  protect:[
    "రక్షించు",
    "సహాయం చేయు"
  ]
};

/* ------------------------------------------
   PLACES
------------------------------------------ */

const PLACES = [

{
telugu:"ఇల్లు",
english:"House",
emoji:"🏠",
category:"home",
activities:["relax"]
},

{
telugu:"పాఠశాల",
english:"School",
emoji:"🏫",
category:"education",
activities:["learn"]
},

{
telugu:"గ్రంథాలయం",
english:"Library",
emoji:"📚",
category:"education",
activities:["learn","explore"]
},

{
telugu:"ఆసుపత్రి",
english:"Hospital",
emoji:"🏥",
category:"healthcare",
activities:["protect"]
},

{
telugu:"దేవాలయం",
english:"Temple",
emoji:"🛕",
category:"religious",
activities:["pray"]
},

{
telugu:"పార్క్",
english:"Park",
emoji:"🌳",
category:"recreation",
activities:["play","relax"]
},

{
telugu:"తోట",
english:"Garden",
emoji:"🌺",
category:"nature",
activities:["relax","explore"]
},

{
telugu:"బజారు",
english:"Market",
emoji:"🛍️",
category:"shopping",
activities:["shop"]
},

{
telugu:"దుకాణం",
english:"Shop",
emoji:"🏪",
category:"shopping",
activities:["shop"]
},

{
telugu:"బ్యాంకు",
english:"Bank",
emoji:"🏦",
category:"government",
activities:["work"]
},

{
telugu:"తపాలా కార్యాలయం",
english:"Post Office",
emoji:"📮",
category:"government",
activities:["work"]
},

{
telugu:"రైల్వే స్టేషన్",
english:"Railway Station",
emoji:"🚉",
category:"transport",
activities:["travel"]
},

{
telugu:"విమానాశ్రయం",
english:"Airport",
emoji:"✈️",
category:"transport",
activities:["travel"]
},

{
telugu:"రోడ్డు",
english:"Road",
emoji:"🛣️",
category:"transport",
activities:["travel"]
},

{
telugu:"వీధి",
english:"Street",
emoji:"🚶",
category:"transport",
activities:["travel"]
},

{
telugu:"గ్రామం",
english:"Village",
emoji:"🏡",
category:"nature",
activities:["relax"]
},

{
telugu:"పట్టణం",
english:"Town",
emoji:"🏘️",
category:"nature",
activities:["work"]
},

{
telugu:"నగరం",
english:"City",
emoji:"🌆",
category:"nature",
activities:["work","travel"]
},

{
telugu:"పొలం",
english:"Farm",
emoji:"🌾",
category:"nature",
activities:["work"]
},

{
telugu:"అడవి",
english:"Forest",
emoji:"🌲",
category:"nature",
activities:["explore"]
},

{
telugu:"సముద్రతీరం",
english:"Beach",
emoji:"🏖️",
category:"nature",
activities:["relax"]
},

{
telugu:"కొండ",
english:"Hill",
emoji:"⛰️",
category:"nature",
activities:["explore"]
},

{
telugu:"చెరువు",
english:"Pond",
emoji:"🏞️",
category:"nature",
activities:["explore"]
},

{
telugu:"నది",
english:"River",
emoji:"🌊",
category:"nature",
activities:["explore"]
},

{
telugu:"వంతెన",
english:"Bridge",
emoji:"🌉",
category:"transport",
activities:["travel"]
},

{
telugu:"క్రీడామైదానం",
english:"Playground",
emoji:"⚽",
category:"recreation",
activities:["play"]
},

{
telugu:"మ్యూజియం",
english:"Museum",
emoji:"🏛️",
category:"tourism",
activities:["explore"]
},

{
telugu:"జూ",
english:"Zoo",
emoji:"🦁",
category:"recreation",
activities:["explore"]
},

{
telugu:"సినిమాహాలు",
english:"Cinema Hall",
emoji:"🎬",
category:"recreation",
activities:["relax"]
},

{
telugu:"హోటల్",
english:"Hotel",
emoji:"🏨",
category:"hospitality",
activities:["relax"]
},

{
telugu:"రెస్టారెంట్",
english:"Restaurant",
emoji:"🍽️",
category:"hospitality",
activities:["eat"]
},

{
telugu:"కార్యాలయం",
english:"Office",
emoji:"🏢",
category:"work",
activities:["work"]
},

{
telugu:"ఫ్యాక్టరీ",
english:"Factory",
emoji:"🏭",
category:"work",
activities:["work"]
},

{
telugu:"బస్ స్టాండ్",
english:"Bus Stand",
emoji:"🚌",
category:"transport",
activities:["travel"]
},

{
telugu:"విశ్వవిద్యాలయం",
english:"University",
emoji:"🎓",
category:"education",
activities:["learn"]
},

{
telugu:"కళాశాల",
english:"College",
emoji:"🏫",
category:"education",
activities:["learn"]
},

{
telugu:"దేవస్థానం",
english:"Shrine",
emoji:"🛕",
category:"religious",
activities:["pray"]
},

{
telugu:"షాపింగ్ మాల్",
english:"Shopping Mall",
emoji:"🏬",
category:"shopping",
activities:["shop"]
},

{
telugu:"గ్రౌండ్",
english:"Ground",
emoji:"🏟️",
category:"events",
activities:["play"]
},

{
telugu:"పర్యాటక స్థలం",
english:"Tourist Place",
emoji:"📸",
category:"tourism",
activities:["explore"]
},

{
telugu:"పోలీస్ స్టేషన్",
english:"Police Station",
emoji:"🚔",
category:"government",
activities:["protect"]
},

{
telugu:"ఫైర్ స్టేషన్",
english:"Fire Station",
emoji:"🚒",
category:"government",
activities:["protect"]
},

{
telugu:"కోర్టు",
english:"Court",
emoji:"⚖️",
category:"government",
activities:["work"]
},

{
telugu:"ల్యాబ్",
english:"Laboratory",
emoji:"🔬",
category:"education",
activities:["learn"]
},

{
telugu:"వేదిక",
english:"Stage",
emoji:"🎭",
category:"events",
activities:["play"]
},

{
telugu:"ఎగ్జిబిషన్",
english:"Exhibition",
emoji:"🖼️",
category:"tourism",
activities:["explore"]
},

{
telugu:"అక్వేరియం",
english:"Aquarium",
emoji:"🐠",
category:"recreation",
activities:["explore"]
},

{
telugu:"పుస్తక దుకాణం",
english:"Book Store",
emoji:"📖",
category:"shopping",
activities:["shop","learn"]
},

{
telugu:"స్టేడియం",
english:"Stadium",
emoji:"🏟️",
category:"recreation",
activities:["play"]
},

{
telugu:"ఆటస్థలం",
english:"Play Area",
emoji:"🛝",
category:"recreation",
activities:["play"]
}

];

/* ------------------------------------------
   SENTENCE TEMPLATES
------------------------------------------ */

const PLACE_TEMPLATES = [

"{word} చాలా ముఖ్యమైన ప్రదేశం.",

"మేము {word}కు వెళ్ళాము.",

"{word}లో చాలా మంది ఉంటారు.",

"{word}లో అనేక కార్యక్రమాలు జరుగుతాయి.",

"{word} సందర్శించడానికి మంచి ప్రదేశం."
];

/* ------------------------------------------
   ENGINE
------------------------------------------ */

function random(arr){
  return arr[Math.floor(Math.random()*arr.length)];
}

function generatePlaceSentence(place){

  let sentence =
    random(PLACE_TEMPLATES);

  return sentence.replace(
    "{word}",
    place.telugu
  );
}

function generatePlaceDescription(place){

  return `${place.telugu} (${place.english}) ఒక ముఖ్యమైన ${place.category} ప్రదేశం.`;
}

/* ------------------------------------------
   EXAMPLES
------------------------------------------ */

console.log(generatePlaceSentence(PLACES[0]));
console.log(generatePlaceSentence(PLACES[10]));
console.log(generatePlaceDescription(PLACES[25]));